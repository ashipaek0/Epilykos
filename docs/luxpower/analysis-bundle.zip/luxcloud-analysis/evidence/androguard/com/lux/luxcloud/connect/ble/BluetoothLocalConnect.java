package com.lux.luxcloud.connect.ble;
public class BluetoothLocalConnect extends com.lux.luxcloud.connect.AbstractLocalConnect implements com.lux.luxcloud.tcp.CommandSender {
    private static final int DEFAULT_ATT_PAYLOAD_SIZE = 20;
    private static final int DEFAULT_MTU = 23;
    private static final int GATT_CONN_TIMEOUT_62 = 62;
    private static final int GATT_ERROR_133 = 133;
    private static final int MAX_GATT_RETRY = 3;
    private static final int SYNC_INIT_MAX_WAIT_COUNT = 600;
    private static final int TARGET_MTU = 256;
    public static final boolean isDebug = False;
    private com.lux.luxcloud.connect.ble.BleAction bleAction;
    private android.os.Handler bleHandler;
    private final android.os.HandlerThread bleHandlerThread;
    private android.bluetooth.BluetoothDevice bluetoothDevice;
    private android.bluetooth.BluetoothGatt bluetoothGatt;
    protected java.util.Map commandWaitMap;
    private volatile boolean connectFinished;
    private com.lux.luxcloud.connect.listener.ConnectListener connectListener;
    private volatile boolean connected;
    private volatile boolean connecting;
    private volatile int currentChunkSize;
    private volatile int currentMtu;
    private volatile int gattRetryCount;
    private volatile boolean gattRetryScheduled;
    private volatile String lastConnectError;
    private android.bluetooth.BluetoothGattCharacteristic notifyCharacteristic;
    private com.lux.luxcloud.tcp.TcpAnalyzer tcpAnalyzer;
    private android.bluetooth.BluetoothGattCharacteristic writeCharacteristic;

    public static synthetic void $r8$lambda$GfYeZXhT6JxKB-TUQP6yNWH5fS4(com.lux.luxcloud.connect.ble.BluetoothLocalConnect p0)
    {
        p0.lambda$scheduleGattRetry$0();
        return;
    }

    static bridge synthetic android.os.Handler -$$Nest$fgetbleHandler(com.lux.luxcloud.connect.ble.BluetoothLocalConnect p0)
    {
        return p0.bleHandler;
    }

    static bridge synthetic android.bluetooth.BluetoothGatt -$$Nest$fgetbluetoothGatt(com.lux.luxcloud.connect.ble.BluetoothLocalConnect p0)
    {
        return p0.bluetoothGatt;
    }

    static bridge synthetic com.lux.luxcloud.connect.listener.ConnectListener -$$Nest$fgetconnectListener(com.lux.luxcloud.connect.ble.BluetoothLocalConnect p0)
    {
        return p0.connectListener;
    }

    static bridge synthetic boolean -$$Nest$fgetconnected(com.lux.luxcloud.connect.ble.BluetoothLocalConnect p0)
    {
        return p0.connected;
    }

    static bridge synthetic int -$$Nest$fgetgattRetryCount(com.lux.luxcloud.connect.ble.BluetoothLocalConnect p0)
    {
        return p0.gattRetryCount;
    }

    static bridge synthetic com.lux.luxcloud.tcp.TcpAnalyzer -$$Nest$fgettcpAnalyzer(com.lux.luxcloud.connect.ble.BluetoothLocalConnect p0)
    {
        return p0.tcpAnalyzer;
    }

    static bridge synthetic void -$$Nest$fputbluetoothGatt(com.lux.luxcloud.connect.ble.BluetoothLocalConnect p0, android.bluetooth.BluetoothGatt p1)
    {
        p0.bluetoothGatt = p1;
        return;
    }

    static bridge synthetic void -$$Nest$fputconnectFinished(com.lux.luxcloud.connect.ble.BluetoothLocalConnect p0, boolean p1)
    {
        p0.connectFinished = p1;
        return;
    }

    static bridge synthetic void -$$Nest$fputcurrentChunkSize(com.lux.luxcloud.connect.ble.BluetoothLocalConnect p0, int p1)
    {
        p0.currentChunkSize = p1;
        return;
    }

    static bridge synthetic void -$$Nest$fputcurrentMtu(com.lux.luxcloud.connect.ble.BluetoothLocalConnect p0, int p1)
    {
        p0.currentMtu = p1;
        return;
    }

    static bridge synthetic void -$$Nest$fputlastConnectError(com.lux.luxcloud.connect.ble.BluetoothLocalConnect p0, String p1)
    {
        p0.lastConnectError = p1;
        return;
    }

    static bridge synthetic void -$$Nest$fputnotifyCharacteristic(com.lux.luxcloud.connect.ble.BluetoothLocalConnect p0, android.bluetooth.BluetoothGattCharacteristic p1)
    {
        p0.notifyCharacteristic = p1;
        return;
    }

    static bridge synthetic void -$$Nest$fputwriteCharacteristic(com.lux.luxcloud.connect.ble.BluetoothLocalConnect p0, android.bluetooth.BluetoothGattCharacteristic p1)
    {
        p0.writeCharacteristic = p1;
        return;
    }

    static bridge synthetic void -$$Nest$mcloseGattSafely(com.lux.luxcloud.connect.ble.BluetoothLocalConnect p0, android.bluetooth.BluetoothGatt p1)
    {
        p0.closeGattSafely(p1);
        return;
    }

    static bridge synthetic void -$$Nest$mfinishConnectFailed(com.lux.luxcloud.connect.ble.BluetoothLocalConnect p0, android.bluetooth.BluetoothGatt p1, String p2)
    {
        p0.finishConnectFailed(p1, p2);
        return;
    }

    static bridge synthetic void -$$Nest$monBleReady(com.lux.luxcloud.connect.ble.BluetoothLocalConnect p0)
    {
        p0.onBleReady();
        return;
    }

    static bridge synthetic void -$$Nest$mscheduleGattRetry(com.lux.luxcloud.connect.ble.BluetoothLocalConnect p0, int p1)
    {
        p0.scheduleGattRetry(p1);
        return;
    }

    static bridge synthetic boolean -$$Nest$mshouldRetryGattError(com.lux.luxcloud.connect.ble.BluetoothLocalConnect p0, int p1)
    {
        return p0.shouldRetryGattError(p1);
    }

    public BluetoothLocalConnect(com.lux.luxcloud.connect.ble.BleAction p4, android.bluetooth.BluetoothDevice p5)
    {
        super("bluetooth");
        super.currentMtu = 23;
        super.currentChunkSize = 20;
        super.gattRetryCount = 0;
        super.gattRetryScheduled = 0;
        super.connectFinished = 0;
        super.lastConnectError = 0;
        android.os.HandlerThread v1_2 = new android.os.HandlerThread("BLE-Worker");
        super.bleHandlerThread = v1_2;
        super.connecting = 0;
        super.connected = 0;
        super.commandWaitMap = new java.util.concurrent.ConcurrentSkipListMap();
        super.bleAction = p4;
        super.bluetoothDevice = p5;
        com.lux.luxcloud.tcp.TcpAnalyzer v4_1 = p5.getName();
        if ((v4_1 == null) || (v4_1.trim().length() <= 0)) {
            v4_1 = com.lux.luxcloud.global.Constants.DEFAULT_DATALOG_SN;
        }
        super.datalogSn = v4_1;
        try {
            v1_2.start();
            super.bleHandler = new android.os.Handler(v1_2.getLooper());
        } catch (Exception) {
            super.bleHandler = new android.os.Handler(android.os.Looper.getMainLooper());
        }
        super.tcpAnalyzer = new com.lux.luxcloud.tcp.TcpAnalyzer(super);
        return;
    }

    private void closeGattSafely(android.bluetooth.BluetoothGatt p3)
    {
        if (p3 == 0) {
            p3 = this.bluetoothGatt;
        }
        try {
            if (p3 != 0) {
                p3.disconnect();
            }
            try {
                if (p3 != 0) {
                    p3.close();
                }
            } catch (Exception) {
            }
            if (this.bluetoothGatt == p3) {
                this.bluetoothGatt = 0;
            }
            this.notifyCharacteristic = 0;
            this.writeCharacteristic = 0;
            this.currentMtu = 23;
            this.currentChunkSize = 20;
            this.connected = 0;
            this.connecting = 0;
            return;
        } catch (Exception) {
        }
    }

    private void connect()
    {
        if ((!this.connecting) && (this.bluetoothGatt == null)) {
            this.startConnectGatt();
        }
        return;
    }

    private void finishConnectFailed(android.bluetooth.BluetoothGatt p3, String p4)
    {
        this.lastConnectError = p4;
        this.gattRetryScheduled = 0;
        this.connectFinished = 1;
        this.closeGattSafely(p3);
        System.out.println(new StringBuilder("LuxPower - BLE connect finally failed, retryCount=").append(this.gattRetryCount).append(", msg=").append(p4).toString());
        com.lux.luxcloud.connect.listener.ConnectListener v3_1 = this.connectListener;
        if (v3_1 != null) {
            v3_1.onFail(p4);
        }
        return;
    }

    private synthetic void lambda$scheduleGattRetry$0()
    {
        this.gattRetryScheduled = 0;
        if (!this.connected) {
            System.out.println(new StringBuilder("LuxPower - BLE retry start, retry=").append(this.gattRetryCount).append("/3").toString());
            this.connect();
            return;
        } else {
            return;
        }
    }

    private void onBleReady()
    {
        System.out.println(new StringBuilder("LuxPower - BLE READY, mtu=").append(this.currentMtu).append(", chunkSize=").append(this.currentChunkSize).append(", retryCount=").append(this.gattRetryCount).toString());
        this.connected = 1;
        this.connecting = 0;
        this.gattRetryScheduled = 0;
        this.connectFinished = 1;
        this.lastConnectError = 0;
        this.gattRetryCount = 0;
        com.lux.luxcloud.connect.ble.BleAction v0_3 = this.connectListener;
        if (v0_3 != null) {
            v0_3.onConnected();
        }
        com.lux.luxcloud.connect.ble.BleAction v0_4 = this.bleAction;
        if (v0_4 != null) {
            v0_4.bleConnected();
        }
        return;
    }

    private void scheduleGattRetry(int p7)
    {
        if (this.gattRetryCount < 3) {
            this.gattRetryCount = (this.gattRetryCount + 1);
            long v2_0 = (((long) this.gattRetryCount) * 800);
            this.gattRetryScheduled = 1;
            this.connectFinished = 0;
            System.out.println(new StringBuilder("LuxPower - BLE retry scheduled, status=").append(p7).append(", retry=").append(this.gattRetryCount).append("/3, delay=").append(v2_0).toString());
            com.lux.luxcloud.connect.ble.BluetoothLocalConnect$$ExternalSyntheticLambda0 v7_8 = new com.lux.luxcloud.connect.ble.BluetoothLocalConnect$$ExternalSyntheticLambda0(this);
            android.os.Handler v0_4 = this.bleHandler;
            if (v0_4 == null) {
                v7_8.run();
                return;
            } else {
                v0_4.postDelayed(v7_8, v2_0);
                return;
            }
        } else {
            this.finishConnectFailed(0, new StringBuilder("gatt error: ").append(p7).toString());
            return;
        }
    }

    private boolean shouldRetryGattError(int p2)
    {
        if ((p2 != 133) && (p2 != 62)) {
            return 0;
        } else {
            return 1;
        }
    }

    private void startConnectGatt()
    {
        this.connecting = 1;
        this.connected = 0;
        this.gattRetryScheduled = 0;
        this.currentMtu = 23;
        this.currentChunkSize = 20;
        System.out.println(new StringBuilder("LuxPower - ble - connectGatt start, retry=").append(this.gattRetryCount).append("/3").toString());
        try {
            this.bluetoothGatt = this.bluetoothDevice.connectGatt(((android.content.Context) this.bleAction), 0, new com.lux.luxcloud.connect.ble.BluetoothLocalConnect$GattCallback(this, 0));
            return;
        } catch (String v0_3) {
            v0_3.printStackTrace();
            this.finishConnectFailed(0, new StringBuilder("connectGatt exception: ").append(v0_3.getMessage()).toString());
            return;
        }
    }

    public void close()
    {
        this.gattRetryScheduled = 0;
        this.connectFinished = 1;
        android.os.HandlerThread v0_3 = this.bleHandler;
        if (v0_3 != null) {
            v0_3.removeCallbacksAndMessages(0);
        }
        this.closeGattSafely(this.bluetoothGatt);
        try {
            this.bleHandlerThread.quitSafely();
        } catch (Exception) {
        }
        return;
    }

    public void connect(com.lux.luxcloud.connect.listener.ConnectListener p2)
    {
        if ((!this.connecting) && ((this.bluetoothGatt == null) && (!this.gattRetryScheduled))) {
            this.connectListener = p2;
            this.gattRetryCount = 0;
            this.connectFinished = 0;
            this.lastConnectError = 0;
            if (p2 != null) {
                p2.onConnecting();
            }
            this.startConnectGatt();
            return;
        } else {
            System.out.println("LuxPower - BLE connect ignored");
            return;
        }
    }

    public void forceDisconnect()
    {
        this.gattRetryScheduled = 0;
        this.connectFinished = 1;
        android.bluetooth.BluetoothGatt v0_2 = this.bleHandler;
        if (v0_2 != null) {
            v0_2.removeCallbacksAndMessages(0);
        }
        this.closeGattSafely(this.bluetoothGatt);
        return;
    }

    public String getCommandWaitResult(String p2)
    {
        return ((String) this.commandWaitMap.get(p2));
    }

    public boolean initialize(boolean p7)
    {
        System.out.println(new StringBuilder("LuxPower - ble - initialize, connected=").append(this.connected).append(", connecting=").append(this.connecting).append(", retryScheduled=").append(this.gattRetryScheduled).append(", retryCount=").append(this.gattRetryCount).append(", connectFinished=").append(this.connectFinished).toString());
        if (!this.connected) {
            int v3_3 = 0;
            if ((!this.connecting) && ((this.bluetoothGatt == null) && (!this.gattRetryScheduled))) {
                this.gattRetryCount = 0;
                this.connectFinished = 0;
                this.lastConnectError = 0;
                this.connect();
            }
            if (android.os.Looper.myLooper() != android.os.Looper.getMainLooper()) {
                if (!p7) {
                    return this.connected;
                }
                while (v3_3 < 600) {
                    if (!this.connected) {
                        if (this.connectFinished) {
                            break;
                        }
                        com.lux.luxcloud.tool.Tool.sleep(100);
                        v3_3++;
                    } else {
                        return 1;
                    }
                }
                System.out.println(new StringBuilder("LuxPower - ble - initialize finished, connected=").append(this.connected).append(", retryCount=").append(this.gattRetryCount).append(", error=").append(this.lastConnectError).toString());
                return this.connected;
            } else {
                System.out.println("LuxPower - ble - initialize called on main thread, skip sync wait");
                return this.connected;
            }
        } else {
            return 1;
        }
    }

    public void initializeAsync(com.lux.luxcloud.connect.ble.InitCallback p2)
    {
        if (!this.connected) {
            if ((!this.connecting) && (!this.gattRetryScheduled)) {
                this.gattRetryCount = 0;
                this.connectFinished = 0;
                this.lastConnectError = 0;
                this.connect(new com.lux.luxcloud.connect.ble.BluetoothLocalConnect$1(this, p2));
            }
        } else {
            if (p2 != null) {
                p2.onSuccess();
                return;
            }
        }
        return;
    }

    public void putCommandWaitMap(String p2, String p3)
    {
        this.commandWaitMap.put(p2, p3);
        return;
    }

    public String sendCommand(String p2, com.lux.luxcloud.protocol.tcp.dataframe.DataFrame p3)
    {
        return this.sendCommand(p2, p3, 4);
    }

    public String sendCommand(String p3, com.lux.luxcloud.protocol.tcp.dataframe.DataFrame p4, int p5)
    {
        try {
            this.commandWaitMap.put(p3, "");
        } catch (int v4_1) {
            v4_1.printStackTrace();
            this.commandWaitMap.remove(p3);
            return 0;
        } catch (int v4_2) {
            this.commandWaitMap.remove(p3);
            throw v4_2;
        }
        if (!this.sendPureCommand(p4)) {
            this.commandWaitMap.remove(p3);
            return 0;
        } else {
            int v4_4 = 0;
            while (v4_4 < (p5 * 5)) {
                com.lux.luxcloud.tool.Tool.sleep(200);
                if (com.lux.luxcloud.tool.Tool.isEmpty(((String) this.commandWaitMap.get(p3)))) {
                    v4_4++;
                } else {
                    int v4_7 = ((String) this.commandWaitMap.get(p3));
                    this.commandWaitMap.remove(p3);
                    this.commandWaitMap.remove(p3);
                    return v4_7;
                }
            }
            this.commandWaitMap.remove(p3);
            return 0;
        }
    }

    public boolean sendPureCommand(com.lux.luxcloud.protocol.tcp.dataframe.DataFrame p7)
    {
        if ((this.connected) && ((this.bluetoothGatt != null) && (this.writeCharacteristic != null))) {
            String v0_2;
            Throwable v7_7 = p7.getFrame();
            this.writeCharacteristic.setWriteType(1);
            if (this.currentChunkSize <= 0) {
                v0_2 = 20;
            } else {
                v0_2 = this.currentChunkSize;
            }
            int v3 = 0;
            while (v3 < v7_7.length) {
                long v4_3 = Math.min(v0_2, (v7_7.length - v3));
                android.bluetooth.BluetoothGattCharacteristic v5_0 = new byte[v4_3];
                System.arraycopy(v7_7, v3, v5_0, 0, v4_3);
                this.writeCharacteristic.setValue(v5_0);
                if (this.bluetoothGatt.writeCharacteristic(this.writeCharacteristic)) {
                    this.wait(300);
                    v3 += v0_2;
                } else {
                    System.err.println("LuxPower - ble - writeCharacteristic returned false");
                    return 0;
                }
            }
            System.out.println("LuxPower - ble - writeCharacteristicValue DONE");
            return 1;
        } else {
            System.err.println("LuxPower - ble - sendPureCommand failed: BLE not ready");
            return 0;
        }
    }

    public boolean startMonitor()
    {
        return 0;
    }
}
