package com.lux.luxcloud.global.bean.param;
final enum class PARAM$218 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$218(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$218(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p6)
    {
        int v6_5;
        p6.getRole();
        boolean v0_0 = p6.getCurrentInverter();
        boolean v1_11 = com.lux.luxcloud.global.GlobalInfo.getInstance().getCurrentClusterGroup();
        if ((!p6.isEnergy100User()) || ((!"firstCluster".equals(v1_11)) || ((v0_0.getDtcValue() != 0) && ((!v0_0.isHybird()) && ((!v0_0.isSnaSeriesOrGeta()) && ((!v0_0.isSna2_12k_EU()) && (!v0_0.isSna2_12k_EU_lt()))))))) {
            if ((!v0_0.isSnaSeriesOrGeta()) && ((!v0_0.isGen3Series()) && (!v0_0.isFlexSeries()))) {
                if (!v0_0.isMega24K()) {
                    if ((!v0_0.isType6Series()) && (!v0_0.isMidBoxWithOutEQB())) {
                        return 0;
                    } else {
                        if ((!v0_0.isFlexBoss100()) && (v0_0.getMachineType() == 0)) {
                            return 0;
                        }
                    }
                } else {
                    v6_5 = this.isViewer(p6);
                    return (v6_5 ^ 1);
                }
            }
            return 1;
        } else {
            if ((v0_0.getMachineType() != 1) || ((v0_0.isFlexSeries()) || ((v0_0.isGen2_7_14K()) || (v0_0.isGenUs13_16K())))) {
                v6_5 = this.isViewer(p6);
            } else {
                return 0;
            }
        }
        return (v6_5 ^ 1);
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131886292;
    }
}
