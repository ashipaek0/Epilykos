package com.lux.luxcloud.global.bean.param;
final enum class PARAM$366 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$366(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$366(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p3)
    {
        if (!p3.getCurrentInverter().isMidBox()) {
            return 0;
        } else {
            if ((!this.isAdmin(p3)) && (!this.isMAINTAIN(p3))) {
                return 0;
            } else {
                return 1;
            }
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        if (!p1.isEQB()) {
            return 2131886642;
        } else {
            return 2131886640;
        }
    }
}
