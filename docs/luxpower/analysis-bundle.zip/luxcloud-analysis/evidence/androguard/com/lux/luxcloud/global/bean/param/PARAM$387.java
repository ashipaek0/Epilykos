package com.lux.luxcloud.global.bean.param;
final enum class PARAM$387 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$387(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$387(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p6)
    {
        boolean v6_2;
        int v0_0 = p6.getCurrentInverter();
        if (v0_0.getDeviceTypeValue() != 2) {
            if ((v0_0.isAcCharger()) || (v0_0.isHybird())) {
                if ((v0_0.getDeviceTypeValue() != 0) || (v0_0.isPhase3())) {
                    return 1;
                } else {
                    int v1_3 = v0_0.getStandard();
                    int v2_0 = v0_0.getSlaveVersionValue();
                    int v0_1 = v0_0.getFwVersionValue();
                    if (((("AAAA".equals(v1_3)) || ("aAAA".equals(v1_3))) && ((v2_0 >= 36) && (v0_1 >= 32))) || ((("AAAB".equals(v1_3)) || ("aAAB".equals(v1_3))) && ((v2_0 >= 29) && (v0_1 >= 26)))) {
                        v6_2 = this.isViewer(p6);
                        return (v6_2 ^ 1);
                    }
                }
            }
            return 0;
        } else {
            v6_2 = this.isViewer(p6);
        }
        return (v6_2 ^ 1);
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887113;
    }
}
