package com.lux.luxcloud.connect.ble;
public final synthetic class BleManager$$ExternalSyntheticLambda1 implements java.lang.Runnable {
    public final synthetic com.lux.luxcloud.connect.ble.BleManager f$0;
    public final synthetic long f$1;
    public final synthetic java.util.concurrent.atomic.AtomicBoolean f$2;
    public final synthetic com.lux.luxcloud.connect.ble.BleScanCallback f$3;

    public synthetic BleManager$$ExternalSyntheticLambda1(com.lux.luxcloud.connect.ble.BleManager p1, long p2, java.util.concurrent.atomic.AtomicBoolean p4, com.lux.luxcloud.connect.ble.BleScanCallback p5)
    {
        this.f$0 = p1;
        this.f$1 = p2;
        this.f$2 = p4;
        this.f$3 = p5;
        return;
    }

    public final void run()
    {
        com.lux.luxcloud.connect.ble.BleManager.$r8$lambda$_xjziSIVGakAzo6JlTzIYho5M9s(this.f$0, this.f$1, this.f$2, this.f$3);
        return;
    }
}
