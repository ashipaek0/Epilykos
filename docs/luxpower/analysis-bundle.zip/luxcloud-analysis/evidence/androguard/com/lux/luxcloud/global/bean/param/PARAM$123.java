package com.lux.luxcloud.global.bean.param;
final enum class PARAM$123 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$123(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$123(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p3)
    {
        com.lux.luxcloud.global.bean.user.ROLE v0_0 = p3.getCurrentInverter();
        if ((!v0_0.isSnaSeriesOrGeta()) && (!v0_0.isGen3Series())) {
            return 0;
        } else {
            return (com.lux.luxcloud.global.bean.user.ROLE.VIEWER.equals(p3.getRole()) ^ 1);
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887381;
    }

    public int getStartRegister()
    {
        return 151;
    }
}
