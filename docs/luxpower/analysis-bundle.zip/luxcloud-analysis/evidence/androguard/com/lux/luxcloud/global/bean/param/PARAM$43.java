package com.lux.luxcloud.global.bean.param;
final enum class PARAM$43 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$43(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$43(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p4)
    {
        boolean v0_0 = p4.getCurrentInverter();
        if ((!v0_0.isType6Series()) && ((!v0_0.isGen3Series()) && ((!v0_0.isMidBox()) && ((!v0_0.isGeta()) && ((!v0_0.isSnaSeries()) && ((!v0_0.isAcCharger()) && (!v0_0.isHybird()))))))) {
            return 0;
        } else {
            if ((this.isViewer(p4)) || (p4.getRole().getInstallerLevelCheck())) {
                return 0;
            } else {
                return 1;
            }
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return 2131886633;
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return -1;
    }

    public int getStartRegister()
    {
        return 62;
    }
}
