package com.lux.luxcloud.global.bean.param;
final enum class PARAM$103 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$103(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$103(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p5)
    {
        boolean v0_0 = p5.getCurrentInverter();
        if (!v0_0.isGen3Series()) {
            if (!v0_0.isSnaSeries()) {
                if ((!v0_0.isHybird()) && (!v0_0.isAcCharger())) {
                    if ((!v0_0.isType6Series()) || (v0_0.isAllInOne())) {
                        return 0;
                    } else {
                        boolean v5_1 = this.isViewer(p5);
                    }
                } else {
                    v5_1 = this.isViewer(p5);
                }
                return (v5_1 ^ 1);
            } else {
                if ((this.isViewer(p5)) && (!this.isEg4(p5))) {
                    return 0;
                } else {
                    return 1;
                }
            }
        } else {
            return 1;
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return 2131886636;
    }

    public Object getPlatformSpecificData(com.lux.luxcloud.global.UserData p19, android.content.Context p20)
    {
        int v2_8 = p19.getCurrentInverter();
        if (!com.lux.luxcloud.global.bean.user.PLATFORM.LUX_POWER.equals(p19.getPlatform())) {
            if (!com.lux.luxcloud.global.bean.user.PLATFORM.EG4.equals(p19.getPlatform())) {
                return 0;
            } else {
                if (!v2_8.isTrip12K()) {
                    if (((!v2_8.is7_10KDevice()) || (v2_8.getPhaseValue().intValue() == 1)) && (!v2_8.isGen3_6K())) {
                        if (!v2_8.isAcCharger()) {
                            if (!v2_8.isSnaSeriesOrGetaOrGen3()) {
                                String[] v3_29 = new String[4];
                                v3_29[0] = p20.getString(2131887511);
                                v3_29[1] = p20.getString(2131887513);
                                v3_29[2] = p20.getString(2131887515);
                                v3_29[3] = p20.getString(2131887517);
                                org.json.JSONObject v1_27 = new String[4];
                                v1_27[0] = "1";
                                v1_27[1] = "2";
                                v1_27[2] = "3";
                                v1_27[3] = "4";
                                return this.createDropdown(v3_29, v1_27);
                            } else {
                                int v2_11 = new String[3];
                                v2_11[0] = p20.getString(2131887518);
                                v2_11[1] = p20.getString(2131887519);
                                v2_11[2] = p20.getString(2131887521);
                                org.json.JSONObject v1_30 = new String[3];
                                v1_30[0] = "0";
                                v1_30[1] = "1";
                                v1_30[2] = "3";
                                return this.createDropdown(v2_11, v1_30);
                            }
                        } else {
                            int v2_12 = new String[3];
                            v2_12[0] = p20.getString(2131887511);
                            v2_12[1] = p20.getString(2131887513);
                            v2_12[2] = p20.getString(2131887515);
                            org.json.JSONObject v1_2 = new String[3];
                            v1_2[0] = "1";
                            v1_2[1] = "2";
                            v1_2[2] = "3";
                            return this.createDropdown(v2_12, v1_2);
                        }
                    } else {
                        int v2_0 = new String[3];
                        v2_0[0] = p20.getString(2131887511);
                        v2_0[1] = p20.getString(2131887513);
                        v2_0[2] = p20.getString(2131887515);
                        org.json.JSONObject v1_5 = new String[3];
                        v1_5[0] = "1";
                        v1_5[1] = "2";
                        v1_5[2] = "3";
                        return this.createDropdown(v2_0, v1_5);
                    }
                } else {
                    int v2_1 = new String[2];
                    v2_1[0] = p20.getString(2131887512);
                    v2_1[1] = p20.getString(2131887513);
                    org.json.JSONObject v1_8 = new String[2];
                    v1_8[0] = "3";
                    v1_8[1] = "2";
                    return this.createDropdown(v2_1, v1_8);
                }
            }
        } else {
            if (!v2_8.isTrip12K()) {
                if (((!v2_8.is7_10KDevice()) || (v2_8.getPhaseValue().intValue() == 1)) && (!v2_8.isGen3_6K())) {
                    if (!v2_8.isAcCharger()) {
                        if (!v2_8.isSnaSeriesOrGetaOrGen3()) {
                            String[] v3_10 = new String[4];
                            v3_10[0] = p20.getString(2131887511);
                            v3_10[1] = p20.getString(2131887513);
                            v3_10[2] = p20.getString(2131887515);
                            v3_10[3] = p20.getString(2131887517);
                            org.json.JSONObject v1_11 = new String[4];
                            v1_11[0] = "1";
                            v1_11[1] = "2";
                            v1_11[2] = "3";
                            v1_11[3] = "4";
                            return this.createDropdown(v3_10, v1_11);
                        } else {
                            int v2_4 = new String[3];
                            v2_4[0] = p20.getString(2131887518);
                            v2_4[1] = p20.getString(2131887519);
                            v2_4[2] = p20.getString(2131887521);
                            org.json.JSONObject v1_14 = new String[3];
                            v1_14[0] = "0";
                            v1_14[1] = "1";
                            v1_14[2] = "3";
                            return this.createDropdown(v2_4, v1_14);
                        }
                    } else {
                        int v2_5 = new String[3];
                        v2_5[0] = p20.getString(2131887511);
                        v2_5[1] = p20.getString(2131887513);
                        v2_5[2] = p20.getString(2131887515);
                        org.json.JSONObject v1_17 = new String[3];
                        v1_17[0] = "1";
                        v1_17[1] = "2";
                        v1_17[2] = "3";
                        return this.createDropdown(v2_5, v1_17);
                    }
                } else {
                    int v2_6 = new String[3];
                    v2_6[0] = p20.getString(2131887511);
                    v2_6[1] = p20.getString(2131887513);
                    v2_6[2] = p20.getString(2131887515);
                    org.json.JSONObject v1_20 = new String[3];
                    v1_20[0] = "0";
                    v1_20[1] = "1";
                    v1_20[2] = "3";
                    return this.createDropdown(v2_6, v1_20);
                }
            } else {
                int v2_7 = new String[2];
                v2_7[0] = p20.getString(2131887512);
                v2_7[1] = p20.getString(2131887513);
                org.json.JSONObject v1_23 = new String[2];
                v1_23[0] = "3";
                v1_23[1] = "2";
                return this.createDropdown(v2_7, v1_23);
            }
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887508;
    }

    public int getStartRegister()
    {
        return 112;
    }
}
