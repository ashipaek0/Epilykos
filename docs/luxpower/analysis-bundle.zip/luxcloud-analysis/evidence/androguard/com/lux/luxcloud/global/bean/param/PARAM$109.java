package com.lux.luxcloud.global.bean.param;
final enum class PARAM$109 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$109(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$109(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    private android.util.Pair getLithiumOptions_12KSeries_NA(com.lux.luxcloud.global.UserData p5, android.content.Context p6)
    {
        android.util.Pair v5_1 = p5.getCurrentInverter();
        String[] v0_1 = new java.util.ArrayList();
        java.util.ArrayList v1_1 = new java.util.ArrayList();
        v0_1.add(new StringBuilder("-1: ").append(p6.getString(2131887062)).toString());
        v1_1.add("-1");
        v0_1.add("0: Standard/Pytes/EG4/BSL/Stackrack/Ampace/BigBattery");
        v1_1.add("0");
        v0_1.add("1: HINAESS");
        v1_1.add("1");
        v0_1.add("2: Pylon/UZ Energy/Shoto/Hubble/FreedomWon/BlueNova");
        v1_1.add("2");
        v0_1.add("3: Rsvd");
        v1_1.add("3");
        v0_1.add("4: GSL Energy");
        v1_1.add("4");
        v0_1.add("5: Luxpower/Meritsun");
        v1_1.add("5");
        String[] v6_2 = 6;
        while (v6_2 <= 18) {
            String[] v2_5;
            if (v6_2 != 14) {
                v2_5 = new StringBuilder().append(v6_2).append(": Rsvd").toString();
            } else {
                v2_5 = "14: Green Battery";
            }
            v0_1.add(v2_5);
            v1_1.add(String.valueOf(v6_2));
            v6_2++;
        }
        android.util.Pair v5_5;
        v0_1.add("18: Fortress");
        v1_1.add("18");
        String[] v6_21 = new StringBuilder("19: ");
        if ((v5_1.getDeviceType().intValue() != 8) && (v5_1.getDeviceType().intValue() != 10)) {
            v5_5 = "Sunwoda/Renogy";
        } else {
            v5_5 = "CROWN";
        }
        v0_1.add(v6_21.append(v5_5).toString());
        v1_1.add("19");
        v0_1.add("20: Aobo");
        v1_1.add("20");
        v0_1.add("21: Weco");
        v1_1.add("21");
        v0_1.add("22: Vero Electric");
        v1_1.add("22");
        v0_1.add("28: Gotion");
        v1_1.add("28");
        String[] v2_14 = new String[0];
        String[] v6_23 = new String[0];
        return new android.util.Pair(((String[]) v0_1.toArray(v2_14)), ((String[]) v1_1.toArray(v6_23)));
    }

    private android.util.Pair getLithiumOptions_12KSeries_Normal(com.lux.luxcloud.global.UserData p18, android.content.Context p19)
    {
        String[] v1_4 = p18.getCurrentInverter();
        String[] v2_3 = new java.util.ArrayList();
        java.util.ArrayList v3_1 = new java.util.ArrayList();
        com.lux.luxcloud.global.bean.inverter.Inverter v16 = v1_4;
        if (!v1_4.isMega24K()) {
            v2_3.add(new StringBuilder("-1: ").append(p19.getString(2131887062)).toString());
            v3_1.add("-1");
            v2_3.add("0: Standard/Pytes/EG4/BSL/Stackrack/Ampace/BigBattery");
            v3_1.add("0");
            v2_3.add("1: HINAESS");
            v3_1.add("1");
            v2_3.add("2: Pylon/UZ Energy/Shoto/Hubble/FreedomWon/BlueNova");
            v3_1.add("2");
            v2_3.add("3: Rsvd");
            v3_1.add("3");
            v2_3.add("4: GSL Energy");
            v3_1.add("4");
            v2_3.add("5: Luxpower/Meritsun/LSSA/HANCHU");
            v3_1.add("5");
            android.util.Pair v0_1 = 6;
            while (v0_1 <= 18) {
                String[] v4_2;
                if (v0_1 != 14) {
                    v4_2 = new StringBuilder().append(v0_1).append(": Rsvd").toString();
                } else {
                    v4_2 = "14: Green Battery";
                }
                v2_3.add(v4_2);
                v3_1.add(String.valueOf(v0_1));
                v0_1++;
            }
            String[] v4_29;
            v2_3.add("18: Fortress");
            v3_1.add("18");
            android.util.Pair v0_30 = new StringBuilder("19: ");
            if ((v16.getDeviceType().intValue() != 8) && (v16.getDeviceType().intValue() != 10)) {
                v4_29 = "Sunwoda/Renogy";
            } else {
                v4_29 = "CROWN";
            }
            v2_3.add(v0_30.append(v4_29).toString());
            v3_1.add("19");
            v2_3.add("20: Aobo");
            v3_1.add("20");
            v2_3.add("21: Weco");
            v3_1.add("21");
            v2_3.add("22: Vero Electric");
            v3_1.add("22");
            v2_3.add("28: Gotion");
            v3_1.add("28");
        } else {
            v2_3.add(new StringBuilder("-1: ").append(p19.getString(2131887062)).toString());
            v3_1.add("-1");
            v2_3.add("0: Rsvd");
            v3_1.add("0");
            v2_3.add("1: Rsvd");
            v3_1.add("1");
            v2_3.add("2: Rsvd");
            v3_1.add("2");
            v2_3.add("3: Rsvd");
            v3_1.add("3");
            v2_3.add("4: Rsvd");
            v3_1.add("4");
            v2_3.add("5: Rsvd");
            v3_1.add("5");
            v2_3.add("6: Luxpower / HINAESS");
            v3_1.add("6");
            android.util.Pair v0_12 = 7;
            while (v0_12 <= 21) {
                if (v0_12 != 9) {
                    v2_3.add(new StringBuilder().append(v0_12).append(": Rsvd").toString());
                    v3_1.add(String.valueOf(v0_12));
                } else {
                    v2_3.add(new StringBuilder().append(v0_12).append(": Zetara").toString());
                    v3_1.add(String.valueOf(v0_12));
                }
                v0_12++;
            }
            if (!this.isEg4(p18)) {
                v2_3.add("22: Rsvd");
                v3_1.add("22");
            } else {
                v2_3.add("22: BRIGGS");
                v3_1.add("22");
            }
            v2_3.add("28: Rsvd");
            v3_1.add("28");
        }
        String[] v4_7 = new String[0];
        String[] v1_1 = new String[0];
        return new android.util.Pair(((String[]) v2_3.toArray(v4_7)), ((String[]) v3_1.toArray(v1_1)));
    }

    private android.util.Pair getLithiumOptions_AllInOne(com.lux.luxcloud.global.UserData p4, android.content.Context p5)
    {
        String[] v4_1 = new java.util.ArrayList();
        String[] v0_1 = new java.util.ArrayList();
        v4_1.add(new StringBuilder("-1: ").append(p5.getString(2131887062)).toString());
        v0_1.add("-1");
        v4_1.add("0: Rsvd");
        v0_1.add("0");
        v4_1.add("1: HINAESS");
        v0_1.add("1");
        v4_1.add("2: Rsvd");
        v0_1.add("2");
        v4_1.add("3: Rsvd");
        v0_1.add("3");
        v4_1.add("4: ATL");
        v0_1.add("4");
        v4_1.add("5: GSL");
        v0_1.add("5");
        v4_1.add("6: Luxpower");
        v0_1.add("6");
        android.util.Pair v5_18 = 7;
        while (v5_18 <= 21) {
            v4_1.add(new StringBuilder().append(v5_18).append(": Rsvd").toString());
            v0_1.add(String.valueOf(v5_18));
            v5_18++;
        }
        String[] v2_1 = new String[0];
        String[] v1_3 = new String[0];
        return new android.util.Pair(((String[]) v4_1.toArray(v2_1)), ((String[]) v0_1.toArray(v1_3)));
    }

    private android.util.Pair getLithiumOptions_Hybrid(com.lux.luxcloud.global.UserData p6, android.content.Context p7)
    {
        android.util.Pair v6_16;
        String[] v0_0 = p6.getCurrentInverter();
        java.util.ArrayList v1_1 = new java.util.ArrayList();
        java.util.ArrayList v2_1 = new java.util.ArrayList();
        v1_1.add(new StringBuilder("-1: ").append(p7.getString(2131887062)).toString());
        v2_1.add("-1");
        v1_1.add("0: Standard Battery");
        v2_1.add("0");
        v1_1.add("1: HINA Battery");
        v2_1.add("1");
        v1_1.add("2: Pylon/Freedom Won/Solar MD/Hubble/Blue Nova");
        v2_1.add("2");
        v1_1.add("3: Enopte");
        v2_1.add("3");
        v1_1.add("4: MSUN");
        v2_1.add("4");
        v1_1.add("5: GSL1 Battery");
        v2_1.add("5");
        if (!p6.isGigabiz1User()) {
            v6_16 = "Luxpower";
        } else {
            v6_16 = "LUX / HANCHU";
        }
        android.util.Pair v6_23;
        v1_1.add("6: ".concat(v6_16));
        v2_1.add("6");
        v1_1.add("7: Aobo Battery");
        v2_1.add("7");
        if (v0_0.getDeviceType().intValue() != 4) {
            v6_23 = "Rsvd";
        } else {
            v6_23 = "Dyness";
        }
        v1_1.add("8: ".concat(v6_23));
        v2_1.add("8");
        v1_1.add("9: Stealth");
        v2_1.add("9");
        v1_1.add("10: TeLongMei");
        v2_1.add("10");
        v1_1.add("11: Merit");
        v2_1.add("11");
        v1_1.add("14: WECO");
        v2_1.add("14");
        v1_1.add("15: Murata");
        v2_1.add("15");
        v1_1.add("16: BITEK");
        v2_1.add("16");
        v1_1.add("17: OKSolar");
        v2_1.add("17");
        v1_1.add("18: GW Battery");
        v2_1.add("18");
        if (v0_0.getDeviceType().intValue() == 10) {
            v1_1.add("19: CROWN");
            v2_1.add("19");
        }
        v1_1.add("20: Revov");
        v2_1.add("20");
        v1_1.add("21: Beebeejump");
        v2_1.add("21");
        v1_1.add("28: Gotion");
        v2_1.add("28");
        String[] v0_1 = new String[0];
        String[] v7_5 = new String[0];
        return new android.util.Pair(((String[]) v1_1.toArray(v0_1)), ((String[]) v2_1.toArray(v7_5)));
    }

    private android.util.Pair getLithiumOptions_SNA(com.lux.luxcloud.global.UserData p30, android.content.Context p31)
    {
        String v0_0 = p30.getCurrentInverter();
        String[] v1_3 = new java.util.ArrayList();
        String[] v2_3 = new java.util.ArrayList();
        p31 = v0_0;
        if (com.lux.luxcloud.global.bean.user.PLATFORM.EG4.equals(p30.getPlatform())) {
            v1_3.add("0: EG4");
            v2_3.add("0");
            v1_3.add("1");
            v2_3.add("1");
            v1_3.add("2");
            v2_3.add("2");
            v1_3.add("3");
            v2_3.add("3");
            v1_3.add("4");
            v2_3.add("4");
            v1_3.add("5");
            v2_3.add("5");
            v1_3.add("6");
            v2_3.add("6");
            v1_3.add("7");
            v2_3.add("7");
            v1_3.add("8");
            v2_3.add("8");
            v1_3.add("9");
            v2_3.add("9");
            v1_3.add("10");
            v2_3.add("10");
            v1_3.add("11");
            v2_3.add("11");
            v1_3.add("14");
            v2_3.add("14");
            v1_3.add("15");
            v2_3.add("15");
            v1_3.add("16");
            v2_3.add("16");
            v1_3.add("17");
            v2_3.add("17");
            v1_3.add("18");
            v2_3.add("18");
            v1_3.add("19");
            v2_3.add("19");
            v1_3.add("20");
            v2_3.add("20");
            v1_3.add("21");
            v2_3.add("21");
        } else {
            v1_3.add("0: Standard Battery");
            v2_3.add("0");
            v1_3.add("1: HINA Battery");
            v2_3.add("1");
            v1_3.add("2: Pylon/Freedom Won/Solar MD/Hubble/Blue Nova");
            v2_3.add("2");
            v1_3.add("3: Enopte");
            v2_3.add("3");
            v1_3.add("4: MSUN");
            v2_3.add("4");
            v1_3.add("5: GSL1 Battery");
            v2_3.add("5");
            if (!p30.isGigabiz1User()) {
                v1_3.add("6: Luxpower");
            } else {
                v1_3.add("6: LUX / HANCHU");
            }
            v2_3.add("6");
            v1_3.add("7: Aobo Battery");
            v2_3.add("7");
            if (p31.getDeviceType().intValue() != 4) {
                v1_3.add("8: Rsvd");
            } else {
                v1_3.add("8: Dyness");
            }
            v2_3.add("8");
            v1_3.add("9: Stealth");
            v2_3.add("9");
            v1_3.add("10: TeLongMei");
            v2_3.add("10");
            v1_3.add("11: Merit");
            v2_3.add("11");
            v1_3.add("14: WECO");
            v2_3.add("14");
            v1_3.add("15: Murata");
            v2_3.add("15");
            v1_3.add("16: BITEK");
            v2_3.add("16");
            v1_3.add("17: OKSolar");
            v2_3.add("17");
            v1_3.add("18: GW Battery");
            v2_3.add("18");
            v1_3.add("19: CROWN");
            v2_3.add("19");
            v1_3.add("20: Revov");
            v2_3.add("20");
            v1_3.add("21: Beebeejump");
            v2_3.add("21");
        }
        int v4_10 = new String[0];
        String v3_6 = new String[0];
        return new android.util.Pair(((String[]) v1_3.toArray(v4_10)), ((String[]) v2_3.toArray(v3_6)));
    }

    private android.util.Pair getLithiumOptions_Trip12K(com.lux.luxcloud.global.UserData p5, android.content.Context p6)
    {
        android.util.Pair v5_1;
        String[] v0_1 = new java.util.ArrayList();
        java.util.ArrayList v1_1 = new java.util.ArrayList();
        android.util.Pair v5_3 = p5.isGigabiz1User();
        v0_1.add(new StringBuilder("-1: ").append(p6.getString(2131887062)).toString());
        v1_1.add("-1");
        v0_1.add("0: Standard");
        v1_1.add("0");
        v0_1.add("1: HINAESS");
        v1_1.add("1");
        v0_1.add("2: Pylon");
        v1_1.add("2");
        v0_1.add("3: Rsvd");
        v1_1.add("3");
        v0_1.add("4: ATL");
        v1_1.add("4");
        v0_1.add("5: GSL");
        v1_1.add("5");
        if (v5_3 == null) {
            v5_1 = "Luxpower/Zetara/Aoboet";
        } else {
            v5_1 = "Luxpower/Aoboet/Hanchu";
        }
        v0_1.add("6: ".concat(v5_1));
        v1_1.add("6");
        android.util.Pair v5_5 = 7;
        while (v5_5 <= 21) {
            v0_1.add(new StringBuilder().append(v5_5).append(": Rsvd").toString());
            v1_1.add(String.valueOf(v5_5));
            v5_5++;
        }
        String[] v2_0 = new String[0];
        String[] v6_20 = new String[0];
        return new android.util.Pair(((String[]) v0_1.toArray(v2_0)), ((String[]) v1_1.toArray(v6_20)));
    }

    private android.util.Pair getLithiumOptions_US(com.lux.luxcloud.global.UserData p10, android.content.Context p11)
    {
        String[] v11_0 = p10.getCurrentInverter();
        String[] v0_4 = new java.util.ArrayList();
        java.util.ArrayList v1_1 = new java.util.ArrayList();
        if (((v11_0.getDeviceType().intValue() != 9) && (v11_0.getDeviceType().intValue() != 6)) || (v11_0.getPhase().intValue() != 1)) {
            String[] v11_10 = -1;
            while (v11_10 <= 21) {
                v0_4.add(new StringBuilder().append(v11_10).append(": ").append(v11_10).toString());
                v1_1.add(String.valueOf(v11_10));
                v11_10++;
            }
        } else {
            String[] v7 = new String[13];
            v7[0] = "-1";
            v7[1] = "0";
            v7[2] = "1";
            v7[3] = "2";
            v7[4] = "5";
            v7[5] = "6";
            v7[6] = "8";
            v7[7] = "11";
            v7[8] = "14";
            v7[9] = "18";
            v7[10] = "19";
            v7[11] = "20";
            v7[12] = "21";
            com.lux.luxcloud.global.bean.user.ROLE v2_1 = 0;
            while (v2_1 < 13) {
                String v4_1 = v7[v2_1];
                v0_4.add(new StringBuilder().append(v4_1).append(": ").append(v4_1).toString());
                v1_1.add(v4_1);
                v2_1++;
            }
        }
        if ((com.lux.luxcloud.global.bean.user.ROLE.ADMIN.equals(p10.getRole())) || (com.lux.luxcloud.global.bean.user.PLATFORM.EG4.equals(p10.getPlatform()))) {
            v0_4.add("22: 22");
            v1_1.add("22");
        }
        v0_4.add("28: Gotion");
        v1_1.add("28");
        if ((com.lux.luxcloud.global.bean.user.ROLE.ADMIN.equals(p10.getRole())) || (com.lux.luxcloud.global.bean.user.PLATFORM.EG4.equals(p10.getPlatform()))) {
            v0_4.add("30: Lithium no comms: 15 cells in series");
            v1_1.add("30");
            v0_4.add("31: Lithium no comms: 16 cells in series");
            v1_1.add("31");
        }
        String[] v11_5 = new String[0];
        String[] v0_0 = new String[0];
        return new android.util.Pair(((String[]) v0_4.toArray(v11_5)), ((String[]) v1_1.toArray(v0_0)));
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p6)
    {
        boolean v0_0 = p6.getCurrentInverter();
        if (!v0_0.isAllInOne()) {
            if ((this.isViewer(p6)) && ((!this.isEg4(p6)) && ((v0_0.getSlaveVersionValue() < 34) || ((v0_0.getFwVersionValue() < 18) || ((p6.isGigabiz1User()) && (this.isViewer(p6))))))) {
                return 0;
            } else {
                return 1;
            }
        } else {
            if ((!this.isAdmin(p6)) && (!com.lux.luxcloud.global.bean.user.PLATFORM.GTEC.equals(p6.getPlatform()))) {
                return 0;
            } else {
                return 1;
            }
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        if (!p1.getCurrentInverter().isSnaSeriesOrGeta()) {
            return 2131886780;
        } else {
            return 2131886779;
        }
    }

    public Object getPlatformSpecificData(com.lux.luxcloud.global.UserData p6, android.content.Context p7)
    {
        android.util.Pair v6_1;
        boolean v0_0 = p6.getCurrentInverter();
        System.out.println(new StringBuilder("MODEL_BIT_LITHIUM_TYPE == ").append(com.lux.luxcloud.global.GlobalInfo.getDefaultClusterId()).toString());
        if (!v0_0.isTrip12K()) {
            if (!com.lux.luxcloud.global.bean.user.PLATFORM.EG4.equals(p6.getPlatform())) {
                if (!v0_0.isAllInOne()) {
                    if (com.lux.luxcloud.global.GlobalInfo.getDefaultClusterId() != 4) {
                        if ((!v0_0.isGen3_6K()) && (!v0_0.isAcCharger())) {
                            if (!v0_0.isSnaSeries()) {
                                v6_1 = this.getLithiumOptions_12KSeries_Normal(p6, p7);
                            } else {
                                v6_1 = this.getLithiumOptions_SNA(p6, p7);
                            }
                        } else {
                            v6_1 = this.getLithiumOptions_Hybrid(p6, p7);
                        }
                    } else {
                        v6_1 = this.getLithiumOptions_12KSeries_NA(p6, p7);
                    }
                } else {
                    v6_1 = this.getLithiumOptions_AllInOne(p6, p7);
                }
            } else {
                v6_1 = this.getLithiumOptions_US(p6, p7);
            }
        } else {
            v6_1 = this.getLithiumOptions_Trip12K(p6, p7);
        }
        return this.createDropdown(((String[]) v6_1.first), ((String[]) v6_1.second));
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131886147;
    }
}
