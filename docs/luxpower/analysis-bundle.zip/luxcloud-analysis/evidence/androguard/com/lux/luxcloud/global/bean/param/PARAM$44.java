package com.lux.luxcloud.global.bean.param;
final enum class PARAM$44 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$44(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$44(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p6)
    {
        boolean v0_0 = p6.getRole();
        boolean v1_2 = p6.getCurrentInverter();
        if (((!v1_2.isType6Series()) && (!v1_2.isGen3Series())) || (v1_2.isAllInOne())) {
            if ((!v1_2.isAcCharger()) && ((!v1_2.isHybird()) && (!v1_2.isSnaSeries()))) {
                if ((!v1_2.isMidBox()) || ((this.isViewer(p6)) || ((v0_0.getInstallerLevelCheck()) && (p6.isEuropeSonnePvInstaller())))) {
                    return 0;
                } else {
                    return 1;
                }
            } else {
                if ((this.isViewer(p6)) || ((v0_0.getInstallerLevelCheck()) && (p6.isEuropeSonnePvInstaller()))) {
                    return 0;
                } else {
                    return 1;
                }
            }
        } else {
            if ((this.isViewer(p6)) || ((v0_0.getInstallerLevelCheck()) && (p6.isEuropeSonnePvInstaller()))) {
                return 0;
            } else {
                return 1;
            }
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return 2131886851;
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887270;
    }

    public int getStartRegister()
    {
        return 63;
    }
}
