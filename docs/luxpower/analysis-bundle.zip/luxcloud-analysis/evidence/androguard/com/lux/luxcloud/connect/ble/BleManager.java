package com.lux.luxcloud.connect.ble;
public class BleManager extends com.lux.luxcloud.connect.AbstractLocalConnect {
    private static final com.lux.luxcloud.connect.ble.BleManager instance;
    private android.content.Context appContext;
    private com.lux.luxcloud.connect.ble.BleAction bleAction;
    private android.bluetooth.le.BluetoothLeScanner bleScanner;
    private android.bluetooth.BluetoothAdapter bluetoothAdapter;
    private com.lux.luxcloud.connect.ble.BluetoothLocalConnect bluetoothLocalConnect;
    private android.bluetooth.le.ScanCallback scanCallback;

    public static synthetic void $r8$lambda$_xjziSIVGakAzo6JlTzIYho5M9s(com.lux.luxcloud.connect.ble.BleManager p0, long p1, java.util.concurrent.atomic.AtomicBoolean p3, com.lux.luxcloud.connect.ble.BleScanCallback p4)
    {
        p0.lambda$scanAndBindByNameAsync$0(p1, p3, p4);
        return;
    }

    public static synthetic void $r8$lambda$vNdVIKtFybsnYLeLIWKFsOWQKak(com.lux.luxcloud.connect.ble.BleManager p0, long p1, android.bluetooth.le.ScanCallback p3, com.lux.luxcloud.connect.ble.BleManager$ScanFinishCallback p4)
    {
        p0.lambda$scanAllDevicesAsync$1(p1, p3, p4);
        return;
    }

    static bridge synthetic android.bluetooth.le.BluetoothLeScanner -$$Nest$fgetbleScanner(com.lux.luxcloud.connect.ble.BleManager p0)
    {
        return p0.bleScanner;
    }

    static bridge synthetic void -$$Nest$mbind(com.lux.luxcloud.connect.ble.BleManager p0, android.bluetooth.BluetoothDevice p1)
    {
        p0.bind(p1);
        return;
    }

    static BleManager()
    {
        com.lux.luxcloud.connect.ble.BleManager.instance = new com.lux.luxcloud.connect.ble.BleManager();
        return;
    }

    private BleManager()
    {
        super("bluetooth");
        return;
    }

    static synthetic boolean access$002(com.lux.luxcloud.connect.ble.BleManager p0, boolean p1)
    {
        p0.connected = p1;
        return p1;
    }

    private void bind(android.bluetooth.BluetoothDevice p3)
    {
        this.bluetoothLocalConnect = new com.lux.luxcloud.connect.ble.BluetoothLocalConnect(this.bleAction, p3);
        return;
    }

    public static com.lux.luxcloud.connect.ble.BleManager getInstance()
    {
        return com.lux.luxcloud.connect.ble.BleManager.instance;
    }

    private void initBleScanner()
    {
        if (this.bluetoothAdapter == null) {
            android.bluetooth.le.BluetoothLeScanner v0_2 = this.appContext;
            if (v0_2 != null) {
                android.bluetooth.le.BluetoothLeScanner v0_5 = ((android.bluetooth.BluetoothManager) v0_2.getSystemService("bluetooth")).getAdapter();
                this.bluetoothAdapter = v0_5;
                this.bleScanner = v0_5.getBluetoothLeScanner();
            }
        }
        return;
    }

    private synthetic void lambda$scanAllDevicesAsync$1(long p1, android.bluetooth.le.ScanCallback p3, com.lux.luxcloud.connect.ble.BleManager$ScanFinishCallback p4)
    {
        com.lux.luxcloud.tool.Tool.sleep(p1);
        this.bleScanner.stopScan(p3);
        if (p4 != null) {
            p4.onFinish();
        }
        return;
    }

    private synthetic void lambda$scanAndBindByNameAsync$0(long p1, java.util.concurrent.atomic.AtomicBoolean p3, com.lux.luxcloud.connect.ble.BleScanCallback p4)
    {
        com.lux.luxcloud.tool.Tool.sleep(p1);
        if ((!this.connected) && ((!p3.get()) && (this.bluetoothLocalConnect == null))) {
            try {
                this.bleScanner.stopScan(this.scanCallback);
            } catch (Exception) {
            }
            p4.onScanTimeout();
        }
        return;
    }

    public void close()
    {
        System.out.println("LuxPower - BLE: close()");
        this.connected = 0;
        android.bluetooth.le.BluetoothLeScanner v0_3 = this.bluetoothLocalConnect;
        if (v0_3 != null) {
            v0_3.forceDisconnect();
            this.bluetoothLocalConnect = 0;
        }
        android.bluetooth.le.BluetoothLeScanner v0_1 = this.bleScanner;
        try {
            if (v0_1 != null) {
                android.bluetooth.le.ScanCallback v2 = this.scanCallback;
                if (v2 != null) {
                    v0_1.stopScan(v2);
                }
            }
        } catch (Exception) {
        }
        this.scanCallback = 0;
        return;
    }

    public String getCommandWaitResult(String p2)
    {
        com.lux.luxcloud.connect.ble.BluetoothLocalConnect v0 = this.bluetoothLocalConnect;
        if (v0 == null) {
            return 0;
        } else {
            return v0.getCommandWaitResult(p2);
        }
    }

    public boolean initialize(boolean p5)
    {
        try {
            if (!this.connected) {
                if (this.bluetoothLocalConnect != null) {
                    System.out.println("LuxPower - BLE: \u521d\u59cb\u5316 GATT \u8fde\u63a5\u4e2d...");
                    if (this.bluetoothLocalConnect.initialize(p5)) {
                        this.connected = 1;
                        System.out.println("LuxPower - BLE: GATT \u8fde\u63a5\u6210\u529f");
                        return 1;
                    }
                } else {
                    System.err.println("LuxPower - BLE: initialize \u65f6 bluetoothLocalConnect \u4e3a\u7a7a");
                    return 0;
                }
            } else {
                return 1;
            }
        } catch (java.io.PrintStream v5_4) {
            v5_4.printStackTrace();
        }
        return 0;
    }

    public void initializeAsync(com.lux.luxcloud.connect.ble.InitCallback p3)
    {
        try {
            if (!this.connected) {
                String v0_3 = this.bluetoothLocalConnect;
                if (v0_3 != null) {
                    v0_3.initializeAsync(new com.lux.luxcloud.connect.ble.BleManager$3(this, p3));
                    return;
                } else {
                    p3.onFail("connect is null");
                    return;
                }
            } else {
                p3.onSuccess();
                return;
            }
        } catch (String v0_1) {
            p3.onFail(v0_1.getMessage());
            return;
        }
    }

    public void scanAllDevicesAsync(long p8, com.lux.luxcloud.connect.ble.BleManager$DeviceFoundCallback p10, com.lux.luxcloud.connect.ble.BleManager$ScanFinishCallback p11)
    {
        if ((this.bleScanner != null) && (this.appContext != null)) {
            com.lux.luxcloud.connect.ble.BleManager$2 v5_1 = new com.lux.luxcloud.connect.ble.BleManager$2(this, p10, p11);
            this.bleScanner.startScan(v5_1);
            new Thread(new com.lux.luxcloud.connect.ble.BleManager$$ExternalSyntheticLambda0(this, p8, v5_1, p11)).start();
            return;
        } else {
            if (p11 != null) {
                p11.onFinish();
            }
            return;
        }
    }

    public void scanAndBindByNameAsync(String p9, long p10, com.lux.luxcloud.connect.ble.BleScanCallback p12)
    {
        if (this.bleScanner != null) {
            System.out.println(new StringBuilder("LuxPower - BLE: \u5f00\u59cb\u5f02\u6b65\u626b\u63cf\uff0c\u76ee\u6807\u540d\u79f0 = ").append(p9).toString());
            java.util.concurrent.atomic.AtomicBoolean v6_1 = new java.util.concurrent.atomic.AtomicBoolean(0);
            com.lux.luxcloud.connect.ble.BleManager$1 v0_3 = new com.lux.luxcloud.connect.ble.BleManager$1(this, p9, v6_1, p12);
            this.scanCallback = v0_3;
            this.bleScanner.startScan(v0_3);
            new Thread(new com.lux.luxcloud.connect.ble.BleManager$$ExternalSyntheticLambda1(this, p10, v6_1, p12)).start();
            return;
        } else {
            p12.onScanError("Scanner \u672a\u521d\u59cb\u5316\uff0c\u8bf7\u5148\u8c03\u7528 setContext()");
            return;
        }
    }

    public String sendCommand(String p2, com.lux.luxcloud.protocol.tcp.dataframe.DataFrame p3)
    {
        com.lux.luxcloud.connect.ble.BluetoothLocalConnect v0 = this.bluetoothLocalConnect;
        if (v0 == null) {
            return 0;
        } else {
            return v0.sendCommand(p2, p3);
        }
    }

    public String sendCommand(String p2, com.lux.luxcloud.protocol.tcp.dataframe.DataFrame p3, int p4)
    {
        com.lux.luxcloud.connect.ble.BluetoothLocalConnect v0 = this.bluetoothLocalConnect;
        if (v0 == null) {
            return 0;
        } else {
            return v0.sendCommand(p2, p3, p4);
        }
    }

    public boolean sendPureCommand(com.lux.luxcloud.protocol.tcp.dataframe.DataFrame p2)
    {
        com.lux.luxcloud.connect.ble.BluetoothLocalConnect v0 = this.bluetoothLocalConnect;
        if ((v0 == null) || (!v0.sendPureCommand(p2))) {
            return 0;
        } else {
            return 1;
        }
    }

    public void setContext(android.content.Context p1, com.lux.luxcloud.connect.ble.BleAction p2)
    {
        this.appContext = p1.getApplicationContext();
        this.bleAction = p2;
        this.initBleScanner();
        return;
    }
}
