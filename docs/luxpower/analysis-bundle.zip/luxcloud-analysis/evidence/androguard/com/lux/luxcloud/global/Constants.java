package com.lux.luxcloud.global;
public class Constants {
    public static int CAMERA_REQUEST_CODE = 0;
    public static final String CLUSTER_GROUP_EU2 = "eu2Cluster";
    public static final String CLUSTER_GROUP_FIRST = "firstCluster";
    public static final String CLUSTER_GROUP_INDIA = "indiaCluster";
    public static final String CLUSTER_GROUP_PHILIPPINES = "phiCluster";
    public static final String CLUSTER_GROUP_SECOND = "secondCluster";
    public static final String CLUSTER_GROUP_VIETNAM = "vietnamCluster";
    public static String DEFAULT_DATALOG_SN = "";
    public static final int DEVICE_TYPE_12K_HYBRID = 6;
    public static final int DEVICE_TYPE_AC_CHARGER = 2;
    public static final int DEVICE_TYPE_ALL_IN_ONE = 7;
    public static final int DEVICE_TYPE_BESS_200K = 14;
    public static final int DEVICE_TYPE_GEN_3_6K = 10;
    public static final int DEVICE_TYPE_GEN_7_10K = 8;
    public static final int DEVICE_TYPE_GETA = 13;
    public static final int DEVICE_TYPE_HV_HYBRID = 4;
    public static final int DEVICE_TYPE_HYBRID = 0;
    public static final int DEVICE_TYPE_LSP_100K = 5;
    public static final int DEVICE_TYPE_MID_BOX = 9;
    public static final int DEVICE_TYPE_OFF_GRID = 3;
    public static final int DEVICE_TYPE_PV_INVERTER = 1;
    public static final int DEVICE_TYPE_SNA_12K = 11;
    public static final int DONGLE_CHANGE_DHCP_IP_MODE = 18;
    public static final int DONGLE_CHANGE_STATIC_IP_MODE = 17;
    public static final int DONGLE_CONNECT_PARAM = 16;
    public static final int DONGLE_PARAM_INDEX_DONGLE_TYPE = 11;
    public static final int DONGLE_PARAM_INDEX_FIRMWARE_VERSION = 7;
    public static final int DONGLE_PARAM_INDEX_RESET_2_FACTORY = 3;
    public static final int DONGLE_PARAM_INDEX_SERVER_IP_AND_PORT = 6;
    public static final int DONGLE_PARAM_INDEX_SN = 1;
    public static final int DONGLE_PARAM_INDEX_SSID = 5;
    public static final int DONGLE_PARAM_INDEX_SSID_PASSWORD = 4;
    public static final int DONGLE_PARAM_INDEX_UPDATE_FIRMWARE = 9;
    public static final int DONGLE_QUERY_AP_PASSWORD = 14;
    public static final int DONGLE_QUERY_FIRST_USE = 19;
    public static final int DONGLE_QUERY_PASSWORD_STATUS = 15;
    public static final String DONGLE_SERVER_AFRICA = "47.91.87.102,4346";
    public static final String DONGLE_SERVER_ASIA = "120.79.53.27,4346";
    public static final String DONGLE_SERVER_EU2 = "eu2.luxpowertek.com,4346";
    public static final String DONGLE_SERVER_EUROPE = "8.208.83.249,4346";
    public static final String DONGLE_SERVER_INDIA = "ind.luxpowertek.com,4346";
    public static final String DONGLE_SERVER_LOCAL = "dongle.luxpowertek.com,4346";
    public static final String DONGLE_SERVER_LOCAL_SSL = "dongle_ssl.solarcloudsystem.com,4348";
    public static final String DONGLE_SERVER_NORTH_AMERICA = "us2.solarcloudsystem.com,4346";
    public static final String DONGLE_SERVER_NORTH_AMERICA_IP = "3.101.7.137,4346";
    public static final String DONGLE_SERVER_NORTH_AMERICA_SSL = "us2_ssl.solarcloudsystem.com,4346";
    public static final String DONGLE_SERVER_PHI = "phi.luxpowertek.com,4346";
    public static final String DONGLE_SERVER_SOUTHEAST_ASIA = "47.81.11.236,4346";
    public static final String DONGLE_SERVER_USA = "47.254.33.206,4346";
    public static final String DONGLE_SERVER_VN = "vn.luxpowertek.com,4346";
    public static final int DONGLE_SET_AP_PASSWORD_STATUS = 12;
    public static final int DONGLE_SOFT_RESET = 13;
    public static final long EG4_OWNER_ACCOUNT_ID_1 = 12;
    public static final long EG4_OWNER_ACCOUNT_ID_10 = 627;
    public static final long EG4_OWNER_ACCOUNT_ID_11 = 1863;
    public static final long EG4_OWNER_ACCOUNT_ID_12 = 11458;
    public static final long EG4_OWNER_ACCOUNT_ID_13 = 13226;
    public static final long EG4_OWNER_ACCOUNT_ID_14 = 13227;
    public static final long EG4_OWNER_ACCOUNT_ID_15 = 14261;
    public static final long EG4_OWNER_ACCOUNT_ID_16 = 2271;
    public static final long EG4_OWNER_ACCOUNT_ID_17 = 3775;
    public static final long EG4_OWNER_ACCOUNT_ID_18 = 488;
    public static final long EG4_OWNER_ACCOUNT_ID_19 = 90;
    public static final long EG4_OWNER_ACCOUNT_ID_2 = 411;
    public static final long EG4_OWNER_ACCOUNT_ID_20 = 21813;
    public static final long EG4_OWNER_ACCOUNT_ID_21 = 21842;
    public static final long EG4_OWNER_ACCOUNT_ID_22 = 12193;
    public static final long EG4_OWNER_ACCOUNT_ID_23 = 19594;
    public static final long EG4_OWNER_ACCOUNT_ID_24 = 25517;
    public static final long EG4_OWNER_ACCOUNT_ID_25 = 25518;
    public static final long EG4_OWNER_ACCOUNT_ID_26 = 26382;
    public static final long EG4_OWNER_ACCOUNT_ID_27 = 26385;
    public static final long EG4_OWNER_ACCOUNT_ID_28 = 41;
    public static final long EG4_OWNER_ACCOUNT_ID_3 = 45;
    public static final long EG4_OWNER_ACCOUNT_ID_4 = 89;
    public static final long EG4_OWNER_ACCOUNT_ID_5 = 39;
    public static final long EG4_OWNER_ACCOUNT_ID_6 = 1355;
    public static final long EG4_OWNER_ACCOUNT_ID_7 = 91;
    public static final long EG4_OWNER_ACCOUNT_ID_8 = 49;
    public static final long EG4_OWNER_ACCOUNT_ID_9 = 11457;
    public static final long ENERGY100_USER_ID = 6920;
    public static int FILECHOOSER_RESULTCODE = 0;
    public static final String INDIA_COUNTRY_CODE = "IN";
    public static String KEY_BLE_DEVICE = "";
    public static final String LOCAL_CONNECT_TYPE = "localConnectType";
    public static final String LOCAL_CONNECT_TYPE_BLUETOOTH = "bluetooth";
    public static final String LOCAL_CONNECT_TYPE_TCP = "tcp";
    public static int LOCATION_PERMISSION_REQUEST_CODE = 0;
    public static int MODEL_EU_VERSION_US = 0;
    public static int MODEL_US_VERSION_US = 0;
    public static final int REMOTE_UPDATE_CODE_ALLOW = 1;
    public static final int REMOTE_UPDATE_CODE_ALLOW_TOTALLY = 65;
    public static final long SCAN_DURATION_MS = 4000;
    public static final String SELECTED_FIRMWARE_ID = "selectedFirmwareId";
    public static final int SUB_DEVICE_TYPE_12K_EU = 162;
    public static final int SUB_DEVICE_TYPE_12K_US = 164;
    public static final int SUB_DEVICE_TYPE_8_10K_EU = 161;
    public static final int SUB_DEVICE_TYPE_8_10K_US = 163;
    public static final int SUB_DEVICE_TYPE_OFF_GRID_US = 131;
    public static final int SUB_DEVICE_TYPE_SNA_12K_EU = 1110;
    public static final int SUB_DEVICE_TYPE_SNA_12K_US = 1111;
    public static final long SolarVietD_ID = 278;
    public static final String TARGET = "TARGET";
    public static final String TARGET_LOCAL_CONNECT = "LocalConnect";
    public static final String TARGET_UPDATE_FIRMWARE = "UpdateFirmware";
    public static final String TARGET_WIFI_CONFIG = "WifiConfig";
    public static final long USER_ID_gigabiz1 = 13;
    public static final String VIETNAM_COUNTRY_CODE = "VN";
    public static final String demoModeLoginAccount = "guest";
    public static final String demoModeLoginPassWord = "Guest123_456";
    public static final String dongleIpPrefix = "10.10.10.";
    public static final java.util.List firmwareTypeProperties = None;
    public static final java.util.List firmwareTypePropertiesExceptE_WIFI = None;
    public static final long sonnepv_USER_ID = 68186;
    public static String useHtmlSettingPage = "";
    public static String useNewSettingPage = "";
    public static final java.util.Map validServerHostIndexMap = None;
    public static final java.util.Map validServerIndexMap = None;
    public static final String webView_loadUrl = "file:///android_asset/h5/index.html";

    static Constants()
    {
        int v0 = 0;
        com.lux.luxcloud.global.firmware.FIRMWARE_DEVICE_TYPE[] v1_0 = 0;
        while (v1_0 < 10) {
            com.lux.luxcloud.global.Constants.DEFAULT_DATALOG_SN = new StringBuilder().append(com.lux.luxcloud.global.Constants.DEFAULT_DATALOG_SN).append(com.lux.luxcloud.tool.ProTool.getStringFromHex(255)).toString();
            v1_0++;
        }
        com.lux.luxcloud.global.Constants.KEY_BLE_DEVICE = "key_ble_device";
        com.lux.luxcloud.global.Constants.MODEL_US_VERSION_US = 1;
        com.lux.luxcloud.global.Constants.MODEL_EU_VERSION_US = 0;
        com.lux.luxcloud.global.Constants.useNewSettingPage = "New_Setting_Page";
        com.lux.luxcloud.global.Constants.useHtmlSettingPage = "Html_Setting_Page";
        com.lux.luxcloud.global.Constants.LOCATION_PERMISSION_REQUEST_CODE = 3;
        com.lux.luxcloud.global.Constants.FILECHOOSER_RESULTCODE = 4;
        com.lux.luxcloud.global.Constants.CAMERA_REQUEST_CODE = 1;
        com.lux.luxcloud.global.Constants.validServerIndexMap = new java.util.HashMap();
        com.lux.luxcloud.global.Constants.validServerHostIndexMap = new java.util.HashMap();
        com.lux.luxcloud.global.Constants.firmwareTypeProperties = new java.util.ArrayList();
        com.lux.luxcloud.global.Constants.firmwareTypePropertiesExceptE_WIFI = new java.util.ArrayList();
        com.lux.luxcloud.global.firmware.FIRMWARE_DEVICE_TYPE[] v1_9 = com.lux.luxcloud.global.firmware.FIRMWARE_DEVICE_TYPE.values();
        int v2_4 = v1_9.length;
        String v3_0 = 0;
        while (v3_0 < v2_4) {
            java.util.List v4_3 = v1_9[v3_0];
            com.lux.luxcloud.global.Constants.firmwareTypeProperties.add(new com.lux.luxcloud.global.bean.property.Property(v4_3.name(), v4_3.getText()));
            v3_0++;
        }
        com.lux.luxcloud.global.firmware.FIRMWARE_DEVICE_TYPE[] v1_10 = com.lux.luxcloud.global.firmware.FIRMWARE_DEVICE_TYPE.values();
        int v2_5 = v1_10.length;
        while (v0 < v2_5) {
            String v3_1 = v1_10[v0];
            if (!com.lux.luxcloud.global.firmware.FIRMWARE_DEVICE_TYPE.DONGLE_E_WIFI_DONGLE.equals(v3_1)) {
                com.lux.luxcloud.global.Constants.firmwareTypePropertiesExceptE_WIFI.add(new com.lux.luxcloud.global.bean.property.Property(v3_1.name(), v3_1.getText()));
            }
            v0++;
        }
        return;
    }

    public Constants()
    {
        return;
    }

    public static Integer getIndexByHost(String p3)
    {
        Integer v3_1 = com.lux.luxcloud.tool.Tool.extractHost(p3);
        java.util.Iterator v0_2 = com.lux.luxcloud.global.Constants.validServerHostIndexMap;
        java.util.Map$Entry v1_5 = ((Integer) v0_2.get(v3_1.toLowerCase()));
        if (v1_5 == null) {
            java.util.Iterator v0_1 = v0_2.entrySet().iterator();
            while (v0_1.hasNext()) {
                java.util.Map$Entry v1_2 = ((java.util.Map$Entry) v0_1.next());
                if (((String) v1_2.getKey()).equalsIgnoreCase(v3_1)) {
                    return ((Integer) v1_2.getValue());
                }
            }
            return 0;
        } else {
            return v1_5;
        }
    }

    public static void initValidServerIndexMap()
    {
        java.util.Iterator v0_0 = com.lux.luxcloud.global.Constants.validServerIndexMap;
        v0_0.clear();
        String v1_11 = com.lux.luxcloud.global.GlobalInfo.getInstance().getCurrentClusterGroup();
        String v2_22 = com.lux.luxcloud.global.bean.user.PLATFORM.LUX_POWER.equals(com.lux.luxcloud.version.Custom.APP_PLATFORM);
        java.util.Map v3_2 = Integer.valueOf(0);
        if ((v2_22 == null) && (!com.lux.luxcloud.global.bean.user.PLATFORM.MID.equals(com.lux.luxcloud.version.Custom.APP_PLATFORM))) {
            if (com.lux.luxcloud.global.bean.user.PLATFORM.EG4.equals(com.lux.luxcloud.version.Custom.APP_PLATFORM)) {
                v0_0.put("us2.solarcloudsystem.com,4346", v3_2);
                v0_0.put("3.101.7.137,4346", v3_2);
                v0_0.put("us2_ssl.solarcloudsystem.com,4346", v3_2);
            }
        } else {
            if (!"firstCluster".equals(v1_11)) {
                if (!"indiaCluster".equals(v1_11)) {
                    if (!"phiCluster".equals(v1_11)) {
                        if (!"vietnamCluster".equals(v1_11)) {
                            if ("eu2Cluster".equals(v1_11)) {
                                v0_0.put("eu2.luxpowertek.com,4346", v3_2);
                            }
                        } else {
                            v0_0.put("vn.luxpowertek.com,4346", v3_2);
                        }
                    } else {
                        v0_0.put("phi.luxpowertek.com,4346", v3_2);
                    }
                } else {
                    v0_0.put("ind.luxpowertek.com,4346", v3_2);
                }
            } else {
                v0_0.put("120.79.53.27,4346", v3_2);
                v0_0.put("8.208.83.249,4346", Integer.valueOf(1));
                v0_0.put("47.91.87.102,4346", Integer.valueOf(2));
                v0_0.put("47.254.33.206,4346", Integer.valueOf(3));
                v0_0.put("47.81.11.236,4346", Integer.valueOf(4));
            }
            v0_0.put("dongle.luxpowertek.com,4346", Integer.valueOf(v0_0.size()));
            v0_0.put("dongle_ssl.solarcloudsystem.com,4348", Integer.valueOf(v0_0.size()));
        }
        com.lux.luxcloud.global.Constants.validServerHostIndexMap.clear();
        java.util.Iterator v0_2 = v0_0.entrySet().iterator();
        while (v0_2.hasNext()) {
            String v1_1 = ((java.util.Map$Entry) v0_2.next());
            com.lux.luxcloud.global.Constants.validServerHostIndexMap.put(com.lux.luxcloud.tool.Tool.extractHost(((String) v1_1.getKey())).toLowerCase(), ((Integer) v1_1.getValue()));
        }
        return;
    }
}
