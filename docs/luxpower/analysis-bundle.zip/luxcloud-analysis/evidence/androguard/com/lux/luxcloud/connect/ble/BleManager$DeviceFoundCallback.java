package com.lux.luxcloud.connect.ble;
public interface BleManager$DeviceFoundCallback {

    public abstract void onDeviceFound(android.bluetooth.le.ScanResult p0);
}
