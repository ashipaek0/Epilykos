package com.lux.luxcloud.global.bean.param;
final enum class PARAM$122 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$122(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$122(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p4)
    {
        boolean v0_0 = p4.getCurrentInverter();
        if ((!v0_0.isAcCharger()) && ((!v0_0.isSnaSeries()) && (!v0_0.isGen3Series()))) {
            return 0;
        } else {
            if ((this.isViewer(p4)) && (!this.isEg4(p4))) {
                return 0;
            } else {
                return 1;
            }
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887380;
    }

    public int getStartRegister()
    {
        return 150;
    }
}
