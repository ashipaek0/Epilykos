package com.lux.luxcloud.global.bean.param;
final enum class PARAM$184 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$184(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$184(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p4)
    {
        boolean v0_0 = p4.getCurrentInverter();
        if (((!v0_0.isType6Series()) && (!v0_0.isGen3Series())) || (v0_0.isAllInOne())) {
            return 0;
        } else {
            if (!v0_0.isGen3_6K()) {
                if ((this.isViewer(p4)) && (this.isEg4(p4))) {
                    return 0;
                } else {
                    return 1;
                }
            } else {
                return 0;
            }
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return 2131886848;
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131886277;
    }

    public int getStartRegister()
    {
        return 224;
    }
}
