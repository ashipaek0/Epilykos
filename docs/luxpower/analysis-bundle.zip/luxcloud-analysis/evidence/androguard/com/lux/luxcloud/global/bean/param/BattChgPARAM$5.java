package com.lux.luxcloud.global.bean.param;
final enum class BattChgPARAM$5 extends com.lux.luxcloud.global.bean.param.BattChgPARAM {

    private BattChgPARAM$5(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic BattChgPARAM$5(String p1, int p2, com.lux.luxcloud.global.bean.param.BattChgPARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkEnabled(String p2)
    {
        return "VOLT".equals(p2);
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p1)
    {
        return 1;
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p3)
    {
        if ((!p3.isType6()) && (!p3.isMidBox())) {
            if ((!p3.isSnaSeries()) && ((!p3.isHybird()) && (!p3.isAcCharger()))) {
                return 2131887598;
            } else {
                return 2131887297;
            }
        } else {
            return 2131887598;
        }
    }

    public int getStartRegister()
    {
        return 158;
    }
}
