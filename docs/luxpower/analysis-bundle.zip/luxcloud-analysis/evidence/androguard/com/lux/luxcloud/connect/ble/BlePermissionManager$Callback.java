package com.lux.luxcloud.connect.ble;
public interface BlePermissionManager$Callback {

    public abstract void onDenied();

    public abstract void onGranted();
}
