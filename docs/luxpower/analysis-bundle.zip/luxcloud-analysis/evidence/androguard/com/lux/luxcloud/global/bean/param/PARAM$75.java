package com.lux.luxcloud.global.bean.param;
final enum class PARAM$75 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$75(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$75(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p5)
    {
        boolean v0_0 = p5.getCurrentInverter();
        if ((!v0_0.isType6Series()) && ((!v0_0.isGen3Series()) && (!v0_0.isMidBox()))) {
            if ((!v0_0.isHybird()) && (!v0_0.isAcCharger())) {
                return 0;
            } else {
                return 1;
            }
        } else {
            if ((p5.isGigabiz1User()) && (this.isViewer(p5))) {
                return 0;
            } else {
                return 1;
            }
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        if (!p1.getCurrentInverter().isHybird()) {
            return 2131886766;
        } else {
            return -1;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p2)
    {
        if (!p2.isMidBox()) {
            if (!p2.isType6Series()) {
                return 2131887405;
            } else {
                return 2131887407;
            }
        } else {
            return 2131887406;
        }
    }

    public int getStartRegister()
    {
        return 82;
    }
}
