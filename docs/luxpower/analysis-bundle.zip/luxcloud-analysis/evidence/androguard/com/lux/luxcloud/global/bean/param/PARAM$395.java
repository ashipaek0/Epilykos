package com.lux.luxcloud.global.bean.param;
final enum class PARAM$395 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$395(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$395(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p3)
    {
        p3.getRole();
        if (!p3.getCurrentInverter().isType6Series()) {
            return 0;
        } else {
            if ((!this.isEg4Admin(p3)) && ((!this.isAdmin(p3)) && (!this.isMAINTAIN(p3)))) {
                return 0;
            } else {
                return 1;
            }
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887358;
    }
}
