package com.lux.luxcloud.global.bean.param;
final enum class PARAM$110 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$110(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$110(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p5)
    {
        int v5_8;
        com.lux.luxcloud.global.bean.inverter.Inverter v0 = p5.getCurrentInverter();
        if ((!v0.isAcCharger()) && (!v0.isHybird())) {
            if (((!v0.isType6Series()) && (!v0.isGen3Series())) || (v0.isAllInOne())) {
                if (!v0.isSnaSeries()) {
                    if ((!this.isEg4(p5)) || (!v0.isParallelGroup())) {
                        return 0;
                    } else {
                        return 1;
                    }
                } else {
                    if (((!v0.isSna12K()) || ((v0.getPhaseValue().intValue() != 1) || (v0.getDtcValue() != 0))) && (!v0.isOffGrid())) {
                        return 1;
                    } else {
                        return 0;
                    }
                }
            } else {
                v5_8 = this.isViewer(p5);
            }
        } else {
            v5_8 = this.isViewer(p5);
        }
        return (v5_8 ^ 1);
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131886567;
    }

    public int getStartRegister()
    {
        return 118;
    }
}
