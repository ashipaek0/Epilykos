package com.lux.luxcloud.global.bean.param;
final enum class PARAM$224 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$224(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$224(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p6)
    {
        com.lux.luxcloud.global.bean.user.ROLE v0 = p6.getRole();
        boolean v1_1 = p6.getCurrentInverter();
        if (((!v1_1.isType6Series()) && (!v1_1.isGen3Series())) || (v1_1.isAllInOne())) {
            if (!v1_1.isMidBox()) {
                if ((!v1_1.isAcCharger()) && ((!v1_1.isHybird()) && (!v1_1.isSnaSeriesOrGeta()))) {
                    return 0;
                } else {
                    if ((this.isViewer(p6)) || (v0.getInstallerLevelCheck())) {
                        return 0;
                    } else {
                        return 1;
                    }
                }
            } else {
                if ((this.isViewer(p6)) || (v0.getInstallerLevelCheck())) {
                    return 0;
                } else {
                    return 1;
                }
            }
        } else {
            if ((this.isViewer(p6)) || (v0.getInstallerLevelCheck())) {
                return 0;
            } else {
                return 1;
            }
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return 2131886741;
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887124;
    }
}
