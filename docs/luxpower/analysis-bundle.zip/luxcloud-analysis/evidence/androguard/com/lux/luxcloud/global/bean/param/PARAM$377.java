package com.lux.luxcloud.global.bean.param;
final enum class PARAM$377 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$377(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$377(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p3)
    {
        int v3_1 = p3.getCurrentInverter();
        if ((!v3_1.isType6Series()) || (v3_1.isAllInOne())) {
            if (!v3_1.isHybird()) {
                if (!v3_1.isSnaSeriesOrGeta()) {
                    if (!v3_1.isMidBox()) {
                        return 0;
                    } else {
                        return 1;
                    }
                } else {
                    return 1;
                }
            } else {
                return this.checkHybridFirmware20240811(v3_1);
            }
        } else {
            return 1;
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return 2131886858;
    }

    public Object getPlatformSpecificData(com.lux.luxcloud.global.UserData p4, android.content.Context p5)
    {
        int v4_2;
        int v4_1 = p4.getCurrentInverter();
        if (!v4_1.isGeta()) {
            v4_2 = 1065353216;
        } else {
            int v4_5 = v4_1.getVoltClassValue();
            if (v4_5 != 2) {
                if (v4_5 != 3) {
                } else {
                    v4_2 = 1082130432;
                }
            } else {
                v4_2 = 1073741824;
            }
        }
        java.text.DecimalFormat v5_1 = new java.text.DecimalFormat("0.#");
        v5_1.setRoundingMode(java.math.RoundingMode.HALF_UP);
        return this.createInputBox(v5_1.format(((double) (((float) 57) / v4_2))), v5_1.format(((double) (1108973978 / v4_2))));
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p3)
    {
        if ((!p3.isType6()) && (!p3.isMidBox())) {
            if ((!p3.isSnaSeries()) && ((!p3.isHybird()) && (!p3.isAcCharger()))) {
                return 2131887598;
            } else {
                return 2131887297;
            }
        } else {
            return 2131887598;
        }
    }

    public int getStartRegister()
    {
        return 158;
    }
}
