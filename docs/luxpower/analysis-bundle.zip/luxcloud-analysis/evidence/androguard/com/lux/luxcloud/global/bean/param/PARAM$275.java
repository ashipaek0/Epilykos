package com.lux.luxcloud.global.bean.param;
final enum class PARAM$275 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$275(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$275(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p5)
    {
        boolean v0_0 = p5.getCurrentInverter();
        if ((!p5.isGigabiz1User()) || (!this.isViewer(p5))) {
            if (((v0_0.getSlaveVersionValue() < 33) || (v0_0.getFwVersionValue() < 34)) && (!com.lux.luxcloud.global.bean.user.PLATFORM.EG4.equals(p5.getPlatform()))) {
                return 0;
            } else {
                return (this.isViewer(p5) ^ 1);
            }
        } else {
            return 0;
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return 2131886757;
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p2)
    {
        if (!com.lux.luxcloud.version.Custom.APP_USER_PLATFORM.equals(com.lux.luxcloud.global.bean.user.PLATFORM.EG4)) {
            return 2131886144;
        } else {
            return 2131886145;
        }
    }
}
