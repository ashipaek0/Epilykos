package com.lux.luxcloud.global.bean.param;
final enum class PARAM$34 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$34(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$34(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p3)
    {
        if ((!com.lux.luxcloud.global.bean.user.ROLE.ADMIN.equals(p3.getRole())) && (!com.lux.luxcloud.global.bean.user.ROLE.MAINTAIN.equals(p3.getRole()))) {
            return 0;
        } else {
            return 1;
        }
    }

    public Object getPlatformSpecificData(com.lux.luxcloud.global.UserData p4, android.content.Context p5)
    {
        int v4_2;
        int v4_1 = p4.getCurrentInverter();
        if (!v4_1.isGeta()) {
            v4_2 = 1065353216;
        } else {
            int v4_5 = v4_1.getVoltClassValue();
            if (v4_5 != 2) {
                if (v4_5 != 3) {
                } else {
                    v4_2 = 1082130432;
                }
            } else {
                v4_2 = 1073741824;
            }
        }
        java.text.DecimalFormat v5_1 = new java.text.DecimalFormat("0.#");
        v5_1.setRoundingMode(java.math.RoundingMode.HALF_UP);
        return this.createInputBox(v5_1.format(((double) (((float) 59) / v4_2))), v5_1.format(((double) (((float) 40) / v4_2))));
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return -1;
    }
}
