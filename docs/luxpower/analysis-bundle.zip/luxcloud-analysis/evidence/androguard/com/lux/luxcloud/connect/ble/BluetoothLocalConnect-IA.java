package com.lux.luxcloud.connect.ble;
public final synthetic class BluetoothLocalConnect-IA {
}
