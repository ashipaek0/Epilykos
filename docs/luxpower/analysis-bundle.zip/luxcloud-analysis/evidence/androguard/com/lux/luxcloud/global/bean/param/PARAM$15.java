package com.lux.luxcloud.global.bean.param;
final enum class PARAM$15 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$15(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$15(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p5)
    {
        boolean v0_0 = p5.getCurrentInverter();
        if ((!v0_0.isType6Series()) && ((!v0_0.isGen3Series()) && ((!v0_0.isMidBox()) && ((!v0_0.isGeta()) && (!v0_0.isSnaSeries()))))) {
            if ((!v0_0.isAcCharger()) && (!v0_0.isHybird())) {
                return 0;
            } else {
                if ((p5.getRole().getInstallerLevelCheck()) || (this.isViewer(p5))) {
                    return 0;
                } else {
                    return 1;
                }
            }
        } else {
            if ((this.isViewer(p5)) && ((!this.isEg4Admin(p5)) && ((!p5.isSolarVietD()) && ((!this.isCrown(p5)) || (!com.lux.luxcloud.global.bean.user.ROLE.OWNER.equals(p5)))))) {
                return 0;
            } else {
                return 1;
            }
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return 2131886842;
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p2)
    {
        if ((!p2.isMidBox()) && (!p2.isType6Series())) {
            return 2131886843;
        } else {
            return 2131886830;
        }
    }

    public int getStartRegister()
    {
        return 35;
    }
}
