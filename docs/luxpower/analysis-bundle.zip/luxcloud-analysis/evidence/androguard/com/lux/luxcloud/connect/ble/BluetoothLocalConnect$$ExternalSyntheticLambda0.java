package com.lux.luxcloud.connect.ble;
public final synthetic class BluetoothLocalConnect$$ExternalSyntheticLambda0 implements java.lang.Runnable {
    public final synthetic com.lux.luxcloud.connect.ble.BluetoothLocalConnect f$0;

    public synthetic BluetoothLocalConnect$$ExternalSyntheticLambda0(com.lux.luxcloud.connect.ble.BluetoothLocalConnect p1)
    {
        this.f$0 = p1;
        return;
    }

    public final void run()
    {
        com.lux.luxcloud.connect.ble.BluetoothLocalConnect.$r8$lambda$GfYeZXhT6JxKB-TUQP6yNWH5fS4(this.f$0);
        return;
    }
}
