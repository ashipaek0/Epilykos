package com.lux.luxcloud.global.bean.param;
final enum class PARAM$234 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$234(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$234(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p7)
    {
        boolean v0_0 = p7.getRole();
        boolean v1_0 = p7.getCurrentInverter();
        if (((v1_0.isSnaSeriesOrGeta()) && ((this.isAdmin(p7)) || (v0_0.getOwnerLevelCheck()))) || (this.isMAINTAIN(p7))) {
            if (!v1_0.isSnaSeries()) {
                if ((v1_0.getSubDeviceTypeValue() == 131) || (v1_0.getSubDeviceTypeValue() == 111)) {
                    return (v1_0.is_ENELEAGE_ZERO() ^ 1);
                }
            } else {
                if ((!this.isAdmin(p7)) && ((!this.isMAINTAIN(p7)) && ((!this.isAdmin(p7)) || (!this.isEg4(p7))))) {
                    return 0;
                } else {
                    return 1;
                }
            }
        }
        if ((!v1_0.isAcCharger()) && (!v1_0.isHybird())) {
            if (((!v1_0.isType6Series()) && (!v1_0.isGen3Series())) || ((v1_0.isAllInOne()) || ((v1_0.isTrip12K()) || (v1_0.isGen3_6K())))) {
                if (!v1_0.isMidBox()) {
                    return 0;
                } else {
                    if ((!this.isAdmin(p7)) && ((!this.isMAINTAIN(p7)) && (!v0_0.getOwnerLevelCheck()))) {
                        return 0;
                    } else {
                        return 1;
                    }
                }
            } else {
                if ((!this.isAdmin(p7)) && ((!this.isMAINTAIN(p7)) && (!v0_0.getOwnerLevelCheck()))) {
                    return 0;
                } else {
                    return 1;
                }
            }
        } else {
            if ((!this.isAdmin(p7)) && (!this.isMAINTAIN(p7))) {
                return 0;
            } else {
                return 1;
            }
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return 2131886777;
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131886310;
    }
}
