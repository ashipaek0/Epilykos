package com.lux.luxcloud.global.bean.param;
final enum class PARAM$168 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$168(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$168(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p5)
    {
        int v0_0 = p5.getCurrentInverter();
        int v2 = 1;
        if (!v0_0.isSnaSeries()) {
            if ((!this.isEg4(p5)) || (!v0_0.isParallelGroup())) {
                if (((!v0_0.isType6SeriesWithoutTrip12K()) && ((!v0_0.isMidBox()) || (v0_0.isAllInOne()))) || (!this.isEg4(p5))) {
                    if ((!v0_0.isAcCharger()) && ((!v0_0.isHybird()) && ((!v0_0.isType6SeriesWithoutTrip12K()) && ((!v0_0.isGen3_6K()) && (!v0_0.is7_10KDevice()))))) {
                        return 0;
                    } else {
                        return 1;
                    }
                } else {
                    return (this.isViewer(p5) ^ 1);
                }
            } else {
                return 1;
            }
        } else {
            boolean v5_9 = com.lux.luxcloud.global.cache.RemoteSetCacheManager.getInstance().getCache(v0_0.getSerialNum());
            if (!v5_9.has("HOLD_MODEL_leadAcidType")) {
                return 0;
            } else {
                try {
                    boolean v5_10 = v5_9.getInt("HOLD_MODEL_leadAcidType");
                } catch (org.json.JSONException) {
                    v5_10 = 0;
                }
                if (v5_10 != 31) {
                    v2 = 0;
                }
                return v2;
            }
        }
    }

    public Object getPlatformSpecificData(com.lux.luxcloud.global.UserData p1, android.content.Context p2)
    {
        if (!p1.getCurrentInverter().isType6()) {
            return this.createInputBox("1500", "50");
        } else {
            return this.createInputBox("5000", "50");
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131886314;
    }

    public int getStartRegister()
    {
        return 204;
    }
}
