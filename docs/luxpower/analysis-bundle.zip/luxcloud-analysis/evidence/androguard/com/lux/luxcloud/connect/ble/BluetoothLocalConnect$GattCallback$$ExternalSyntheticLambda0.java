package com.lux.luxcloud.connect.ble;
public final synthetic class BluetoothLocalConnect$GattCallback$$ExternalSyntheticLambda0 implements java.lang.Runnable {
    public final synthetic com.lux.luxcloud.connect.ble.BluetoothLocalConnect$GattCallback f$0;
    public final synthetic android.bluetooth.BluetoothGatt f$1;

    public synthetic BluetoothLocalConnect$GattCallback$$ExternalSyntheticLambda0(com.lux.luxcloud.connect.ble.BluetoothLocalConnect$GattCallback p1, android.bluetooth.BluetoothGatt p2)
    {
        this.f$0 = p1;
        this.f$1 = p2;
        return;
    }

    public final void run()
    {
        com.lux.luxcloud.connect.ble.BluetoothLocalConnect$GattCallback.$r8$lambda$DEpH0PdCdBFedYjCV8Ov_SKfkm0(this.f$0, this.f$1);
        return;
    }
}
