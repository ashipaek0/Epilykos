package com.lux.luxcloud.global.bean.param;
final enum class PARAM$391 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$391(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$391(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p5)
    {
        boolean v5_1;
        boolean v0_0 = p5.getCurrentInverter();
        if (((!v0_0.isType6Series()) || (v0_0.getUsVersionValue() != 1)) && (!v0_0.isGenUs13_16K())) {
            if ((!v0_0.isType6Series()) && (!v0_0.isGen3Series())) {
                if (!v0_0.isSnaSeriesOrGeta()) {
                    return 0;
                } else {
                    v5_1 = this.isViewer(p5);
                }
            } else {
                if ((!this.isAdmin(p5)) && (!this.isMAINTAIN(p5))) {
                    return 0;
                } else {
                    return 1;
                }
            }
        } else {
            v5_1 = this.isViewer(p5);
        }
        return (v5_1 ^ 1);
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return 2131887595;
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887594;
    }
}
