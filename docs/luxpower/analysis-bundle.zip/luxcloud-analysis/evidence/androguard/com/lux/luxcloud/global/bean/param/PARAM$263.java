package com.lux.luxcloud.global.bean.param;
final enum class PARAM$263 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$263(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$263(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p6)
    {
        com.lux.luxcloud.global.bean.user.ROLE v0_0 = p6.getCurrentInverter();
        com.lux.luxcloud.global.bean.user.PLATFORM v1 = p6.getPlatform();
        if (!v0_0.isGen3Series()) {
            if (((!v0_0.isAcCharger()) && (!v0_0.isHybird())) || (v0_0.isTrip12K())) {
                if ((((!v0_0.isType6Series()) || (v0_0.isAllInOne())) && (!v0_0.isMidBox())) || ((v0_0.isTrip12K()) || (v0_0.isGen3_6K()))) {
                    return 0;
                } else {
                    if ((!com.lux.luxcloud.global.bean.user.PLATFORM.EG4.equals(v1)) && (com.lux.luxcloud.global.bean.user.ROLE.VIEWER.equals(p6.getRole()))) {
                        return 0;
                    } else {
                        return 1;
                    }
                }
            } else {
                return (this.isViewer(p6) ^ 1);
            }
        } else {
            return 0;
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return 2131886750;
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887704;
    }
}
