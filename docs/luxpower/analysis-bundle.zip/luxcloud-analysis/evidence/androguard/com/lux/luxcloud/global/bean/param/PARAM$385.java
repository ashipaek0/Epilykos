package com.lux.luxcloud.global.bean.param;
final enum class PARAM$385 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$385(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$385(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    private void addGridStandardOption(java.util.Map p3, String p4, int p5, android.content.Context p6)
    {
        p3.put(p4, new StringBuilder().append(p4).append(": ").append(p6.getString(p5)).toString());
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p6)
    {
        p6.getRole();
        int v0_0 = p6.getUsername();
        boolean v1_1 = p6.getCurrentInverter();
        if ((!v1_1.isHybird()) && ((!v1_1.isAcCharger()) && ((!v1_1.isType6Series()) && (!v1_1.isGen3Series())))) {
            if (((!v1_1.isSnaSeriesOrGeta()) || ((this.isViewer(p6)) && (!this.isEg4(p6)))) || ((v1_1.getSubDeviceTypeValue() == 131) || (v1_1.getSubDeviceTypeValue() == 1111))) {
                return 0;
            } else {
                return 1;
            }
        } else {
            if ((!this.isAdmin(p6)) && ((!this.isMAINTAIN(p6)) && ((!"SignatureSolar".equals(v0_0)) && (!"gigabiz1".equals(v0_0))))) {
                return 0;
            } else {
                return 1;
            }
        }
    }

    public Object getPlatformSpecificData(com.lux.luxcloud.global.UserData p26, android.content.Context p27)
    {
        void v0_0 = this;
        org.json.JSONObject v1_0 = p27;
        String v2_42 = p26.getCurrentInverter();
        if (v2_42 != null) {
            int v15_4;
            java.util.LinkedHashMap v3_1 = new java.util.LinkedHashMap();
            int v4_14 = v2_42.getDtcValue();
            int v5_0 = v2_42.getDeviceTypeValue();
            int v6_0 = v2_42.getMachineType();
            String v7_1 = v2_42.getPhaseValue().intValue();
            String v8_2 = v2_42.getUsVersionValue();
            int v9_1 = v2_42.getSlaveVersion().intValue();
            int v10_1 = v2_42.getFwVersion().intValue();
            int v11_2 = v2_42.isMega24K();
            String v12_0 = v2_42.isGen2_7_14K();
            String v13_0 = v2_42.isTrip12K();
            String v14_0 = v2_42.isTrip12KLvUs();
            com.lux.luxcloud.global.bean.inverter.Inverter v26_1 = v2_42;
            if ((!v2_42.isSnaSeries()) && ((!v26_1.isGeta()) && (!v26_1.isGen3_6K()))) {
                v15_4 = 0;
            } else {
                v15_4 = 1;
            }
            boolean v17 = v11_2;
            boolean v18 = v12_0;
            boolean v19 = v13_0;
            boolean v20 = v14_0;
            boolean v21 = v15_4;
            if ((!v17) || (v8_2 == 1)) {
                if ((v4_14 != 1) || ((v5_0 == 3) || (v6_0 == 0))) {
                    int v11_7;
                    if (v5_0 != 6) {
                        v11_7 = 1;
                        if ((!v17) || (v8_2 != v11_7)) {
                            if (!v21) {
                                if ((!v19) || (v20)) {
                                    if (v20) {
                                        v0_0 = this.addGridStandardOption(v3_1, "0", 2131887189, p27).addGridStandardOption(v3_1, "5", 2131887163, p27);
                                    }
                                } else {
                                    v0_0 = this.addGridStandardOption(v3_1, "0", 2131887210, p27).addGridStandardOption(v3_1, "1", 2131887217, p27).addGridStandardOption(v3_1, "2", 2131887194, v1_0).addGridStandardOption(v3_1, "3", 2131887209, v1_0).addGridStandardOption(v3_1, "4", 2131887199, v1_0).addGridStandardOption(v3_1, "5", 2131887174, p27).addGridStandardOption(v3_1, "6", 2131887173, v1_0).addGridStandardOption(v3_1, "7", 2131887208, v1_0).addGridStandardOption(v3_1, "8", 2131887198, v1_0).addGridStandardOption(v3_1, "9", 2131887169, v1_0).addGridStandardOption(v3_1, "10", 2131887201, v1_0).addGridStandardOption(v3_1, "11", 2131887178, v1_0).addGridStandardOption(v3_1, "12", 2131887184, v1_0).addGridStandardOption(v3_1, "13", 2131887180, v1_0).addGridStandardOption(v3_1, "14", 2131887202, v1_0).addGridStandardOption(v3_1, "15", 2131887167, p27).addGridStandardOption(v3_1, "16", 2131887187, p27);
                                }
                            } else {
                                void v0_20 = this.addGridStandardOption(v3_1, "0", 2131887204, p27).addGridStandardOption(v3_1, "1", 2131887216, p27).addGridStandardOption(v3_1, "2", 2131887215, v1_0).addGridStandardOption(v3_1, "3", 2131887196, p27).addGridStandardOption(v3_1, "4", 2131887195, v1_0).addGridStandardOption(v3_1, "5", 2131887205, p27).addGridStandardOption(v3_1, "6", 2131887207, p27);
                                v3_1.put("7", "7: 7");
                                v0_0 = v0_20.addGridStandardOption(v3_1, "8", 2131887206, p27).addGridStandardOption(v3_1, "16", 2131887212, p27);
                            }
                            if ((v19) && (!v20)) {
                                v0_0 = v0_0.addGridStandardOption(v3_1, "19", 2131887203, p27).addGridStandardOption(v3_1, "20", 2131887168, p27).addGridStandardOption(v3_1, "22", 2131887213, v1_0).addGridStandardOption(v3_1, "23", 2131887197, p27);
                            }
                            if ((!v21) && (!v20)) {
                                v0_0 = v0_0.addGridStandardOption(v3_1, "21", 2131887211, p27).addGridStandardOption(v3_1, "24", 2131887214, p27);
                            }
                            if ((v19) && (!v20)) {
                                v0_0 = v0_0.addGridStandardOption(v3_1, "25", 2131887200, p27);
                            }
                            if ((v18) || ((v19) && (!v20))) {
                                v0_0 = v0_0.addGridStandardOption(v3_1, "26", 2131887163, p27);
                            }
                            return v0_0.createDropdownFromMap(v3_1);
                        }
                    } else {
                        v11_7 = 1;
                        if ((v7_1 != 1) || ((v8_2 != 1) && (v4_14 != 1))) {
                        }
                    }
                    v0_0 = this.addGridStandardOption(v3_1, "0", 2131887189, p27).addGridStandardOption(v3_1, "1", 2131887176, p27).addGridStandardOption(v3_1, "2", 2131887191, v1_0).addGridStandardOption(v3_1, "3", 2131887185, p27).addGridStandardOption(v3_1, "4", 2131887179, p27);
                    if ((v9_1 >= 39) && (v10_1 >= 39)) {
                        v0_0 = v0_0.addGridStandardOption(v3_1, "6", 2131887182, p27);
                    }
                } else {
                    v0_0 = this.addGridStandardOption(v3_1, "0", 2131887189, p27).addGridStandardOption(v3_1, "1", 2131887176, p27).addGridStandardOption(v3_1, "2", 2131887191, v1_0).addGridStandardOption(v3_1, "3", 2131887185, p27).addGridStandardOption(v3_1, "4", 2131887179, p27);
                    if ((((v5_0 == 6) && ((v7_1 == 1) && ((v8_2 == 1) || (v4_14 == 1)))) || (v5_0 == 9)) && ((v9_1 >= 39) && (v10_1 >= 39))) {
                        v0_0 = v0_0.addGridStandardOption(v3_1, "6", 2131887182, p27);
                    }
                }
            } else {
                v0_0 = this.addGridStandardOption(v3_1, "3", 2131887188, p27).addGridStandardOption(v3_1, "4", 2131887175, p27).addGridStandardOption(v3_1, "5", 2131887185, v1_0).addGridStandardOption(v3_1, "6", 2131887179, v1_0).addGridStandardOption(v3_1, "11", 2131887174, v1_0).addGridStandardOption(v3_1, "12", 2131887173, v1_0);
            }
            return v0_0.createDropdownFromMap(v3_1);
        } else {
            return 0;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887271;
    }
}
