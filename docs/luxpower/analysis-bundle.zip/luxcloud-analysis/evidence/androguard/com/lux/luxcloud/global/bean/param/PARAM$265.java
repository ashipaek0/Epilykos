package com.lux.luxcloud.global.bean.param;
final enum class PARAM$265 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$265(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$265(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p6)
    {
        com.lux.luxcloud.global.bean.inverter.Inverter v0 = p6.getCurrentInverter();
        if ((!v0.isSnaSeriesOrGeta()) || (((v0.getDtcValue() != 1) || ((v0.getSubDeviceTypeValue() != 131) && (v0.getHardwareVersion() < 11))) && (((v0.getDtcValue() != 0) || (this.isViewer(p6))) || (((!v0.isSna12K()) || (v0.getSubDeviceTypeValue() != 131)) && (v0.getHardwareVersion() < 11))))) {
            return 0;
        } else {
            return 1;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887117;
    }
}
