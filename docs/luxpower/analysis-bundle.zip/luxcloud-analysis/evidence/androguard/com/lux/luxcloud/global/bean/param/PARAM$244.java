package com.lux.luxcloud.global.bean.param;
final enum class PARAM$244 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$244(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$244(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p5)
    {
        boolean v0_0 = p5.getCurrentInverter();
        if (!v0_0.isSnaSeriesOrGeta()) {
            if (!v0_0.isGen3Series()) {
                return 0;
            } else {
                return 1;
            }
        } else {
            if ((this.isViewer(p5)) && (!this.isEg4(p5))) {
                return 0;
            } else {
                return 1;
            }
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return 2131886729;
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887098;
    }
}
