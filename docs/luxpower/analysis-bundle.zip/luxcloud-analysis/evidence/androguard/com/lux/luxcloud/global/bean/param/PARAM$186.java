package com.lux.luxcloud.global.bean.param;
final enum class PARAM$186 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$186(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$186(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p2)
    {
        if ((!com.lux.luxcloud.global.bean.param.PARAM$186.GENERAL.checkVisible(p2)) && ((!com.lux.luxcloud.global.bean.param.PARAM$186.EPS_OUTPUT.checkVisible(p2)) && ((!com.lux.luxcloud.global.bean.param.PARAM$186.BASIC_PROTECTION_SETTING.checkVisible(p2)) && (!com.lux.luxcloud.global.bean.param.PARAM$186.GRID_SELL.checkVisible(p2))))) {
            return 0;
        } else {
            return 1;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131886137;
    }
}
