package com.lux.luxcloud.global.bean.param;
final enum class PARAM$289 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$289(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$289(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p8)
    {
        com.lux.luxcloud.global.bean.inverter.Inverter v0 = p8.getCurrentInverter();
        p8.getRole();
        int v1 = v0.getSlaveVersionValue();
        boolean v2_0 = v0.getStandard();
        if ((!v0.isAllInOne()) && (!v0.isAcCharger())) {
            if (((!v0.isSnaSeries()) && (!v0.isSna2_12k_EU())) || ((((!v0.isSunKing()) || ((!"cbba".equals(v2_0)) || (v1 < 10))) && ((!v0.isGeta()) && ((v0.getDeviceTypeValue() != 3) || (((!"cbaa".equals(v2_0)) || (v1 < 36)) && (((!"cBaa".equals(v2_0)) || (v1 < 141)) && (((!"cBAA".equals(v2_0)) || (v1 < 141)) && ((v0.getDtcValue() != 1) || ((!"ccaa".equals(v2_0)) || (v1 < 18))))))))) && ((v0.getDeviceTypeValue() != 11) || (((v0.getDtcValue() != 1) || ((!"ceaa".equals(v2_0)) || (v1 < 6))) && ((!"cfaa".equals(v2_0)) || (v1 < 6)))))) {
                if ((!v0.isType6Series()) || (v0.isAllInOne())) {
                    if (!v0.isMidBox()) {
                        return 0;
                    } else {
                        return 1;
                    }
                } else {
                    return 1;
                }
            } else {
                return this.isViewer(p8);
            }
        } else {
            return 0;
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        if (!p1.getCurrentInverter().isHybird()) {
            return 2131886863;
        } else {
            return -1;
        }
    }

    public Object getPlatformSpecificData(com.lux.luxcloud.global.UserData p4, android.content.Context p5)
    {
        int v4_2;
        int v4_1 = p4.getCurrentInverter();
        if (!v4_1.isGeta()) {
            v4_2 = 1065353216;
        } else {
            int v4_5 = v4_1.getVoltClassValue();
            if (v4_5 != 2) {
                if (v4_5 != 3) {
                } else {
                    v4_2 = 1082130432;
                }
            } else {
                v4_2 = 1073741824;
            }
        }
        java.text.DecimalFormat v5_1 = new java.text.DecimalFormat("0.#");
        v5_1.setRoundingMode(java.math.RoundingMode.HALF_UP);
        return this.createInputBox(v5_1.format(((double) (1114505216 / v4_2))), v5_1.format(((double) (((float) 40) / v4_2))));
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887753;
    }
}
