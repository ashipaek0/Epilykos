package com.lux.luxcloud.global.bean.param;
final enum class PARAM$376 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$376(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$376(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p4)
    {
        com.lux.luxcloud.global.bean.inverter.Inverter v0 = p4.getCurrentInverter();
        if (!v0.isHybird()) {
            if (com.lux.luxcloud.global.bean.param.PARAM.BIT_AC_CHARGE_TYPE.checkVisible(p4)) {
                if ((!v0.isType6Series()) || (v0.isAllInOne())) {
                    if (!v0.isMidBox()) {
                        return 0;
                    } else {
                        return 1;
                    }
                } else {
                    return 1;
                }
            } else {
                return 0;
            }
        } else {
            return this.checkHybridFirmware20240811(v0);
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return 2131886857;
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p3)
    {
        if ((p3.isType6()) || ((p3.isMidBox()) || (!p3.isSnaSeries()))) {
            return 2131887597;
        } else {
            return 2131887296;
        }
    }

    public int getStartRegister()
    {
        return 160;
    }
}
