package com.lux.luxcloud.global.bean.inverter;
final enum class BATTERY_TYPE$2 extends com.lux.luxcloud.global.bean.inverter.BATTERY_TYPE {

    private BATTERY_TYPE$2(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic BATTERY_TYPE$2(String p1, int p2, com.lux.luxcloud.global.bean.inverter.BATTERY_TYPE-IA p3)
    {
        this(p1, p2);
        return;
    }

    public int getCode()
    {
        return 1;
    }

    public String getResourceId()
    {
        return "phrase.battery.type.lead.acid";
    }
}
