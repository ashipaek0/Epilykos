package com.lux.luxcloud.global.bean.param;
final enum class PARAM$6 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$6(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$6(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p2)
    {
        return (com.lux.luxcloud.global.bean.user.ROLE.VIEWER.equals(p2.getRole()) ^ 1);
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return 2131886774;
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887477;
    }

    public int getStartRegister()
    {
        return 26;
    }
}
