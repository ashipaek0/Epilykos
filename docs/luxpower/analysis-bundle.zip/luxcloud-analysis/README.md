# LuxCloud 5.0.0 analysis bundle

Start with [REPORT.md](REPORT.md). It compares this APK with Epilykos `dev` at commit `2792b1c179e8995831beebc670c823baed6ef1a4` and prioritizes corrections for both local Wi-Fi and Bluetooth source modes.

The strongest findings are the SOC low-byte correction, conditional BMS current scaling, local Wi-Fi TLS-PSK, and the app's BLE chunked write-without-response strategy. Transport compatibility and settings applicability still need hardware validation. No inverter was contacted during this analysis.

## Files

- `holding-register-map.json` / `.csv`: 1,200 family-scoped parameter/address associations, including packed bit and time aliases. These are not 1,200 distinct registers or a write allowlist. Unknown scaling and permissions remain null.
- `input-register-map.json` / `.csv`: 38 distinct app-referenced input starts, with semantics and conditions where established.
- `protocol-map.json`: framing, CRC, BLE and TLS transport details.
- `command-catalog.json`, `datalog-parameter-map.json`, `register-use-inventory.json`: other commands, separate dongle parameter space, and literal read/write uses.
- `evidence/`: selected Androguard sources, JADX app sources, Android manifest, settings assets, strings, class inventory and decompiler log. Decompiler output is evidence, not recompilable original source. JADX reported 276 errors across the APK.
- `comparison/`: Epilykos baseline excerpts, address crosswalk, reproduced decoder counterexamples and existing test-suite logs.
- `scripts/`: offline codec/tests, reproducible map extraction, explicit-target read-only probes, optional capture hooks.
- `package-inventory.json`: package metadata, archive/split integrity hashes and observed certificate fingerprint. This does not authenticate the mirror against a vendor release.
- `SHA256SUMS`: integrity manifest for all other bundle files.

## Offline checks

Run from this bundle's directory using Python 3:

```sh
python3 scripts/test_codec.py
```

The included tests cover framing, CRC, fragmentation, chunk sizes, PSK derivation, scale branches and map coverage. They do not prove hardware behavior.

Reproduce the full holding map from the included decompiler outputs into a separate directory:

```sh
python3 scripts/extract_registers.py evidence/androguard /tmp/luxcloud-map-rebuild
python3 scripts/enrich_registers.py evidence/jadx /tmp/luxcloud-map-rebuild
```

Both commands use only Python's standard library. The resulting holding JSON was compared in full with the delivered map and matched. This pair does not regenerate the manually reviewed input/protocol catalogues or the resolved register-use inventory.

To repeat the selected DAD decompilation, install Androguard and run `python3 scripts/decompile_android.py /path/to/base.apk /path/to/scratch-output`. Original APKs are not duplicated in this bundle. JADX version used: 1.5.6; see its log for errors.

## Optional live read-only diagnostics

These commands contact the specified device only when explicitly run. Replace example targets and serials with actual values; `DT00000001` is a placeholder. BLE resolution may scan for the supplied address. The probes send holding/input read commands, with no settings write or provisioning command.

```sh
python3 scripts/read_local.py wifi 10.10.10.1 --dongle DT00000001 --tls required
python3 scripts/read_local.py ble AA:BB:CC:DD:EE:FF --dongle DT00000001
```

Wi-Fi TLS-PSK needs Python 3.13+ and an OpenSSL build supporting `DHE-PSK-AES128-GCM-SHA256`. `--tls auto` explicitly permits fallback onto a fresh plain socket; `--tls off` selects legacy plain TCP. BLE needs Bleak and advertised write-without-response support. These runtime paths were not exercised against hardware.

The default request is app-style protocol 2, holding 0/count40, with a zero inverter serial for bootstrap. Existing Epilykos capture fixtures use protocol 5. Use `--protocol 5` and `--inverter ACTUALSN10` when appropriate to an established device; neither version is assumed universal. `ACTUALSN10` is also a ten-character placeholder.

`capture_app.js` contains optional Frida hooks for translated inverter TX/RX frames above either transport. It injects no commands and excludes C3/C4 provisioning payloads, but logs still contain device serials and values. Its runtime hooks need validation on a live app.

`compare_epilykos.js /path/to/installed/epilykos` reproduces the synthetic SOC and current examples without device access. Supply the checkout's dependencies via `NODE_PATH` if using an archived source snapshot. The report explains model-family restrictions and why the app's own apparent energy-counter truncation should not be copied.
