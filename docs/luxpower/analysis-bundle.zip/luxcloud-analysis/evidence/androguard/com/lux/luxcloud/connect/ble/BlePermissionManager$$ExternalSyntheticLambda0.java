package com.lux.luxcloud.connect.ble;
public final synthetic class BlePermissionManager$$ExternalSyntheticLambda0 implements androidx.activity.result.ActivityResultCallback {
    public final synthetic com.lux.luxcloud.connect.ble.BlePermissionManager f$0;

    public synthetic BlePermissionManager$$ExternalSyntheticLambda0(com.lux.luxcloud.connect.ble.BlePermissionManager p1)
    {
        this.f$0 = p1;
        return;
    }

    public final void onActivityResult(Object p2)
    {
        com.lux.luxcloud.connect.ble.BlePermissionManager.$r8$lambda$TqriMm5x8aPqYWFy99A_CJN3jeI(this.f$0, ((java.util.Map) p2));
        return;
    }
}
