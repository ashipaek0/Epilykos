package com.lux.luxcloud.global.bean.param;
final enum class PARAM$274 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$274(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$274(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p6)
    {
        com.lux.luxcloud.global.bean.inverter.Inverter v0 = p6.getCurrentInverter();
        boolean v1_1 = com.lux.luxcloud.global.bean.user.ROLE.VIEWER.equals(p6.getRole());
        if (((v1_1) && ((!this.isEg4(p6)) && ((v0.getSlaveVersionValue() < 33) || ((v0.getFwVersionValue() < 34) || (p6.isGigabiz1User()))))) && (((!v0.isType6SeriesWithoutTrip12K()) && ((!v0.isMidBox()) || (v0.isAllInOne()))) && ((!v0.isAcCharger()) && (!v0.isHybird())))) {
            if ((!this.isEg4(p6)) || ((!v0.isSnaSeries()) || (!v1_1))) {
                return 0;
            } else {
                return 1;
            }
        } else {
            return 1;
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return 2131886757;
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p2)
    {
        if (!com.lux.luxcloud.version.Custom.APP_USER_PLATFORM.equals(com.lux.luxcloud.global.bean.user.PLATFORM.EG4)) {
            return 2131886144;
        } else {
            return 2131886145;
        }
    }
}
