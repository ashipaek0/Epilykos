package com.lux.luxcloud.global.bean.param;
final enum class PARAM$176 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$176(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$176(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p5)
    {
        String v0_0 = p5.getCurrentInverter();
        int v1_11 = com.lux.luxcloud.global.GlobalInfo.getInstance().getCurrentClusterGroup();
        if (((!p5.isEnergy100User()) || ((v0_0.getDtcValue() != 0) || ((!v0_0.isSnaSeriesOrGeta()) && (!v0_0.isHybird())))) || (!"firstCluster".equals(v1_11))) {
            if (((!v0_0.isType6Series()) && (!v0_0.isGen3Series())) || ((v0_0.isAllInOne()) || (v0_0.getMachineType() == 1))) {
                if ((!v0_0.is12KUsVersion()) || (v0_0.getMachineType() == 1)) {
                    if ((!v0_0.isMidBox()) || (v0_0.getMachineType() == 1)) {
                        if (!v0_0.isSnaSeriesOrGeta()) {
                            return 0;
                        } else {
                            if ((!this.isAdmin(p5)) && (!"solarcom".equals(p5.getUsername()))) {
                                return 0;
                            } else {
                                return 1;
                            }
                        }
                    } else {
                        return 1;
                    }
                } else {
                    return 1;
                }
            } else {
                return 1;
            }
        } else {
            return 1;
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return 2131886853;
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887585;
    }

    public int getStartRegister()
    {
        return 216;
    }
}
