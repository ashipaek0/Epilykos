package com.lux.luxcloud.global.bean.param;
final enum class PARAM$203 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$203(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$203(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p3)
    {
        com.lux.luxcloud.global.bean.inverter.Inverter v0 = p3.getCurrentInverter();
        if (((this.isViewer(p3)) || ((!v0.isType6Series()) && (!v0.isGen3Series()))) || ((v0.getSlaveVersionValue() < 38) || (v0.getFwVersionValue() < 38))) {
            return 0;
        } else {
            return 1;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p2)
    {
        if (!com.lux.luxcloud.global.bean.user.PLATFORM.EG4.equals(com.lux.luxcloud.version.Custom.APP_USER_PLATFORM)) {
            return 2131887113;
        } else {
            return 2131887115;
        }
    }
}
