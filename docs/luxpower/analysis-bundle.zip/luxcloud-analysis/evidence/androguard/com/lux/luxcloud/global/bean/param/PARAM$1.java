package com.lux.luxcloud.global.bean.param;
final enum class PARAM$1 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$1(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$1(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    private void addPvInputModeOption(java.util.Map p1, String p2, int p3, android.content.Context p4)
    {
        p1.put(p2, p4.getString(p3));
        return;
    }

    private java.util.Map createPvInputModeDcSourceMap(android.content.Context p4)
    {
        java.util.LinkedHashMap v0_1 = new java.util.LinkedHashMap();
        this.addPvInputModeOption(v0_1, "0", 2131887559, p4);
        this.addPvInputModeOption(v0_1, "3", 2131887561, p4);
        this.addPvInputModeOption(v0_1, "4", 2131887567, p4);
        return v0_1;
    }

    private java.util.Map createPvInputModeDefaultMap(android.content.Context p4)
    {
        java.util.LinkedHashMap v0_1 = new java.util.LinkedHashMap();
        this.addPvInputModeOption(v0_1, "0", 2131887552, p4);
        this.addPvInputModeOption(v0_1, "1", 2131887553, p4);
        this.addPvInputModeOption(v0_1, "2", 2131887555, p4);
        this.addPvInputModeOption(v0_1, "3", 2131887557, p4);
        this.addPvInputModeOption(v0_1, "4", 2131887558, p4);
        return v0_1;
    }

    private java.util.Map createPvInputModeGen3_6KMap(android.content.Context p4)
    {
        java.util.LinkedHashMap v0_1 = new java.util.LinkedHashMap();
        this.addPvInputModeOption(v0_1, "0", 2131887563, p4);
        this.addPvInputModeOption(v0_1, "1", 2131887554, p4);
        this.addPvInputModeOption(v0_1, "2", 2131887556, p4);
        this.addPvInputModeOption(v0_1, "3", 2131887575, p4);
        this.addPvInputModeOption(v0_1, "4", 2131887572, p4);
        return v0_1;
    }

    private java.util.Map createPvInputModePvInMap(android.content.Context p4)
    {
        java.util.LinkedHashMap v0_1 = new java.util.LinkedHashMap();
        this.addPvInputModeOption(v0_1, "0", 2131887562, p4);
        this.addPvInputModeOption(v0_1, "1", 2131887571, p4);
        this.addPvInputModeOption(v0_1, "2", 2131887578, p4);
        this.addPvInputModeOption(v0_1, "3", 2131887575, p4);
        this.addPvInputModeOption(v0_1, "4", 2131887572, p4);
        return v0_1;
    }

    private java.util.Map createPvInputModeTrip12KMap(android.content.Context p4)
    {
        java.util.LinkedHashMap v0_1 = new java.util.LinkedHashMap();
        this.addPvInputModeOption(v0_1, "0", 2131887563, p4);
        this.addPvInputModeOption(v0_1, "1", 2131887574, p4);
        this.addPvInputModeOption(v0_1, "2", 2131887576, p4);
        this.addPvInputModeOption(v0_1, "3", 2131887579, p4);
        this.addPvInputModeOption(v0_1, "4", 2131887573, p4);
        return v0_1;
    }

    private java.util.Map createPvInputModeType6Map(android.content.Context p4)
    {
        java.util.LinkedHashMap v0_1 = new java.util.LinkedHashMap();
        this.addPvInputModeOption(v0_1, "0", 2131887562, p4);
        this.addPvInputModeOption(v0_1, "1", 2131887571, p4);
        this.addPvInputModeOption(v0_1, "2", 2131887578, p4);
        this.addPvInputModeOption(v0_1, "3", 2131887580, p4);
        this.addPvInputModeOption(v0_1, "4", 2131887569, p4);
        this.addPvInputModeOption(v0_1, "5", 2131887570, p4);
        this.addPvInputModeOption(v0_1, "6", 2131887577, p4);
        this.addPvInputModeOption(v0_1, "7", 2131887568, p4);
        return v0_1;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p2)
    {
        return (com.lux.luxcloud.global.bean.user.ROLE.VIEWER.equals(p2.getRole()) ^ 1);
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        if (!p1.getCurrentInverter().isSnaSeriesOrGetaOrGen3()) {
            return 2131886789;
        } else {
            return 2131886788;
        }
    }

    public Object getPlatformSpecificData(com.lux.luxcloud.global.UserData p5, android.content.Context p6)
    {
        com.lux.luxcloud.global.bean.inverter.Inverter v0 = p5.getCurrentInverter();
        if (v0 != null) {
            if ((com.lux.luxcloud.global.bean.user.PLATFORM.LUX_POWER.equals(p5.getPlatform())) || (com.lux.luxcloud.global.bean.user.PLATFORM.EG4.equals(p5.getPlatform()))) {
                if (!v0.isGen3Series()) {
                    if ((!v0.is7_10KDevice()) || ((!"HAAA".equals(v0.getStandard())) || ((v0.getSlaveVersionValue() < 7) || (v0.getFwVersionValue() < 6)))) {
                        if (!v0.isTrip12K()) {
                            if (!v0.isGen3_6K()) {
                                if ((!v0.isType6Series()) && ((!v0.is7_10KDevice()) && (!v0.isAllInOne()))) {
                                    if (!v0.isSnaSeriesOrGetaOrGen3()) {
                                        if ((!v0.isSnaSeries()) && (!v0.isLsp())) {
                                            return this.createDropdownFromMap(this.createPvInputModeDefaultMap(p6));
                                        }
                                    } else {
                                        return this.createDropdownFromMap(this.createPvInputModeDcSourceMap(p6));
                                    }
                                } else {
                                    return this.createDropdownFromMap(this.createPvInputModeType6Map(p6));
                                }
                            } else {
                                return this.createDropdownFromMap(this.createPvInputModeGen3_6KMap(p6));
                            }
                        } else {
                            return this.createDropdownFromMap(this.createPvInputModeTrip12KMap(p6));
                        }
                    } else {
                        return this.createDropdownFromMap(this.createPvInputModePvInMap(p6));
                    }
                } else {
                    return this.createDropdownFromMap(this.createPvInputModeDcSourceMap(p6));
                }
            }
            return 0;
        } else {
            return 0;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887551;
    }

    public int getStartRegister()
    {
        return 20;
    }
}
