package com.lux.luxcloud.global.bean.param;
final enum class PARAM$386 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$386(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$386(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p1)
    {
        if (!p1.getCurrentInverter().isSnaSeriesOrGeta()) {
            return 0;
        } else {
            return 1;
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        if (!p1.getCurrentInverter().isMidBox()) {
            return 2131886728;
        } else {
            return -1;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887093;
    }
}
