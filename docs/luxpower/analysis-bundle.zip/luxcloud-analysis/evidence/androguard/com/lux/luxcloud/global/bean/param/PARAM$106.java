package com.lux.luxcloud.global.bean.param;
final enum class PARAM$106 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$106(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$106(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p5)
    {
        boolean v0_0 = p5.getCurrentInverter();
        if (!v0_0.isGen3Series()) {
            if ((!v0_0.isType6Series()) || (v0_0.isAllInOne())) {
                if ((!v0_0.isHybird()) && (!v0_0.isAcCharger())) {
                    return 0;
                } else {
                    return (this.isViewer(p5) ^ 1);
                }
            } else {
                return 1;
            }
        } else {
            return 0;
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return 2131886635;
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131886219;
    }

    public int getStartRegister()
    {
        return 113;
    }
}
