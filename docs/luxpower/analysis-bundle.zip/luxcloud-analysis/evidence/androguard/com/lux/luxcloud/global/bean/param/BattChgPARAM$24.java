package com.lux.luxcloud.global.bean.param;
final enum class BattChgPARAM$24 extends com.lux.luxcloud.global.bean.param.BattChgPARAM {

    private BattChgPARAM$24(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic BattChgPARAM$24(String p1, int p2, com.lux.luxcloud.global.bean.param.BattChgPARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkEnabled(String p2)
    {
        return "VOLT".equals(p2);
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p2)
    {
        if (!p2.isType6()) {
            if (!p2.isSnaSeries()) {
                return -1;
            } else {
                return 2131887287;
            }
        } else {
            return 2131887601;
        }
    }

    public int getStartRegister()
    {
        return 159;
    }
}
