package com.lux.luxcloud.global.bean.param;
final enum class PARAM$194 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$194(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$194(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p5)
    {
        com.lux.luxcloud.global.bean.inverter.Inverter v0 = p5.getCurrentInverter();
        if ((!v0.isEQB()) && (!v0.isMidBox())) {
            if ((!v0.isHybird()) || (v0.getPhaseValue().intValue() != 1)) {
                if ((!com.lux.luxcloud.global.bean.param.PARAM$194.FUNC_RSD_DISABLE.checkVisible(p5)) && ((!com.lux.luxcloud.global.bean.param.PARAM$194.FUNC_PV_ARC.checkVisible(p5)) && ((!com.lux.luxcloud.global.bean.param.PARAM$194.FUNC_PV_ARC_FAULT_CLEAR.checkVisible(p5)) || (!v0.isType6Series())))) {
                    return 0;
                } else {
                    return 1;
                }
            } else {
                return 0;
            }
        } else {
            return 0;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        if (!p1.isType6Series()) {
            return 2131886306;
        } else {
            return 2131887680;
        }
    }
}
