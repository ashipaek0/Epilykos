package com.lux.luxcloud.global.bean.param;
final enum class PARAM$190 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$190(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$190(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p5)
    {
        if (!this.isLocal(p5)) {
            boolean v5_2;
            boolean v0_2 = p5.getCurrentInverter();
            if ((!v0_2.isAcCharger()) && (!v0_2.isHybird())) {
                if (!v0_2.isSnaSeries()) {
                    if (!v0_2.isEQB()) {
                        if ((!v0_2.isMidBox()) || (!this.isLocal(p5))) {
                            return 1;
                        } else {
                            return 0;
                        }
                    } else {
                        return 0;
                    }
                } else {
                    v5_2 = this.isViewer(p5);
                }
            } else {
                v5_2 = this.isViewer(p5);
            }
            return (v5_2 ^ 1);
        } else {
            return 0;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131886288;
    }
}
