package com.lux.luxcloud.global.bean.param;
final enum class PARAM$143 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$143(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$143(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p2)
    {
        int v2_1 = p2.getCurrentInverter();
        if ((!v2_1.isSnaSeriesOrGeta()) && (!v2_1.isGen3Series())) {
            return 0;
        } else {
            return 1;
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return 2131886796;
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887311;
    }

    public int getStartRegister()
    {
        return 168;
    }
}
