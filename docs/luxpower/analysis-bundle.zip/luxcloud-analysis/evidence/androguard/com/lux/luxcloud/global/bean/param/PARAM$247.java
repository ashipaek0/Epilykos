package com.lux.luxcloud.global.bean.param;
final enum class PARAM$247 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$247(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$247(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p7)
    {
        int v0_0 = p7.getRole();
        int v1_1 = p7.getCurrentInverter();
        if (((!v1_1.isType6Series()) && (!v1_1.isGen3Series())) || (v1_1.isAllInOne())) {
            if (!v1_1.isMidBox()) {
                if (!v1_1.isSnaSeriesOrGeta()) {
                    if (v1_1.isHybird()) {
                        int v0_2 = v1_1.getStandard();
                        int v2_4 = v1_1.getSlaveVersionValue();
                        int v1_0 = v1_1.getFwVersionValue();
                        if (((("AAAA".equalsIgnoreCase(v0_2)) && ((v2_4 >= 36) && (v1_0 >= 32))) || (("AAAB".equalsIgnoreCase(v0_2)) && ((v2_4 >= 29) && (v1_0 >= 26)))) && (!com.lux.luxcloud.global.bean.user.ROLE.VIEWER.equals(p7.getRole()))) {
                            return 1;
                        }
                    }
                    return 0;
                } else {
                    if ((!this.isAdmin(p7)) && (!com.lux.luxcloud.global.bean.user.ROLE.INSTALLER.equals(v0_0))) {
                        return 0;
                    } else {
                        return 1;
                    }
                }
            } else {
                if ((this.isViewer(p7)) && (!this.isEg4(p7))) {
                    return 0;
                } else {
                    return 1;
                }
            }
        } else {
            if ((this.isViewer(p7)) && (!this.isEg4(p7))) {
                return 0;
            } else {
                return 1;
            }
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        if (!p1.getCurrentInverter().isSnaSeries()) {
            return 2131887116;
        } else {
            return 2131886819;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p2)
    {
        if (((!p2.isMidBox()) && ((!p2.isType6()) || (p2.isAllInOne()))) && ((p2.is12KEUVersion()) && (p2.is12KUsVersion()))) {
            return 2131887114;
        } else {
            return 2131887112;
        }
    }
}
