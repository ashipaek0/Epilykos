package com.lux.luxcloud.global.bean.param;
final enum class PARAM$246 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$246(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$246(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p5)
    {
        boolean v0_0 = p5.getCurrentInverter();
        if ((!v0_0.isType6Series()) && ((!v0_0.isGen3Series()) && (!v0_0.isMidBox()))) {
            if (!v0_0.isSnaSeries()) {
                if (!v0_0.isGeta()) {
                    return 0;
                } else {
                    if (v0_0.getPhaseValue().intValue() != 3) {
                        return this.isAdmin(p5);
                    } else {
                        if (((!this.isAdmin(p5)) && ((!this.isMAINTAIN(p5)) && ((!this.isAdmin(p5)) || (!this.isEg4(p5))))) && ((this.isEg4(p5)) || (!this.isViewer(p5)))) {
                            return 0;
                        } else {
                            return 1;
                        }
                    }
                }
            } else {
                return 1;
            }
        } else {
            if ((!this.isAdmin(p5)) && (!this.isMAINTAIN(p5))) {
                return 0;
            } else {
                return 1;
            }
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return 2131886850;
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        if (!p1.isSnaSeries()) {
            return 2131887106;
        } else {
            return 2131887135;
        }
    }
}
