package com.lux.luxcloud.connect.ble;
public class BlePermissionManager {
    private com.lux.luxcloud.connect.ble.BlePermissionManager$Callback callback;
    private final androidx.activity.result.ActivityResultLauncher launcher;
    private boolean requesting;

    public static synthetic void $r8$lambda$TqriMm5x8aPqYWFy99A_CJN3jeI(com.lux.luxcloud.connect.ble.BlePermissionManager p0, java.util.Map p1)
    {
        p0.onPermissionResult(p1);
        return;
    }

    public BlePermissionManager(androidx.appcompat.app.AppCompatActivity p3)
    {
        this.requesting = 0;
        this.launcher = p3.registerForActivityResult(new androidx.activity.result.contract.ActivityResultContracts$RequestMultiplePermissions(), new com.lux.luxcloud.connect.ble.BlePermissionManager$$ExternalSyntheticLambda0(this));
        return;
    }

    private static String[] getBlePermissions()
    {
        String[] v0_1 = new java.util.ArrayList();
        v0_1.add("android.permission.ACCESS_FINE_LOCATION");
        if (android.os.Build$VERSION.SDK_INT >= 31) {
            v0_1.add("android.permission.BLUETOOTH_SCAN");
            v0_1.add("android.permission.BLUETOOTH_CONNECT");
        }
        String[] v1_1 = new String[0];
        return ((String[]) v0_1.toArray(v1_1));
    }

    private static boolean hasAllPermissions(android.app.Activity p4, String[] p5)
    {
        int v2 = 0;
        while (v2 < p5.length) {
            if (p4.checkSelfPermission(p5[v2]) == 0) {
                v2++;
            } else {
                return 0;
            }
        }
        return 1;
    }

    private void onPermissionResult(java.util.Map p4)
    {
        int v0 = 0;
        this.requesting = 0;
        com.lux.luxcloud.connect.ble.BlePermissionManager$Callback v4_3 = p4.values().iterator();
        while (v4_3.hasNext()) {
            if (!Boolean.TRUE.equals(((Boolean) v4_3.next()))) {
            }
            com.lux.luxcloud.connect.ble.BlePermissionManager$Callback v4_1 = this.callback;
            if (v4_1 != null) {
                if (v0 == 0) {
                    v4_1.onDenied();
                    return;
                } else {
                    v4_1.onGranted();
                    return;
                }
            } else {
                return;
            }
        }
        v0 = 1;
    }

    public void ensurePermissions(android.app.Activity p2, com.lux.luxcloud.connect.ble.BlePermissionManager$Callback p3)
    {
        if (!this.requesting) {
            this.callback = p3;
            String[] v0_1 = com.lux.luxcloud.connect.ble.BlePermissionManager.getBlePermissions();
            if (!com.lux.luxcloud.connect.ble.BlePermissionManager.hasAllPermissions(p2, v0_1)) {
                this.requesting = 1;
                this.launcher.launch(v0_1);
                return;
            } else {
                p3.onGranted();
                return;
            }
        } else {
            return;
        }
    }
}
