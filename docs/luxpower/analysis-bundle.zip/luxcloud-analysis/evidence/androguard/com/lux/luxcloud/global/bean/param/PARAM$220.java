package com.lux.luxcloud.global.bean.param;
final enum class PARAM$220 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$220(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$220(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p5)
    {
        boolean v0_0 = p5.getRole();
        com.lux.luxcloud.global.bean.user.ROLE v1_3 = p5.getCurrentInverter();
        if (!v1_3.isGen3Series()) {
            if ((!v1_3.isType6Series()) && (!v1_3.isFlexSeries())) {
                return 0;
            } else {
                if ((!this.isEg4Admin(p5)) && ((!com.lux.luxcloud.global.bean.user.ROLE.ADMIN.equals(v0_0)) && (!this.isMAINTAIN(p5)))) {
                    return 0;
                } else {
                    return 1;
                }
            }
        } else {
            return 0;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131886118;
    }
}
