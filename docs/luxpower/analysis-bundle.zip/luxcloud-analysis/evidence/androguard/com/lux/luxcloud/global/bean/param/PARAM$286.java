package com.lux.luxcloud.global.bean.param;
final enum class PARAM$286 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$286(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$286(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p8)
    {
        boolean v0_0 = p8.getCurrentInverter();
        p8.getRole();
        int v1 = v0_0.getSlaveVersionValue();
        String v2 = v0_0.getStandard();
        if ((!v0_0.isAllInOne()) && (!v0_0.isAcCharger())) {
            if ((!v0_0.isSnaSeries()) && ((!v0_0.isSna2_12k_EU()) && (!v0_0.isSna3_6K_eu()))) {
                return 1;
            } else {
                if ((((!v0_0.isSunKing()) || ((!"cbba".equals(v2)) || (v1 < 10))) && ((!v0_0.isGeta()) && ((v0_0.getDeviceTypeValue() != 3) || (((!"cbaa".equals(v2)) || (v1 < 36)) && (((!"cBaa".equals(v2)) || (v1 < 141)) && (((!"cBAA".equals(v2)) || (v1 < 141)) && ((v0_0.getDtcValue() != 1) || ((!"ccaa".equals(v2)) || (v1 < 18))))))))) && ((v0_0.getDeviceTypeValue() != 11) || (((v0_0.getDtcValue() != 1) || ((!"ceaa".equals(v2)) || (v1 < 6))) && ((!"cfaa".equals(v2)) || (v1 < 6))))) {
                    return 0;
                } else {
                    return (this.isViewer(p8) ^ 1);
                }
            }
        } else {
            return 0;
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        if (!p1.getCurrentInverter().isHybird()) {
            return 2131886862;
        } else {
            return -1;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887752;
    }
}
