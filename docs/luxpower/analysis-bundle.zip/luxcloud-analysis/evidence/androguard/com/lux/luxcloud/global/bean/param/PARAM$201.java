package com.lux.luxcloud.global.bean.param;
final enum class PARAM$201 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$201(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$201(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p2)
    {
        if ((!this.isAdmin(p2)) && (!this.isMAINTAIN(p2))) {
            return 0;
        } else {
            return 1;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131886604;
    }
}
