package com.lux.luxcloud.global.bean.param;
final enum class PARAM$272 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$272(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$272(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    private java.util.Map createSnaScheduleModeMap(android.content.Context p4)
    {
        java.util.LinkedHashMap v0_1 = new java.util.LinkedHashMap();
        v0_1.put("-1", p4.getString(2131887308));
        v0_1.put("0", p4.getString(2131887302));
        v0_1.put("1", p4.getString(2131887303));
        v0_1.put("2", p4.getString(2131887304));
        v0_1.put("3", p4.getString(2131887305));
        v0_1.put("4", p4.getString(2131887306));
        v0_1.put("5", p4.getString(2131887307));
        return v0_1;
    }

    private java.util.Map createSocVoltScheduleModeMap(com.lux.luxcloud.global.bean.inverter.Inverter p4, boolean p5, android.content.Context p6)
    {
        java.util.LinkedHashMap v0_1 = new java.util.LinkedHashMap();
        v0_1.put("-1", p6.getString(2131887308));
        v0_1.put("0", p6.getString(2131887303));
        v0_1.put("1", p6.getString(2131887309));
        if ((p5 != null) && (p4.getPhase().intValue() == 1)) {
            v0_1.put("2", p6.getString(2131887310));
        }
        return v0_1;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p2)
    {
        int v2_1 = p2.getCurrentInverter();
        if (!v2_1.isAcCharger()) {
            if (!v2_1.isHybird()) {
                return 1;
            } else {
                return this.checkHybridFirmware20240811(v2_1);
            }
        } else {
            return 0;
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return 2131886795;
    }

    public Object getPlatformSpecificData(com.lux.luxcloud.global.UserData p7, android.content.Context p8)
    {
        com.lux.luxcloud.global.bean.inverter.Inverter v0 = p7.getCurrentInverter();
        if (v0 != null) {
            if ((!com.lux.luxcloud.global.bean.user.PLATFORM.LUX_POWER.equals(p7.getPlatform())) && (!com.lux.luxcloud.global.bean.user.PLATFORM.MID.equals(p7.getPlatform()))) {
                if (com.lux.luxcloud.global.bean.user.PLATFORM.EG4.equals(p7.getPlatform())) {
                    if (!v0.isSnaSeriesOrGeta()) {
                        if (!v0.isType6Series()) {
                            if ((v0.isAllInOne()) || ((v0.isMidBox()) || (v0.isHybird()))) {
                                return this.createDropdownFromMap(this.createSocVoltScheduleModeMap(v0, 0, p8));
                            }
                        } else {
                            return this.createDropdownFromMap(this.createSocVoltScheduleModeMap(v0, 1, p8));
                        }
                    } else {
                        return this.createDropdownFromMap(this.createSnaScheduleModeMap(p8));
                    }
                }
            } else {
                if (!v0.isSnaSeriesOrGeta()) {
                    if ((!v0.isType6Series()) && (!v0.isMidBox())) {
                        if ((v0.isAllInOne()) || (v0.isHybird())) {
                            return this.createDropdownFromMap(this.createSocVoltScheduleModeMap(v0, 0, p8));
                        }
                    } else {
                        return this.createDropdownFromMap(this.createSocVoltScheduleModeMap(v0, 1, p8));
                    }
                } else {
                    return this.createDropdownFromMap(this.createSnaScheduleModeMap(p8));
                }
            }
            return 0;
        } else {
            return 0;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131886108;
    }
}
