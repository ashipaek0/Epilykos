package com.lux.luxcloud.global.bean.param;
final enum class HOLD_PARAM$1 extends com.lux.luxcloud.global.bean.param.HOLD_PARAM {

    private HOLD_PARAM$1(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic HOLD_PARAM$1(String p1, int p2, com.lux.luxcloud.global.bean.param.HOLD_PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public com.lux.luxcloud.global.bean.param.PARAM_VALUE_TYPE getParamValueType()
    {
        return com.lux.luxcloud.global.bean.param.PARAM_VALUE_TYPE.TEXT;
    }

    public int getRegisterCount()
    {
        return 11;
    }

    public int getStartRegister()
    {
        return 359;
    }

    public boolean isWritable()
    {
        return 1;
    }
}
