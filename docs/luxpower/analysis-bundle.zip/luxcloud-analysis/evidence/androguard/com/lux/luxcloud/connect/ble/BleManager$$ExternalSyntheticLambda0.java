package com.lux.luxcloud.connect.ble;
public final synthetic class BleManager$$ExternalSyntheticLambda0 implements java.lang.Runnable {
    public final synthetic com.lux.luxcloud.connect.ble.BleManager f$0;
    public final synthetic long f$1;
    public final synthetic android.bluetooth.le.ScanCallback f$2;
    public final synthetic com.lux.luxcloud.connect.ble.BleManager$ScanFinishCallback f$3;

    public synthetic BleManager$$ExternalSyntheticLambda0(com.lux.luxcloud.connect.ble.BleManager p1, long p2, android.bluetooth.le.ScanCallback p4, com.lux.luxcloud.connect.ble.BleManager$ScanFinishCallback p5)
    {
        this.f$0 = p1;
        this.f$1 = p2;
        this.f$2 = p4;
        this.f$3 = p5;
        return;
    }

    public final void run()
    {
        com.lux.luxcloud.connect.ble.BleManager.$r8$lambda$vNdVIKtFybsnYLeLIWKFsOWQKak(this.f$0, this.f$1, this.f$2, this.f$3);
        return;
    }
}
