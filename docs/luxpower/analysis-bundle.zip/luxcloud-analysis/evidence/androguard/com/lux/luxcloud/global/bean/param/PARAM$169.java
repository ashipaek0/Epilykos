package com.lux.luxcloud.global.bean.param;
final enum class PARAM$169 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$169(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$169(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p4)
    {
        boolean v0_0 = p4.getCurrentInverter();
        if (!v0_0.isGen3Series()) {
            if ((!v0_0.isType6Series()) || (v0_0.isAllInOne())) {
                return 0;
            } else {
                if ((this.isViewer(p4)) && (!this.isEg4(p4))) {
                    return 0;
                } else {
                    return 1;
                }
            }
        } else {
            return 0;
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return 2131886773;
    }

    public Object getPlatformSpecificData(com.lux.luxcloud.global.UserData p9, android.content.Context p10)
    {
        String v9_1 = p9.getCurrentInverter();
        if (v9_1 != null) {
            java.util.Set v0_1 = new java.util.LinkedHashMap();
            if (!v9_1.isTrip12K()) {
                v0_1.put("0", "0: 240V/120V");
                v0_1.put("1", "1: 208V/120V");
                v0_1.put("2", "2: 240V");
                v0_1.put("3", "3: 230V");
                v0_1.put("4", "4: 200V/100V");
                if (((v9_1.isType6()) && ((v9_1.getSlaveVersionValue() >= 31) && (v9_1.getFwVersionValue() >= 31))) || (v9_1.isMega24K())) {
                    v0_1.put("5", "5: 220V/127V");
                }
            } else {
                v0_1.put("0", "0: 230V/230V");
                v0_1.put("1", "1: 120V/208V");
                v0_1.put("2", "2: 240V/415V");
                v0_1.put("3", "3: 230V/400V");
                v0_1.put("4", "4: Rsvd");
                v0_1.put("5", "5: 220V/380V");
                if (v9_1.isTrip12KLv()) {
                    v0_1.put("6", "6: 220/220V");
                    v0_1.put("7", "7: 240/240V");
                    v0_1.put("8", "8: 127V/220V");
                    v0_1.put("9", "9: 138V/240V");
                }
            }
            if (v0_1.isEmpty()) {
                return 0;
            } else {
                int v1_19 = new String[0];
                String[] v10_2 = new String[0];
                return this.createDropdown(((String[]) v0_1.values().toArray(v1_19)), ((String[]) v0_1.keySet().toArray(v10_2)));
            }
        } else {
            return 0;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887476;
    }

    public int getStartRegister()
    {
        return 205;
    }
}
