package com.lux.luxcloud.global.bean.inverter;
public class Inverter implements java.io.Serializable {
    private boolean allowExport2Grid;
    private boolean allowGenExercise;
    private Integer batCurrUnit;
    private String batParallelNum;
    private com.lux.luxcloud.global.bean.inverter.BATTERY_TYPE batteryTypeFromModel;
    private String datalogSn;
    private Integer deviceType;
    private Integer dtc;
    private String fwCode;
    private Integer fwVersion;
    private int hardwareVersion;
    private com.lux.luxcloud.global.bean.inverter.InverterData7 inverterData7;
    private Integer leadAcidType;
    private int machineType;
    private String masterInverterSn;
    private Long model;
    private Integer odm;
    private String parallelFirstDeviceSn;
    private String parallelGroup;
    private Integer phase;
    private Long plantId;
    private Integer powerRating;
    private Integer protocolVersion;
    private String serialNum;
    private Integer slaveVersion;
    private String standard;
    private Integer subDeviceType;
    private Integer usVersion;
    private Integer voltClass;
    private Boolean withbatteryData;

    public Inverter()
    {
        return;
    }

    public boolean checkAllowGenExercise()
    {
        if ((this.isType6()) && ((!com.lux.luxcloud.tool.Tool.isEmpty(this.standard)) && ((this.standard.equals("eAAB")) || ((this.standard.equals("EAAB")) || ((this.standard.equals("fAAB")) || (this.standard.equals("FAAB"))))))) {
            this.checkSlaveVersion();
            this.checkFwVersion();
            int v0_14 = this.slaveVersion;
            if ((v0_14 != 0) && (v0_14.intValue() >= 24)) {
                int v0_16 = this.fwVersion;
                if ((v0_16 != 0) && (v0_16.intValue() >= 24)) {
                    return 1;
                }
            }
        }
        if ((!this.isTrip12K()) && (!this.isHybird())) {
            int v0_21 = this.getDtcValue();
            if ((!this.isOffGrid()) || ((((!"cbaa".equalsIgnoreCase(this.standard)) || (this.slaveVersion.intValue() < 36)) && (((!"cBaa".equals(this.standard)) && (!"cBAA".equals(this.standard))) || (this.slaveVersion.intValue() < 141))) && ((v0_21 != 1) || ((!"ccaa".equalsIgnoreCase(this.standard)) || (this.slaveVersion.intValue() < 18))))) {
                if ((!this.isSna12K()) || (((v0_21 != 1) || ((!"ceaa".equalsIgnoreCase(this.standard)) || (this.slaveVersion.intValue() < 6))) && ((!"cfaa".equalsIgnoreCase(this.standard)) || (this.slaveVersion.intValue() < 6)))) {
                    return 0;
                } else {
                    return 1;
                }
            } else {
                return 1;
            }
        } else {
            return 1;
        }
    }

    public void checkFwVersion()
    {
        try {
            if ((this.fwVersion == null) && ((!com.lux.luxcloud.tool.Tool.isEmpty(this.fwCode)) && (this.fwCode.length() >= 9))) {
                this.fwVersion = Integer.valueOf(Integer.parseInt(this.fwCode.substring(7, 9), 16));
            }
        } catch (Exception) {
        }
        return;
    }

    public void checkSlaveVersion()
    {
        try {
            if ((this.slaveVersion == null) && ((!com.lux.luxcloud.tool.Tool.isEmpty(this.fwCode)) && (this.fwCode.length() >= 9))) {
                this.slaveVersion = Integer.valueOf(Integer.parseInt(this.fwCode.substring(5, 7), 16));
            }
        } catch (Exception) {
        }
        return;
    }

    public boolean checkSupportQuickDisCharge()
    {
        if ((!this.isHybird()) || ((this.isAcCharger()) || ((this.isPhase3()) || (this.isParallelGroup())))) {
            return 0;
        } else {
            return 1;
        }
    }

    public Integer getBatCurrUnit()
    {
        return this.batCurrUnit;
    }

    public String getBatParallelNum()
    {
        return this.batParallelNum;
    }

    public com.lux.luxcloud.global.bean.inverter.BATTERY_TYPE getBatteryTypeFromModel()
    {
        return this.batteryTypeFromModel;
    }

    public String getDatalogSn()
    {
        return this.datalogSn;
    }

    public Integer getDeviceType()
    {
        return this.deviceType;
    }

    public int getDeviceTypeValue()
    {
        int v0_0 = this.deviceType;
        if (v0_0 == 0) {
            return 0;
        } else {
            return v0_0.intValue();
        }
    }

    public Integer getDtc()
    {
        return this.dtc;
    }

    public int getDtcValue()
    {
        int v0_0 = this.dtc;
        if (v0_0 != 0) {
            return v0_0.intValue();
        } else {
            return -1;
        }
    }

    public String getFwCode()
    {
        return this.fwCode;
    }

    public Integer getFwVersion()
    {
        return this.fwVersion;
    }

    public int getFwVersionValue()
    {
        int v0_0 = this.fwVersion;
        if (v0_0 == 0) {
            return -1;
        } else {
            return v0_0.intValue();
        }
    }

    public int getHardwareVersion()
    {
        return this.hardwareVersion;
    }

    public com.lux.luxcloud.global.bean.inverter.InverterData7 getInverterData7()
    {
        return this.inverterData7;
    }

    public Integer getLeadAcidCapacity()
    {
        Integer v0_0 = this.leadAcidType;
        if (v0_0 != null) {
            switch (v0_0.intValue()) {
                case 0:
                    return Integer.valueOf(50);
                case 1:
                    return Integer.valueOf(100);
                case 2:
                    return Integer.valueOf(150);
                case 3:
                    return Integer.valueOf(200);
                case 4:
                    return Integer.valueOf(250);
                case 5:
                    return Integer.valueOf(300);
                case 6:
                    return Integer.valueOf(350);
                case 7:
                    return Integer.valueOf(400);
                case 8:
                    return Integer.valueOf(450);
                case 9:
                    return Integer.valueOf(500);
                case 10:
                    return Integer.valueOf(550);
                case 11:
                    return Integer.valueOf(600);
                case 12:
                    return Integer.valueOf(650);
                default:
            }
        }
        return Integer.valueOf(-1);
    }

    public Integer getLeadAcidType()
    {
        return this.leadAcidType;
    }

    public int getMachineType()
    {
        return this.machineType;
    }

    public String getMasterInverterSn()
    {
        return this.masterInverterSn;
    }

    public Long getModel()
    {
        return this.model;
    }

    public Integer getOdm()
    {
        return this.odm;
    }

    public Integer getOdmValue()
    {
        Integer v0_1;
        Integer v0_0 = this.odm;
        if (v0_0 != null) {
            v0_1 = v0_0.intValue();
        } else {
            v0_1 = -1;
        }
        return Integer.valueOf(v0_1);
    }

    public String getParallelFirstDeviceSn()
    {
        return this.parallelFirstDeviceSn;
    }

    public Integer getPhase()
    {
        return this.phase;
    }

    public Integer getPhaseValue()
    {
        Integer v0_1;
        Integer v0_0 = this.phase;
        if (v0_0 != null) {
            v0_1 = v0_0.intValue();
        } else {
            v0_1 = -1;
        }
        return Integer.valueOf(v0_1);
    }

    public Long getPlantId()
    {
        return this.plantId;
    }

    public Integer getPowerRating()
    {
        return this.powerRating;
    }

    public int getPowerRatingValue()
    {
        int v0_0 = this.powerRating;
        if (v0_0 == 0) {
            return -1;
        } else {
            return v0_0.intValue();
        }
    }

    public Integer getProtocolVersion()
    {
        return this.protocolVersion;
    }

    public String getSerialNum()
    {
        return this.serialNum;
    }

    public Integer getSlaveVersion()
    {
        return this.slaveVersion;
    }

    public int getSlaveVersionValue()
    {
        int v0_0 = this.slaveVersion;
        if (v0_0 == 0) {
            return -1;
        } else {
            return v0_0.intValue();
        }
    }

    public String getStandard()
    {
        return this.standard;
    }

    public Integer getSubDeviceType()
    {
        return this.subDeviceType;
    }

    public int getSubDeviceTypeValue()
    {
        int v0_0 = this.subDeviceType;
        if (v0_0 == 0) {
            return -1;
        } else {
            return v0_0.intValue();
        }
    }

    public Integer getUsVersion()
    {
        return this.usVersion;
    }

    public int getUsVersionValue()
    {
        int v0_0 = this.usVersion;
        if (v0_0 == 0) {
            return -1;
        } else {
            return v0_0.intValue();
        }
    }

    public Integer getVoltClass()
    {
        return this.voltClass;
    }

    public int getVoltClassValue()
    {
        int v0_0 = this.voltClass;
        if (v0_0 == 0) {
            return -1;
        } else {
            return v0_0.intValue();
        }
    }

    public Boolean getWithbatteryData()
    {
        return this.withbatteryData;
    }

    public boolean is12000XP()
    {
        int v0_0 = this.deviceType;
        if ((v0_0 != 0) && ((v0_0.intValue() == 11) && (!this.isPhase3()))) {
            int v0_5 = this.dtc;
            if ((v0_5 != 0) && (v0_5.intValue() == 1)) {
                return 1;
            }
        }
        return 0;
    }

    public boolean is12KEUVersion()
    {
        if (this.isType6()) {
            int v0_2 = this.usVersion;
            if ((v0_2 != 0) && (v0_2.intValue() == com.lux.luxcloud.global.Constants.MODEL_EU_VERSION_US)) {
                return 1;
            }
        }
        return 0;
    }

    public boolean is12KUsVersion()
    {
        if (this.isType6()) {
            int v0_2 = this.usVersion;
            if ((v0_2 != 0) && (v0_2.intValue() == com.lux.luxcloud.global.Constants.MODEL_US_VERSION_US)) {
                return 1;
            }
        }
        return 0;
    }

    public boolean is6000XP()
    {
        int v0_0 = this.deviceType;
        if ((v0_0 != 0) && (v0_0.intValue() == 3)) {
            int v0_6 = this.phase;
            if ((v0_6 == 0) || (v0_6.intValue() != 3)) {
                int v0_1 = this.dtc;
                if ((v0_1 != 0) && ((v0_1.intValue() == 1) && (this.machineType == 0))) {
                    return 1;
                }
            }
        }
        return 0;
    }

    public boolean is7_10KDevice()
    {
        int v0_0 = this.deviceType;
        if ((v0_0 == 0) || (v0_0.intValue() != 8)) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isAcCharger()
    {
        int v0_0 = this.deviceType;
        if ((v0_0 == 0) || (v0_0.intValue() != 2)) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isAllInOne()
    {
        int v0_0 = this.deviceType;
        if ((v0_0 == 0) || (v0_0.intValue() != 7)) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isAllowExport2Grid()
    {
        return this.allowExport2Grid;
    }

    public boolean isAllowGenExercise()
    {
        return this.allowGenExercise;
    }

    public boolean isBatCurrUnit10()
    {
        if ((!this.isAcCharger()) && (!this.isTrip12K())) {
            if ((!this.isType6()) && ((!this.isAllInOne()) && (!this.is7_10KDevice()))) {
                int v0_3 = this.batCurrUnit;
                if ((v0_3 == 0) || (v0_3.intValue() != 1)) {
                    return 0;
                } else {
                    return 1;
                }
            } else {
                return 1;
            }
        } else {
            return 0;
        }
    }

    public boolean isBess200K()
    {
        int v0_0 = this.deviceType;
        if ((v0_0 == 0) || ((v0_0.intValue() != 14) || (!this.isPhase3()))) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isDtcAmerica()
    {
        int v0_0 = this.dtc;
        if ((v0_0 == 0) || (v0_0.intValue() != 1)) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isEQB()
    {
        int v0_0 = this.deviceType;
        if ((v0_0 == 0) || ((v0_0.intValue() != 9) || (this.machineType != 2))) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isEcoBeast6k()
    {
        if ((!this.isOffGrid()) || ((this.isDtcAmerica()) || (this.machineType != 4))) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isEcoBeast6kPro()
    {
        if ((!this.isOffGrid()) || ((this.isDtcAmerica()) || ((this.isPhase3()) || (this.machineType != 5)))) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isEconex_6k()
    {
        if ((this.isOffGrid()) && (!this.isPhase3())) {
            int v0_4 = this.dtc;
            if ((v0_4 != 0) && ((v0_4.intValue() == 1) && (this.machineType == 5))) {
                return 1;
            }
        }
        return 0;
    }

    public boolean isFlexBoss100()
    {
        if ((!this.isType6()) || ((!this.isHighVoltBattery()) || ((this.isPhase3()) || ((this.getMachineType() != 1) || ((this.getPowerRatingValue() != 12) || (this.getOdmValue().intValue() != 4)))))) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isFlexBoss18()
    {
        if ((!this.isType6()) || ((this.getMachineType() != 1) || ((this.getPowerRatingValue() != 9) || (this.getOdmValue().intValue() != 4)))) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isFlexBoss21()
    {
        if ((!this.isType6()) || ((this.getMachineType() != 1) || ((this.getPowerRatingValue() != 8) || (this.getOdmValue().intValue() != 4)))) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isFlexSeries()
    {
        if ((!this.isFlexBoss18()) && ((!this.isFlexBoss21()) && (!this.isFlexBoss100()))) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isGen1_7_10K()
    {
        int v0_0 = this.deviceType;
        if ((v0_0 == 0) || ((v0_0.intValue() != 8) || ((this.isPhase3()) || (this.machineType != 0)))) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isGen2_7_14K()
    {
        int v0_0 = this.deviceType;
        if ((v0_0 == 0) || ((v0_0.intValue() != 8) || ((this.isPhase3()) || (this.machineType != 1)))) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isGen3()
    {
        int v0_0 = this.deviceType;
        if ((v0_0 == 0) || ((v0_0.intValue() != 8) || (this.machineType != 2))) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isGen3Pro()
    {
        int v0_0 = this.deviceType;
        if ((v0_0 == 0) || ((v0_0.intValue() != 8) || ((this.machineType != 2) || (this.getPowerRatingValue() < 8)))) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isGen3Series()
    {
        if ((!this.isGen3()) && (!this.isGen3Pro())) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isGen3_6K()
    {
        int v0_0 = this.deviceType;
        if ((v0_0 == 0) || (v0_0.intValue() != 10)) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isGenMbUs18k()
    {
        if ((!this.isType6()) || ((this.isPhase3()) || ((this.getPowerRatingValue() != 12) || ((this.getMachineType() != 1) || ((!this.isHighVoltBattery()) || ((this.getOdmValue().intValue() != 0) || (this.getUsVersionValue() != 1))))))) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isGenUs13_16K()
    {
        int v0_0 = this.deviceType;
        if (((v0_0 == 0) || ((v0_0.intValue() != 6) || ((this.isPhase3()) || ((this.getUsVersionValue() != 1) || ((this.machineType != 0) || ((this.getPowerRatingValue() != 8) && ((this.getPowerRatingValue() != 9) && ((this.getPowerRatingValue() != 10) && (this.getPowerRatingValue() != 11))))))))) || (this.getOdmValue().intValue() != 0)) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isGenova()
    {
        int v0_0 = this.getPowerRatingValue();
        int v1_4 = this.deviceType;
        if ((v1_4 == 0) || ((v1_4.intValue() != 8) || ((this.getDtcValue() != 0) || ((this.getVoltClassValue() != 0) || ((this.getOdmValue().intValue() != 0) || ((this.machineType != 6) || ((v0_0 != 0) && ((v0_0 != 6) && (v0_0 != 7))))))))) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isGeta()
    {
        int v0_0 = this.deviceType;
        if ((v0_0 == 0) || ((v0_0.intValue() != 13) || (this.isPhase3()))) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isHighVoltBattery()
    {
        int v0_0 = this.voltClass;
        if ((v0_0 == 0) || (v0_0.intValue() != 1)) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isHybird()
    {
        int v0_0 = this.deviceType;
        if ((v0_0 != 0) && (v0_0.intValue() == 0)) {
            int v0_4 = this.phase;
            if ((v0_4 == 0) || (v0_4.intValue() != 3)) {
                return 1;
            }
        }
        return 0;
    }

    public boolean isHybird12K()
    {
        int v0_0 = this.deviceType;
        if ((v0_0 == 0) || ((v0_0.intValue() != 6) || (this.isPhase3()))) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isLowVoltBattery()
    {
        return (this.isHighVoltBattery() ^ 1);
    }

    public boolean isLsp()
    {
        int v0_0 = this.deviceType;
        if ((v0_0 == 0) || (v0_0.intValue() != 5)) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isLxpUS8_12k()
    {
        if ((this.isType6()) && (!this.isPhase3())) {
            int v0_4 = this.usVersion;
            if ((v0_4 != 0) && (v0_4.intValue() == com.lux.luxcloud.global.Constants.MODEL_US_VERSION_US)) {
                return 1;
            }
        }
        return 0;
    }

    public boolean isMega24K()
    {
        int v0_0 = this.deviceType;
        if ((v0_0 == 0) || ((v0_0.intValue() != 4) || (!this.isDtcAmerica()))) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isMidBox()
    {
        int v0_0 = this.deviceType;
        if ((v0_0 == 0) || (v0_0.intValue() != 9)) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isMidBoxWithMini()
    {
        if ((!this.isMidBox()) && (!this.isMidMini())) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isMidBoxWithOutEQB()
    {
        if ((!this.isMidBox()) || (this.isEQB())) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isMidBoxWithOutMini()
    {
        if ((!this.isMidBox()) || (this.isMidMini())) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isMidMini()
    {
        int v0_0 = this.deviceType;
        if ((v0_0 == 0) || ((v0_0.intValue() != 9) || (this.machineType != 1))) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isOffGrid()
    {
        int v0_0 = this.deviceType;
        if ((v0_0 == 0) || (v0_0.intValue() != 3)) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isOffGridHardV11()
    {
        if ((this.getSubDeviceTypeValue() != 131) && (this.getHardwareVersion() < 11)) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isParallelGroup()
    {
        return (com.lux.luxcloud.tool.Tool.isEmpty(this.parallelGroup) ^ 1);
    }

    public boolean isPhase3()
    {
        int v0_0 = this.phase;
        if ((v0_0 == 0) || (v0_0.intValue() != 3)) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isPowerHubLink()
    {
        int v0_0 = this.deviceType;
        if ((v0_0 == 0) || ((v0_0.intValue() != 9) || ((this.machineType != 0) || ((this.getDtcValue() != 0) || ((this.getVoltClassValue() != 0) || (this.getOdmValue().intValue() != 0)))))) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isResona()
    {
        int v0_0 = this.getPowerRatingValue();
        int v1_4 = this.deviceType;
        if ((v1_4 == 0) || ((v1_4.intValue() != 8) || ((this.getDtcValue() != 0) || ((this.getVoltClassValue() != 0) || ((this.getOdmValue().intValue() != 0) || ((this.machineType != 6) || ((v0_0 != 1) && ((v0_0 != 2) && (v0_0 != 5))))))))) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isSna12K()
    {
        int v0_0 = this.deviceType;
        if ((v0_0 == 0) || (v0_0.intValue() != 11)) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isSna12kEu()
    {
        int v0_0 = this.deviceType;
        if ((v0_0 != 0) && ((v0_0.intValue() == 11) && (!this.isPhase3()))) {
            int v0_6 = this.dtc;
            if ((v0_6 != 0) && (v0_6.intValue() == 0)) {
                return 1;
            }
        }
        return 0;
    }

    public boolean isSna2_12K()
    {
        if ((!this.isSna12K()) || (this.machineType != 1)) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isSna2_12k_EU()
    {
        if ((!this.isSna2_12K()) || (this.isDtcAmerica())) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isSna2_12k_EU_lt()
    {
        if ((!this.isSna2_12K()) || (this.getPowerRatingValue() != 6)) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isSna2_6kUs()
    {
        if ((!this.isOffGrid()) || ((!this.isDtcAmerica()) || (this.machineType != 1))) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isSna3_6K_eu()
    {
        if ((this.isOffGrid()) && (!this.isPhase3())) {
            int v0_5 = this.dtc;
            if ((v0_5 != 0) && ((v0_5.intValue() == 0) && (this.machineType == 2))) {
                return 1;
            }
        }
        return 0;
    }

    public boolean isSna3_6K_us()
    {
        int v0_0 = this.deviceType;
        if ((v0_0 != 0) && ((v0_0.intValue() == 3) && (!this.isPhase3()))) {
            int v0_5 = this.dtc;
            if ((v0_5 != 0) && (v0_5.intValue() == 1)) {
                return 1;
            }
        }
        return 0;
    }

    public boolean isSna6kEneleageZero()
    {
        if ((!this.isOffGrid()) || ((!this.isDtcAmerica()) || ((this.getMachineType() != 5) || (this.getOdmValue().intValue() != 8)))) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isSna6kUsAio()
    {
        if ((!this.isOffGrid()) || ((!this.isDtcAmerica()) || (this.machineType != 4))) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isSnaSeries()
    {
        if ((!this.isOffGrid()) && (!this.isSna12K())) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isSnaSeriesOrGeta()
    {
        if ((!this.isSnaSeries()) && (!this.isGeta())) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isSnaSeriesOrGetaOrGen3()
    {
        if ((!this.isSnaSeries()) && ((!this.isGeta()) && ((!this.isGen3()) && ((!this.isGenova()) && (!this.isResona()))))) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isSunKing()
    {
        int v0_0 = this.deviceType;
        if ((v0_0 == 0) || ((v0_0.intValue() != 3) || (this.getOdmValue().intValue() != 2))) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isTrip12K()
    {
        int v0_0 = this.phase;
        if ((v0_0 != 0) && (v0_0.intValue() == 3)) {
            int v0_4 = this.deviceType;
            if ((v0_4 != 0) && (v0_4.intValue() == 0)) {
                return 1;
            }
        }
        return 0;
    }

    public boolean isTrip12KHv()
    {
        if ((!this.isTrip12K()) || (!this.isHighVoltBattery())) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isTrip12KLv()
    {
        if ((!this.isTrip12K()) || (!this.isLowVoltBattery())) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isTrip12KLvUs()
    {
        if ((!this.isTrip12K()) || ((!this.isLowVoltBattery()) || (this.getUsVersionValue() != 1))) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isType6()
    {
        int v0_0 = this.deviceType;
        if ((v0_0 == 0) || (v0_0.intValue() != 6)) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isType6Series()
    {
        if ((!this.isType6()) && ((!this.isAllInOne()) && ((!this.is7_10KDevice()) && ((!this.isGen3_6K()) && ((!this.isTrip12K()) && (!this.isMega24K())))))) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isType6SeriesWithoutTrip12K()
    {
        if ((!this.isType6()) && ((!this.isAllInOne()) && ((!this.is7_10KDevice()) && (!this.isGen3_6K())))) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean is_ENELEAGE_ZERO()
    {
        if ((!this.isOffGrid()) || ((this.isPhase3()) || ((!this.isDtcAmerica()) || ((this.machineType != 5) || (this.getOdmValue().intValue() != 8))))) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean needCheckHoldBeforeStandardUpdate()
    {
        if ((!this.isType6()) && (!this.isGen1_7_10K())) {
            return 0;
        } else {
            return 1;
        }
    }

    public void setAllowExport2Grid(boolean p1)
    {
        this.allowExport2Grid = p1;
        return;
    }

    public void setAllowGenExercise(boolean p1)
    {
        this.allowGenExercise = p1;
        return;
    }

    public void setBatCurrUnit(Integer p1)
    {
        this.batCurrUnit = p1;
        return;
    }

    public void setBatParallelNum(String p1)
    {
        this.batParallelNum = p1;
        return;
    }

    public void setBatteryTypeFromModel(com.lux.luxcloud.global.bean.inverter.BATTERY_TYPE p1)
    {
        this.batteryTypeFromModel = p1;
        return;
    }

    public void setDatalogSn(String p1)
    {
        this.datalogSn = p1;
        return;
    }

    public void setDeviceType(Integer p1)
    {
        this.deviceType = p1;
        return;
    }

    public void setDtc(Integer p1)
    {
        this.dtc = p1;
        return;
    }

    public void setFwCode(String p1)
    {
        this.fwCode = p1;
        return;
    }

    public void setFwVersion(Integer p1)
    {
        this.fwVersion = p1;
        return;
    }

    public void setHardwareVersion(int p1)
    {
        this.hardwareVersion = p1;
        return;
    }

    public void setInverterData7(com.lux.luxcloud.global.bean.inverter.InverterData7 p1)
    {
        this.inverterData7 = p1;
        return;
    }

    public void setLeadAcidType(Integer p1)
    {
        this.leadAcidType = p1;
        return;
    }

    public void setMachineType(int p1)
    {
        this.machineType = p1;
        return;
    }

    public void setMasterInverterSn(String p1)
    {
        this.masterInverterSn = p1;
        return;
    }

    public void setModel(Long p1)
    {
        this.model = p1;
        return;
    }

    public void setOdm(Integer p1)
    {
        this.odm = p1;
        return;
    }

    public void setParallelFirstDeviceSn(String p1)
    {
        this.parallelFirstDeviceSn = p1;
        return;
    }

    public void setParallelGroup(String p1)
    {
        this.parallelGroup = p1;
        return;
    }

    public void setPhase(Integer p1)
    {
        this.phase = p1;
        return;
    }

    public void setPlantId(Long p1)
    {
        this.plantId = p1;
        return;
    }

    public void setPowerRating(Integer p1)
    {
        this.powerRating = p1;
        return;
    }

    public void setProtocolVersion(Integer p1)
    {
        this.protocolVersion = p1;
        return;
    }

    public void setSerialNum(String p1)
    {
        this.serialNum = p1;
        return;
    }

    public void setSlaveVersion(Integer p1)
    {
        this.slaveVersion = p1;
        return;
    }

    public void setStandard(String p1)
    {
        this.standard = p1;
        return;
    }

    public void setSubDeviceType(Integer p1)
    {
        this.subDeviceType = p1;
        return;
    }

    public void setUsVersion(Integer p1)
    {
        this.usVersion = p1;
        return;
    }

    public void setVoltClass(Integer p1)
    {
        this.voltClass = p1;
        return;
    }

    public void setWithbatteryData(Boolean p1)
    {
        this.withbatteryData = p1;
        return;
    }

    public boolean supportRead127Register()
    {
        int v0_0 = this.protocolVersion;
        if ((v0_0 == 0) || (v0_0.intValue() < 4)) {
            return 0;
        } else {
            return 1;
        }
    }

    public String toString()
    {
        return this.serialNum;
    }
}
