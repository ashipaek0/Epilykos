package com.lux.luxcloud.global.bean.param;
final enum class PARAM$144 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$144(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$144(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p3)
    {
        int v3_1 = p3.getCurrentInverter();
        if (((!v3_1.isType6Series()) && (!v3_1.isGen3Series())) || (v3_1.isAllInOne())) {
            if (!v3_1.isMidBox()) {
                if (!v3_1.isSnaSeriesOrGeta()) {
                    return 0;
                } else {
                    return 1;
                }
            } else {
                return 1;
            }
        } else {
            return 1;
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        if (!p1.getCurrentInverter().isSnaSeriesOrGeta()) {
            return 2131886632;
        } else {
            return 2131886631;
        }
    }

    public Object getPlatformSpecificData(com.lux.luxcloud.global.UserData p4, android.content.Context p5)
    {
        int v4_1 = p4.getCurrentInverter();
        if (!v4_1.isTrip12K()) {
            int v4_2;
            if (!v4_1.isGeta()) {
                v4_2 = 1065353216;
            } else {
                int v4_7 = v4_1.getVoltClassValue();
                if (v4_7 != 2) {
                    if (v4_7 != 3) {
                    } else {
                        v4_2 = 1082130432;
                    }
                } else {
                    v4_2 = 1073741824;
                }
            }
            java.text.DecimalFormat v5_3 = new java.text.DecimalFormat("0.#");
            v5_3.setRoundingMode(java.math.RoundingMode.HALF_UP);
            return this.createInputBox(v5_3.format(((double) (((float) 56) / v4_2))), v5_3.format(((double) (((float) 40) / v4_2))));
        } else {
            return this.createInputBox("700", "80");
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887539;
    }

    public int getStartRegister()
    {
        return 169;
    }
}
