package com.lux.luxcloud.global.bean.param;
final enum class PARAM$398 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$398(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$398(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p4)
    {
        com.lux.luxcloud.global.bean.user.ROLE v0 = p4.getRole();
        if (!p4.getCurrentInverter().isType6Series()) {
            return 0;
        } else {
            if (((!this.isEg4(p4)) || (!com.lux.luxcloud.global.bean.user.ROLE.ADMIN.equals(v0))) && ((!com.lux.luxcloud.global.bean.user.ROLE.ADMIN.equals(v0)) && (!com.lux.luxcloud.global.bean.user.ROLE.MAINTAIN.equals(v0)))) {
                return 0;
            } else {
                return 1;
            }
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887356;
    }
}
