package com.lux.luxcloud.global.bean.param;
final enum class PARAM$317 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$317(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$317(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p2)
    {
        boolean v2_1 = p2.getCurrentInverter();
        if (!v2_1.isEQB()) {
            return v2_1.isMidBox();
        } else {
            return 0;
        }
    }

    public Object getPlatformSpecificData(com.lux.luxcloud.global.UserData p4, android.content.Context p5)
    {
        org.json.JSONObject v4_1 = p4.getCurrentInverter();
        if (v4_1 != null) {
            java.util.LinkedHashMap v0_1 = new java.util.LinkedHashMap();
            v0_1.put("-1", p5.getString(2131887062));
            v0_1.put("0", p5.getString(2131887639));
            v0_1.put("1", p5.getString(2131887584));
            v0_1.put("2", p5.getString(2131887312));
            if (v4_1.isMidMini()) {
                v0_1.put("3", p5.getString(2131887638));
            }
            return this.createDropdownFromMap(v0_1);
        } else {
            return 0;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        if (!p1.isMidMini()) {
            return 2131887734;
        } else {
            return 2131887589;
        }
    }
}
