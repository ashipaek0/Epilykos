package com.lux.luxcloud.global.bean.param;
final enum class PARAM$243 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$243(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$243(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p5)
    {
        boolean v0_0 = p5.getCurrentInverter();
        if (!v0_0.isGen3Series()) {
            if ((!v0_0.isAcCharger()) && (!v0_0.isHybird())) {
                if ((!v0_0.isType6Series()) || (v0_0.isAllInOne())) {
                    if ((!v0_0.isGen3_6K()) && (!v0_0.is7_10KDevice())) {
                        if (!v0_0.isMidBox()) {
                            return 0;
                        } else {
                            return 1;
                        }
                    } else {
                        return 1;
                    }
                } else {
                    return 1;
                }
            } else {
                if ((this.isViewer(p5)) && (!p5.isGigabiz1User())) {
                    return 0;
                } else {
                    return 1;
                }
            }
        } else {
            return 0;
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return 2131886731;
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887099;
    }
}
