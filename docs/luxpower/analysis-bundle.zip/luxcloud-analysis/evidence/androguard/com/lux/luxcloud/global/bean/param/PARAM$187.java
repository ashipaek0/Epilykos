package com.lux.luxcloud.global.bean.param;
final enum class PARAM$187 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$187(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$187(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p2)
    {
        if ((!com.lux.luxcloud.global.bean.param.PARAM$187.PARALLEL.checkVisible(p2)) && ((!com.lux.luxcloud.global.bean.param.PARAM$187.ADVANCED_PROTECTION_SETTING.checkVisible(p2)) && ((!com.lux.luxcloud.global.bean.param.PARAM$187.CT_METER_SETTING.checkVisible(p2)) && (!com.lux.luxcloud.global.bean.param.PARAM$187.PV_SETTING.checkVisible(p2))))) {
            return 0;
        } else {
            return 1;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131886637;
    }
}
