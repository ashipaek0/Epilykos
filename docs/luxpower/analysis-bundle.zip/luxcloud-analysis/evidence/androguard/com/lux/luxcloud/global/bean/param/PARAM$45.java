package com.lux.luxcloud.global.bean.param;
final enum class PARAM$45 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$45(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$45(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p4)
    {
        boolean v0_0 = p4.getCurrentInverter();
        if (!v0_0.isMidBox()) {
            if ((!v0_0.isSnaSeries()) && ((!v0_0.isTrip12K()) && (!v0_0.isGeta()))) {
                if ((!v0_0.isType6Series()) && (!v0_0.isGen3Series())) {
                    return 1;
                } else {
                    return (this.isViewer(p4) ^ 1);
                }
            } else {
                return 0;
            }
        } else {
            return this.isAdmin(p4);
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        if (!p1.isTrip12K()) {
            return 2131887337;
        } else {
            return 2131887336;
        }
    }

    public int getStartRegister()
    {
        return 64;
    }
}
