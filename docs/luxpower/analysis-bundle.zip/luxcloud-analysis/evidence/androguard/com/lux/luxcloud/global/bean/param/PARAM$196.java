package com.lux.luxcloud.global.bean.param;
final enum class PARAM$196 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$196(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$196(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p4)
    {
        com.lux.luxcloud.global.bean.inverter.Inverter v0 = p4.getCurrentInverter();
        if (!v0.isEQB()) {
            if ((!v0.isMidBox()) || (!this.isLocal(p4))) {
                if (((!com.lux.luxcloud.global.bean.param.PARAM$196.FUNC_MIDBOX_EN.checkVisible(p4)) && ((!com.lux.luxcloud.global.bean.param.PARAM$196.HOLD_SET_MASTER_OR_SLAVE.checkVisible(p4)) && ((!com.lux.luxcloud.global.bean.param.PARAM$196.HOLD_SET_COMPOSED_PHASE.checkVisible(p4)) && ((!com.lux.luxcloud.global.bean.param.PARAM$196.FUNC_BAT_SHARED.checkVisible(p4)) && ((!com.lux.luxcloud.global.bean.param.PARAM$196.BIT_PARALLEL_SETTINGS_ROLE.checkVisible(p4)) && (!com.lux.luxcloud.global.bean.param.PARAM$196.FUNC_PARALLEL_DATA_SYNC_EN.checkVisible(p4))))))) || (v0.isGeta())) {
                    return 0;
                } else {
                    return 1;
                }
            } else {
                return 0;
            }
        } else {
            return 0;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887285;
    }
}
