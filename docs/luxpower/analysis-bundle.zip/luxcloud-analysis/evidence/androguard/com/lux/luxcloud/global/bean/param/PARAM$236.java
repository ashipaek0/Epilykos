package com.lux.luxcloud.global.bean.param;
final enum class PARAM$236 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$236(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$236(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p5)
    {
        boolean v0_0 = p5.getCurrentInverter();
        if ((!v0_0.isHybird()) && (!v0_0.isAcCharger())) {
            if (((!v0_0.isType6Series()) && (!v0_0.isGen3Series())) || (v0_0.isAllInOne())) {
                if (!v0_0.isMidBox()) {
                    return 0;
                } else {
                    if ((!this.isAdmin(p5)) && ((!this.isMAINTAIN(p5)) && (!this.isEg4Admin(p5)))) {
                        return 0;
                    } else {
                        return 1;
                    }
                }
            } else {
                if ((!this.isAdmin(p5)) && ((!this.isMAINTAIN(p5)) && (!this.isEg4Admin(p5)))) {
                    return 0;
                } else {
                    return 1;
                }
            }
        } else {
            if ((!this.isAdmin(p5)) && ((!this.isMAINTAIN(p5)) && (!this.isEg4Admin(p5)))) {
                return 0;
            } else {
                return 1;
            }
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        if (!p1.getCurrentInverter().isHybird()) {
            return 2131886810;
        } else {
            return -1;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131886216;
    }
}
