package com.lux.luxcloud.global.bean.param;
final enum class PARAM$245 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$245(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$245(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p9)
    {
        String v0_0 = p9.getCurrentInverter();
        if (v0_0 != null) {
            if ((!this.isEg4(p9)) && (this.isViewer(p9))) {
                return 0;
            } else {
                int v4_4;
                int v9_1 = v0_0.getStandard();
                int v2_1 = v0_0.getSlaveVersion().intValue();
                int v3_1 = v0_0.getFwVersion().intValue();
                if ((!v0_0.is6000XP()) || ((!"ccaa".equalsIgnoreCase(v9_1)) || ((v2_1 < 18) || (v3_1 < 18)))) {
                    v4_4 = 0;
                } else {
                    v4_4 = 1;
                }
                if ((!v0_0.isSna3_6K_eu()) || ((!"CBAA".equalsIgnoreCase(v9_1)) || ((v2_1 < 36) || (v3_1 < 32)))) {
                    int v6_5 = 0;
                } else {
                    v6_5 = 1;
                }
                if ((!v0_0.is12000XP()) || ((!"ceaa".equalsIgnoreCase(v9_1)) || ((v2_1 < 6) || (v3_1 < 9)))) {
                    int v7_5 = 0;
                } else {
                    v7_5 = 1;
                }
                if ((!v0_0.isSna12kEu()) || ((!"cfaa".equalsIgnoreCase(v9_1)) || ((v2_1 < 7) || (v3_1 < 8)))) {
                    int v9_5 = 0;
                } else {
                    v9_5 = 1;
                }
                if ((v4_4 == 0) && ((v6_5 == 0) && ((v7_5 == 0) && (v9_5 == 0)))) {
                    return 0;
                } else {
                    return 1;
                }
            }
        } else {
            return 0;
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return 2131887097;
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887096;
    }
}
