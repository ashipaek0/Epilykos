package com.lux.luxcloud.global.bean.param;
final enum class BattChgPARAM$34 extends com.lux.luxcloud.global.bean.param.BattChgPARAM {

    private BattChgPARAM$34(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic BattChgPARAM$34(String p1, int p2, com.lux.luxcloud.global.bean.param.BattChgPARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkEnabled(String p2)
    {
        return "VOLT".equals(p2);
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p1)
    {
        return 1;
    }

    public Object getPlatformSpecificData(com.lux.luxcloud.global.UserData p2)
    {
        if (!p2.getCurrentInverter().isTrip12K()) {
            return this.createInputBox("56", "40");
        } else {
            return this.createInputBox("700", "80");
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887491;
    }
}
