package com.lux.luxcloud.global.bean.param;
final enum class BattChgPARAM$29 extends com.lux.luxcloud.global.bean.param.BattChgPARAM {

    private BattChgPARAM$29(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic BattChgPARAM$29(String p1, int p2, com.lux.luxcloud.global.bean.param.BattChgPARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkEnabled(String p2)
    {
        return "SOC".equals(p2);
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p3)
    {
        int v3_1 = p3.getCurrentInverter();
        if ((!v3_1.isHybird()) && (!v3_1.isType6Series())) {
            if (!v3_1.isMidBox()) {
                return 0;
            } else {
                return 1;
            }
        } else {
            return 1;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131886175;
    }

    public int getStartRegister()
    {
        return 67;
    }
}
