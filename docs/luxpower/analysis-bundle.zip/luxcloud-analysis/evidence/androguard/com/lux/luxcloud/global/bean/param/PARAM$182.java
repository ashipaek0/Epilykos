package com.lux.luxcloud.global.bean.param;
final enum class PARAM$182 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$182(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$182(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p6)
    {
        boolean v0_0 = p6.getCurrentInverter();
        p6.getRole();
        boolean v1_7 = com.lux.luxcloud.global.GlobalInfo.getInstance().getCurrentClusterGroup();
        if ((!p6.isEnergy100User()) || ((!this.isViewer(p6)) || ((v0_0.getDtcValue() != 0) || (!"firstCluster".equals(v1_7))))) {
            if (((!v0_0.isType6Series()) && (!v0_0.isGen3Series())) || (v0_0.isAllInOne())) {
                if ((!v0_0.isSnaSeriesOrGeta()) || (!v0_0.isOffGridHardV11())) {
                    if (!v0_0.isMidBox()) {
                        return 0;
                    } else {
                        if ((this.isViewer(p6)) && (!this.isEg4(p6))) {
                            return 0;
                        } else {
                            return 1;
                        }
                    }
                } else {
                    if ((this.isViewer(p6)) && ((!this.isEg4(p6)) && ((!p6.isEnergy100User()) || (!this.isViewer(p6))))) {
                        return 0;
                    } else {
                        return 1;
                    }
                }
            } else {
                return 1;
            }
        } else {
            if ((!v0_0.isSnaSeriesOrGeta()) && (!v0_0.isHybird())) {
                return 0;
            } else {
                return 1;
            }
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return 2131886800;
    }

    public Object getPlatformSpecificData(com.lux.luxcloud.global.UserData p4, android.content.Context p5)
    {
        int v4_2;
        int v4_1 = p4.getCurrentInverter();
        if (!v4_1.isGeta()) {
            v4_2 = 1065353216;
        } else {
            int v4_5 = v4_1.getVoltClassValue();
            if (v4_5 != 2) {
                if (v4_5 != 3) {
                } else {
                    v4_2 = 1082130432;
                }
            } else {
                v4_2 = 1073741824;
            }
        }
        java.text.DecimalFormat v5_1 = new java.text.DecimalFormat("0.#");
        v5_1.setRoundingMode(java.math.RoundingMode.HALF_UP);
        return this.createInputBox(v5_1.format(((double) (((float) 52) / v4_2))), v5_1.format(((double) (((float) 40) / v4_2))));
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887316;
    }

    public int getStartRegister()
    {
        return 222;
    }
}
