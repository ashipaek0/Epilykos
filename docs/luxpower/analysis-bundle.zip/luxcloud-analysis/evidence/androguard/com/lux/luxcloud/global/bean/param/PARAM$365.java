package com.lux.luxcloud.global.bean.param;
final enum class PARAM$365 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$365(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$365(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p2)
    {
        boolean v2_1 = p2.getCurrentInverter();
        if (!v2_1.isEQB()) {
            return v2_1.isMidBox();
        } else {
            return 0;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        if (!p1.isMidMini()) {
            return 2131886641;
        } else {
            return 2131886643;
        }
    }
}
