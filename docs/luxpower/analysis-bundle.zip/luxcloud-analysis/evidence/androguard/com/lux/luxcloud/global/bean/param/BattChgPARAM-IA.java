package com.lux.luxcloud.global.bean.param;
public final synthetic class BattChgPARAM-IA {
}
