package com.lux.luxcloud.global.bean.param;
final enum class BattChgPARAM$25 extends com.lux.luxcloud.global.bean.param.BattChgPARAM {

    private BattChgPARAM$25(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic BattChgPARAM$25(String p1, int p2, com.lux.luxcloud.global.bean.param.BattChgPARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkEnabled(String p2)
    {
        return "VOLT".equals(p2);
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p3)
    {
        int v3_1 = p3.getCurrentInverter();
        if (!v3_1.isSnaSeriesOrGeta()) {
            if (!v3_1.isMidBox()) {
                if (!v3_1.isType6Series()) {
                    return 0;
                } else {
                    return 1;
                }
            } else {
                return 1;
            }
        } else {
            return 1;
        }
    }

    public Object getPlatformSpecificData(com.lux.luxcloud.global.UserData p5)
    {
        int v5_2;
        int v5_1 = p5.getCurrentInverter();
        if (!v5_1.isGeta()) {
            v5_2 = 1065353216;
        } else {
            int v5_5 = v5_1.getVoltClassValue();
            if (v5_5 != 2) {
                if (v5_5 != 3) {
                } else {
                    v5_2 = 1082130432;
                }
            } else {
                v5_2 = 1073741824;
            }
        }
        java.text.DecimalFormat v0_1 = new java.text.DecimalFormat("0.#");
        v0_1.setRoundingMode(java.math.RoundingMode.HALF_UP);
        return this.createInputBox(v0_1.format(((double) (1114505216 / v5_2))), v0_1.format(((double) (((float) 48) / v5_2))));
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887335;
    }

    public int getStartRegister()
    {
        return 201;
    }
}
