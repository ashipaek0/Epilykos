package com.lux.luxcloud.global.bean.param;
final enum class PARAM$411 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$411(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$411(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p6)
    {
        long v0_0 = p6.getCurrentInverter();
        p6.getRole();
        if (!p6.isEuropeSonnePvInstaller()) {
            if (!v0_0.isEQB()) {
                if ((p6.getParentUserIdValue() != 68186) || ((!com.lux.luxcloud.global.bean.user.ROLE.INSTALLER.equals(p6.getRole())) || (p6.getClusterId() != 2))) {
                    return (this.isViewer(p6) ^ 1);
                } else {
                    return 0;
                }
            } else {
                return 0;
            }
        } else {
            return 0;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887160;
    }
}
