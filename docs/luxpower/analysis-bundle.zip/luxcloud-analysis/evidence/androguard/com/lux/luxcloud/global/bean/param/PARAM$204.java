package com.lux.luxcloud.global.bean.param;
final enum class PARAM$204 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$204(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$204(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p2)
    {
        return com.lux.luxcloud.global.bean.param.PARAM$204.FUNC_GO_TO_OFFGRID_MODE.checkVisible(p2);
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p2)
    {
        if (!com.lux.luxcloud.global.bean.user.PLATFORM.EG4.equals(com.lux.luxcloud.version.Custom.APP_USER_PLATFORM)) {
            return 2131887436;
        } else {
            return 2131887437;
        }
    }
}
