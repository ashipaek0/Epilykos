package com.lux.luxcloud.global.bean.param;
final enum class PARAM$227 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$227(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$227(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p5)
    {
        int v5_1;
        int v0_0 = p5.getCurrentInverter();
        if ((!v0_0.isAcCharger()) && (!v0_0.isHybird())) {
            if (((!v0_0.isType6Series()) && (!v0_0.isGen3Series())) || (v0_0.isAllInOne())) {
                if (!v0_0.isMidBox()) {
                    return 0;
                } else {
                    v5_1 = this.isViewer(p5);
                }
            } else {
                if ((this.isViewer(p5)) || ((v0_0.getDeviceTypeValue() == 0) || (v0_0.getPhaseValue().intValue() == 3))) {
                    return 0;
                } else {
                    return 1;
                }
            }
        } else {
            v5_1 = this.isViewer(p5);
        }
        return (v5_1 ^ 1);
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return 2131886785;
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131886551;
    }
}
