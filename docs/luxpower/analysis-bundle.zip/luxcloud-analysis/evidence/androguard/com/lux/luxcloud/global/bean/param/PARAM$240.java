package com.lux.luxcloud.global.bean.param;
final enum class PARAM$240 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$240(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$240(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p5)
    {
        com.lux.luxcloud.global.bean.user.ROLE v0_0 = p5.getCurrentInverter();
        if (!v0_0.isGen3Series()) {
            if ((!v0_0.isHybird()) && (!v0_0.isAcCharger())) {
                if ((!v0_0.isGen3_6K()) && ((!v0_0.is7_10KDevice()) && (!v0_0.isTrip12K()))) {
                    if ((!v0_0.isType6Series()) || (v0_0.isAllInOne())) {
                        if (!v0_0.is12KUsVersion()) {
                            if (!v0_0.isMidBox()) {
                                return 0;
                            } else {
                                if ((p5.isGigabiz1User()) && (com.lux.luxcloud.global.bean.user.ROLE.VIEWER.equals(p5.getRole()))) {
                                    return 0;
                                } else {
                                    return 1;
                                }
                            }
                        } else {
                            return v0_0.isAllowExport2Grid();
                        }
                    } else {
                        return 1;
                    }
                } else {
                    return 1;
                }
            } else {
                if ((p5.isGigabiz1User()) && ((com.lux.luxcloud.global.bean.user.ROLE.VIEWER.equals(p5.getRole())) && (!v0_0.isAllowExport2Grid()))) {
                    return 0;
                } else {
                    return 1;
                }
            }
        } else {
            return 0;
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return 2131886732;
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131886275;
    }
}
