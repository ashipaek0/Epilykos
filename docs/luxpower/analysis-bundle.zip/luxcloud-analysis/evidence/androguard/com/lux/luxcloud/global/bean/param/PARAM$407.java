package com.lux.luxcloud.global.bean.param;
final enum class PARAM$407 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$407(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$407(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p5)
    {
        p5.getRole();
        boolean v0_1 = p5.getCurrentInverter();
        if (!v0_1.isGen3Series()) {
            if ((!v0_1.isType6Series()) && (!v0_1.isTrip12K())) {
                if ((!v0_1.isSna3_6K_eu()) && (!v0_1.isSnaSeries())) {
                    return 0;
                } else {
                    if ((!this.isEg4(p5)) && (this.isViewer(p5))) {
                        return 0;
                    } else {
                        return 1;
                    }
                }
            } else {
                return (this.isViewer(p5) ^ 1);
            }
        } else {
            return 0;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887331;
    }
}
