package com.lux.luxcloud.global.bean.param;
final enum class PARAM$408 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$408(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$408(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p5)
    {
        p5.getRole();
        boolean v0_2 = p5.getCurrentInverter();
        if (!v0_2.isGen3Series()) {
            if (!v0_2.isType6Series()) {
                if ((!v0_2.isSna3_6K_eu()) && (!v0_2.isGen3Pro())) {
                    return 0;
                } else {
                    if ((this.isViewer(p5)) && (!this.isEg4(p5))) {
                        return 0;
                    } else {
                        return 1;
                    }
                }
            } else {
                if ((!this.isEg4Admin(p5)) && ((!this.isAdmin(p5)) && (!this.isMAINTAIN(p5)))) {
                    return 0;
                } else {
                    return 1;
                }
            }
        } else {
            return 0;
        }
    }

    public Object getPlatformSpecificData(com.lux.luxcloud.global.UserData p3, android.content.Context p4)
    {
        org.json.JSONObject v3_1 = new java.util.LinkedHashMap();
        this.addPlainOption(v3_1, "-1", 2131887062, p4);
        this.addPlainOption(v3_1, "0", 2131887015, p4);
        this.addPlainOption(v3_1, "1", 2131887016, p4);
        return this.createDropdownFromMap(v3_1);
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887014;
    }
}
