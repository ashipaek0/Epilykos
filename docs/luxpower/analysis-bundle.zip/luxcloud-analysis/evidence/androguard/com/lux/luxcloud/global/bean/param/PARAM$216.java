package com.lux.luxcloud.global.bean.param;
final enum class PARAM$216 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$216(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$216(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p3)
    {
        int v0_0 = p3.getCurrentInverter();
        p3.getRole();
        if ((!v0_0.isType6()) || ((!this.isAdmin(p3)) && ((!this.isMAINTAIN(p3)) && ((!this.isEg4Admin(p3)) && ((v0_0.getSlaveVersionValue() < 33) || (v0_0.getFwVersionValue() < 34)))))) {
            return 0;
        } else {
            return 1;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887670;
    }
}
