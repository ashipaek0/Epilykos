package com.lux.luxcloud.global.bean.param;
final enum class PARAM$195 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$195(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$195(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p5)
    {
        boolean v0_0 = p5.getCurrentInverter();
        if (!v0_0.isEQB()) {
            if (!v0_0.isMidMini()) {
                if ((!v0_0.isMidBox()) || (!this.isLocal(p5))) {
                    if (!v0_0.isGen3Series()) {
                        if ((!v0_0.isGen3_6K()) && ((!v0_0.is7_10KDevice()) && ((!v0_0.isType6Series()) && ((!v0_0.isHybird()) && ((!v0_0.isAcCharger()) && ((!v0_0.isMidBox()) && (!v0_0.isTrip12K()))))))) {
                            return 0;
                        } else {
                            return (this.isViewer(p5) ^ 1);
                        }
                    } else {
                        return 1;
                    }
                } else {
                    return 0;
                }
            } else {
                return 1;
            }
        } else {
            return 0;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131886301;
    }
}
