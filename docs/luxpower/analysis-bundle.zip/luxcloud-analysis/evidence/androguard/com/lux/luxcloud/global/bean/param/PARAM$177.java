package com.lux.luxcloud.global.bean.param;
final enum class PARAM$177 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$177(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$177(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p8)
    {
        boolean v0_0 = p8.getCurrentInverter();
        String v1_1 = com.lux.luxcloud.global.GlobalInfo.getInstance().getCurrentClusterGroup();
        if (((!p8.isEnergy100User()) || ((v0_0.getDtcValue() != 0) || ((!v0_0.isSnaSeriesOrGeta()) && (!v0_0.isHybird())))) || (!"firstCluster".equals(v1_1))) {
            if (!v0_0.isGen3Series()) {
                if (!v0_0.isSnaSeriesOrGeta()) {
                    if (((!v0_0.isType6Series()) && (!v0_0.isFlexSeries())) || ((v0_0.getMachineType() == 1) || (v0_0.isFlexBoss100()))) {
                        return 0;
                    } else {
                        return 1;
                    }
                } else {
                    if (!v0_0.isAllInOne()) {
                        if (!this.isAdmin(p8)) {
                            if (!"solarcom".equals(p8.getUsername())) {
                                if (!v0_0.isSna12K()) {
                                    if ((!v0_0.isOffGridHardV11()) && (!v0_0.isGeta())) {
                                        return 0;
                                    } else {
                                        if ((this.isViewer(p8)) && ((!"firstCluster".equals(v1_1)) || ((!p8.isEnergy100User()) || (!this.isViewer(p8))))) {
                                            return 0;
                                        } else {
                                            return 1;
                                        }
                                    }
                                } else {
                                    if ((this.isViewer(p8)) && ((!this.isEg4(p8)) && ((!"firstCluster".equals(v1_1)) || ((!p8.isEnergy100User()) || (!this.isViewer(p8)))))) {
                                        return 0;
                                    } else {
                                        return 1;
                                    }
                                }
                            } else {
                                return 1;
                            }
                        } else {
                            return 1;
                        }
                    } else {
                        return 0;
                    }
                }
            } else {
                return 1;
            }
        } else {
            return 1;
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return 2131886791;
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887599;
    }

    public int getStartRegister()
    {
        return 217;
    }
}
