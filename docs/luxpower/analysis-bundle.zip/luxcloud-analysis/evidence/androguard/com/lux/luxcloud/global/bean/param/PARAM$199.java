package com.lux.luxcloud.global.bean.param;
final enum class PARAM$199 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$199(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$199(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p3)
    {
        boolean v0_0 = p3.getCurrentInverter();
        if ((!v0_0.isEQB()) && (!v0_0.isMidBox())) {
            return (this.isViewer(p3) ^ 1);
        } else {
            return 0;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887687;
    }
}
