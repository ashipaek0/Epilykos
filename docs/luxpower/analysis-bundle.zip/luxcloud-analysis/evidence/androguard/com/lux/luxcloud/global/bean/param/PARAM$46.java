package com.lux.luxcloud.global.bean.param;
final enum class PARAM$46 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$46(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$46(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p3)
    {
        com.lux.luxcloud.global.bean.inverter.Inverter v0 = p3.getCurrentInverter();
        if ((!v0.isType6Series()) && ((!v0.isGen3Series()) && (!v0.isMidBox()))) {
            if ((!v0.isAcCharger()) && (!v0.isHybird())) {
                return 0;
            } else {
                return 1;
            }
        } else {
            return this.isAdmin(p3);
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887364;
    }

    public int getStartRegister()
    {
        return 65;
    }
}
