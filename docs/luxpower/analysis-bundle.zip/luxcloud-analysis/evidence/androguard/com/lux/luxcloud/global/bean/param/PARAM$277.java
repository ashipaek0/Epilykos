package com.lux.luxcloud.global.bean.param;
final enum class PARAM$277 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$277(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$277(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p4)
    {
        boolean v4_1 = p4.getCurrentInverter();
        if (!v4_1.isGen3Series()) {
            if ((!v4_1.isType6Series()) || (v4_1.isAllInOne())) {
                if (!v4_1.isMidBox()) {
                    return 0;
                } else {
                    return 1;
                }
            } else {
                return 1;
            }
        } else {
            return 0;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131886134;
    }
}
