package com.lux.luxcloud.global.bean.param;
final enum class PARAM$18 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$18(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$18(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p5)
    {
        boolean v0_0 = p5.getCurrentInverter();
        if (!v0_0.isMidBox()) {
            if ((!v0_0.isType6Series()) && ((!v0_0.isGen3Series()) && ((!v0_0.isGeta()) && ((!v0_0.isMega24K()) && ((!v0_0.isSnaSeries()) && ((!v0_0.isAcCharger()) && (!v0_0.isHybird()))))))) {
                return 0;
            } else {
                return (this.isViewer(p5) ^ 1);
            }
        } else {
            if ((this.isViewer(p5)) || (p5.getRole().getInstallerLevelCheck())) {
                return 0;
            } else {
                return 1;
            }
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return 2131886837;
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p2)
    {
        if ((!p2.isMidBox()) && (!p2.isType6Series())) {
            return 2131887485;
        } else {
            return 2131887468;
        }
    }

    public int getStartRegister()
    {
        return 38;
    }
}
