package com.lux.luxcloud.global.bean.param;
final enum class PARAM$261 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$261(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$261(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p5)
    {
        boolean v5_3;
        com.lux.luxcloud.global.bean.user.ROLE v0_0 = p5.getCurrentInverter();
        if ((!v0_0.isType6()) && ((!v0_0.isGen3Series()) && ((!v0_0.is7_10KDevice()) && (!v0_0.isAcCharger())))) {
            if ((!v0_0.isSnaSeries()) || ((p5.getClusterId() != 4) && (p5.getClusterId() != 100))) {
                return 0;
            } else {
                v5_3 = com.lux.luxcloud.global.bean.user.ROLE.VIEWER.equals(p5.getRole());
            }
        } else {
            v5_3 = com.lux.luxcloud.global.bean.user.ROLE.VIEWER.equals(p5.getRole());
        }
        return (v5_3 ^ 1);
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return 2131886744;
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887125;
    }
}
