package com.lux.luxcloud.global.bean.param;
public abstract enum class BattChgPARAM extends java.lang.Enum {
    private static final synthetic com.lux.luxcloud.global.bean.param.BattChgPARAM[] $VALUES;
    public static final enum com.lux.luxcloud.global.bean.param.BattChgPARAM HOLD_AC_CHARGE_END_BATTERY_VOLTAGE;
    public static final enum com.lux.luxcloud.global.bean.param.BattChgPARAM HOLD_AC_CHARGE_SOC_LIMIT;
    public static final enum com.lux.luxcloud.global.bean.param.BattChgPARAM HOLD_AC_CHARGE_START_BATTERY_SOC;
    public static final enum com.lux.luxcloud.global.bean.param.BattChgPARAM HOLD_AC_CHARGE_START_BATTERY_VOLTAGE;
    public static final enum com.lux.luxcloud.global.bean.param.BattChgPARAM HOLD_AC_CHARGE_START_BATTERY_VOLTAGE_TEMP;
    public static final enum com.lux.luxcloud.global.bean.param.BattChgPARAM HOLD_BATTERY_WARNING_SOC;
    public static final enum com.lux.luxcloud.global.bean.param.BattChgPARAM HOLD_BATTERY_WARNING_VOLTAGE;
    public static final enum com.lux.luxcloud.global.bean.param.BattChgPARAM HOLD_FORCED_CHG_SOC_LIMIT;
    public static final enum com.lux.luxcloud.global.bean.param.BattChgPARAM HOLD_FORCED_DISCHG_SOC_LIMIT;
    public static final enum com.lux.luxcloud.global.bean.param.BattChgPARAM HOLD_LEAD_ACID_DISCHARGE_CUT_OFF_VOLT;
    public static final enum com.lux.luxcloud.global.bean.param.BattChgPARAM HOLD_SOC_LOW_LIMIT_EPS_DISCHG;
    public static final enum com.lux.luxcloud.global.bean.param.BattChgPARAM MIDBOX_HOLD_AC_START_SOC_1;
    public static final enum com.lux.luxcloud.global.bean.param.BattChgPARAM MIDBOX_HOLD_AC_START_SOC_2;
    public static final enum com.lux.luxcloud.global.bean.param.BattChgPARAM MIDBOX_HOLD_AC_START_SOC_3;
    public static final enum com.lux.luxcloud.global.bean.param.BattChgPARAM MIDBOX_HOLD_AC_START_SOC_4;
    public static final enum com.lux.luxcloud.global.bean.param.BattChgPARAM MIDBOX_HOLD_AC_START_VOLT_1;
    public static final enum com.lux.luxcloud.global.bean.param.BattChgPARAM MIDBOX_HOLD_AC_START_VOLT_2;
    public static final enum com.lux.luxcloud.global.bean.param.BattChgPARAM MIDBOX_HOLD_AC_START_VOLT_3;
    public static final enum com.lux.luxcloud.global.bean.param.BattChgPARAM MIDBOX_HOLD_AC_START_VOLT_4;
    public static final enum com.lux.luxcloud.global.bean.param.BattChgPARAM MIDBOX_HOLD_SL_START_SOC_1;
    public static final enum com.lux.luxcloud.global.bean.param.BattChgPARAM MIDBOX_HOLD_SL_START_SOC_2;
    public static final enum com.lux.luxcloud.global.bean.param.BattChgPARAM MIDBOX_HOLD_SL_START_SOC_3;
    public static final enum com.lux.luxcloud.global.bean.param.BattChgPARAM MIDBOX_HOLD_SL_START_SOC_4;
    public static final enum com.lux.luxcloud.global.bean.param.BattChgPARAM MIDBOX_HOLD_SL_START_VOLT_1;
    public static final enum com.lux.luxcloud.global.bean.param.BattChgPARAM MIDBOX_HOLD_SL_START_VOLT_2;
    public static final enum com.lux.luxcloud.global.bean.param.BattChgPARAM MIDBOX_HOLD_SL_START_VOLT_3;
    public static final enum com.lux.luxcloud.global.bean.param.BattChgPARAM MIDBOX_HOLD_SL_START_VOLT_4;
    public static final enum com.lux.luxcloud.global.bean.param.BattChgPARAM OFF_GRID_HOLD_GEN_CHG_END_SOC;
    public static final enum com.lux.luxcloud.global.bean.param.BattChgPARAM OFF_GRID_HOLD_GEN_CHG_END_VOLT;
    public static final enum com.lux.luxcloud.global.bean.param.BattChgPARAM OFF_GRID_HOLD_GEN_CHG_START_SOC;
    public static final enum com.lux.luxcloud.global.bean.param.BattChgPARAM OFF_GRID_HOLD_GEN_CHG_START_VOLT;
    public static final enum com.lux.luxcloud.global.bean.param.BattChgPARAM OFF_GRID_HOLD_MAX_GEN_CHG_BAT_CURR;
    public static final enum com.lux.luxcloud.global.bean.param.BattChgPARAM _12K_HOLD_AC_COUPLE_START_SOC;
    public static final enum com.lux.luxcloud.global.bean.param.BattChgPARAM _12K_HOLD_AC_COUPLE_START_VOLT;
    public static final enum com.lux.luxcloud.global.bean.param.BattChgPARAM _12K_HOLD_CHARGE_FIRST_VOLT;
    public static final enum com.lux.luxcloud.global.bean.param.BattChgPARAM _12K_HOLD_GRID_PEAK_SHAVING_SOC;
    public static final enum com.lux.luxcloud.global.bean.param.BattChgPARAM _12K_HOLD_GRID_PEAK_SHAVING_SOC_2;
    public static final enum com.lux.luxcloud.global.bean.param.BattChgPARAM _12K_HOLD_GRID_PEAK_SHAVING_VOLT;
    public static final enum com.lux.luxcloud.global.bean.param.BattChgPARAM _12K_HOLD_GRID_PEAK_SHAVING_VOLT_2;
    public static final enum com.lux.luxcloud.global.bean.param.BattChgPARAM _12K_HOLD_SMART_LOAD_START_SOC;
    public static final enum com.lux.luxcloud.global.bean.param.BattChgPARAM _12K_HOLD_SMART_LOAD_START_VOLT;
    public static final enum com.lux.luxcloud.global.bean.param.BattChgPARAM _12K_HOLD_STOP_DISCHG_VOLT;

    private static synthetic com.lux.luxcloud.global.bean.param.BattChgPARAM[] $values()
    {
        com.lux.luxcloud.global.bean.param.BattChgPARAM v3 = com.lux.luxcloud.global.bean.param.BattChgPARAM._12K_HOLD_SMART_LOAD_START_SOC;
        com.lux.luxcloud.global.bean.param.BattChgPARAM v5 = com.lux.luxcloud.global.bean.param.BattChgPARAM.HOLD_AC_CHARGE_START_BATTERY_VOLTAGE;
        com.lux.luxcloud.global.bean.param.BattChgPARAM v7 = com.lux.luxcloud.global.bean.param.BattChgPARAM.OFF_GRID_HOLD_MAX_GEN_CHG_BAT_CURR;
        com.lux.luxcloud.global.bean.param.BattChgPARAM v9 = com.lux.luxcloud.global.bean.param.BattChgPARAM.MIDBOX_HOLD_SL_START_VOLT_1;
        com.lux.luxcloud.global.bean.param.BattChgPARAM v11 = com.lux.luxcloud.global.bean.param.BattChgPARAM.MIDBOX_HOLD_AC_START_VOLT_1;
        com.lux.luxcloud.global.bean.param.BattChgPARAM v13 = com.lux.luxcloud.global.bean.param.BattChgPARAM.MIDBOX_HOLD_SL_START_VOLT_2;
        com.lux.luxcloud.global.bean.param.BattChgPARAM v15 = com.lux.luxcloud.global.bean.param.BattChgPARAM.MIDBOX_HOLD_AC_START_VOLT_2;
        com.lux.luxcloud.global.bean.param.BattChgPARAM v17 = com.lux.luxcloud.global.bean.param.BattChgPARAM.MIDBOX_HOLD_SL_START_VOLT_3;
        com.lux.luxcloud.global.bean.param.BattChgPARAM v19 = com.lux.luxcloud.global.bean.param.BattChgPARAM.MIDBOX_HOLD_AC_START_VOLT_3;
        com.lux.luxcloud.global.bean.param.BattChgPARAM v21 = com.lux.luxcloud.global.bean.param.BattChgPARAM.MIDBOX_HOLD_SL_START_VOLT_4;
        com.lux.luxcloud.global.bean.param.BattChgPARAM v23 = com.lux.luxcloud.global.bean.param.BattChgPARAM.MIDBOX_HOLD_AC_START_VOLT_4;
        com.lux.luxcloud.global.bean.param.BattChgPARAM v25 = com.lux.luxcloud.global.bean.param.BattChgPARAM._12K_HOLD_CHARGE_FIRST_VOLT;
        com.lux.luxcloud.global.bean.param.BattChgPARAM v27 = com.lux.luxcloud.global.bean.param.BattChgPARAM.OFF_GRID_HOLD_GEN_CHG_END_VOLT;
        com.lux.luxcloud.global.bean.param.BattChgPARAM v29 = com.lux.luxcloud.global.bean.param.BattChgPARAM.HOLD_AC_CHARGE_SOC_LIMIT;
        com.lux.luxcloud.global.bean.param.BattChgPARAM v31 = com.lux.luxcloud.global.bean.param.BattChgPARAM.OFF_GRID_HOLD_GEN_CHG_START_SOC;
        com.lux.luxcloud.global.bean.param.BattChgPARAM v33 = com.lux.luxcloud.global.bean.param.BattChgPARAM.HOLD_SOC_LOW_LIMIT_EPS_DISCHG;
        com.lux.luxcloud.global.bean.param.BattChgPARAM v35 = com.lux.luxcloud.global.bean.param.BattChgPARAM._12K_HOLD_GRID_PEAK_SHAVING_VOLT;
        com.lux.luxcloud.global.bean.param.BattChgPARAM v37 = com.lux.luxcloud.global.bean.param.BattChgPARAM._12K_HOLD_GRID_PEAK_SHAVING_SOC;
        com.lux.luxcloud.global.bean.param.BattChgPARAM v39 = com.lux.luxcloud.global.bean.param.BattChgPARAM.HOLD_FORCED_DISCHG_SOC_LIMIT;
        com.lux.luxcloud.global.bean.param.BattChgPARAM v41 = com.lux.luxcloud.global.bean.param.BattChgPARAM.HOLD_BATTERY_WARNING_SOC;
        return new com.lux.luxcloud.global.bean.param.BattChgPARAM[] {com.lux.luxcloud.global.bean.param.BattChgPARAM._12K_HOLD_AC_COUPLE_START_SOC, com.lux.luxcloud.global.bean.param.BattChgPARAM.HOLD_BATTERY_WARNING_VOLTAGE});
    }

    static BattChgPARAM()
    {
        com.lux.luxcloud.global.bean.param.BattChgPARAM._12K_HOLD_AC_COUPLE_START_SOC = new com.lux.luxcloud.global.bean.param.BattChgPARAM$1("_12K_HOLD_AC_COUPLE_START_SOC", 0, 0);
        com.lux.luxcloud.global.bean.param.BattChgPARAM._12K_HOLD_AC_COUPLE_START_VOLT = new com.lux.luxcloud.global.bean.param.BattChgPARAM$2("_12K_HOLD_AC_COUPLE_START_VOLT", 1, 0);
        com.lux.luxcloud.global.bean.param.BattChgPARAM._12K_HOLD_SMART_LOAD_START_SOC = new com.lux.luxcloud.global.bean.param.BattChgPARAM$3("_12K_HOLD_SMART_LOAD_START_SOC", 2, 0);
        com.lux.luxcloud.global.bean.param.BattChgPARAM._12K_HOLD_SMART_LOAD_START_VOLT = new com.lux.luxcloud.global.bean.param.BattChgPARAM$4("_12K_HOLD_SMART_LOAD_START_VOLT", 3, 0);
        com.lux.luxcloud.global.bean.param.BattChgPARAM.HOLD_AC_CHARGE_START_BATTERY_VOLTAGE = new com.lux.luxcloud.global.bean.param.BattChgPARAM$5("HOLD_AC_CHARGE_START_BATTERY_VOLTAGE", 4, 0);
        com.lux.luxcloud.global.bean.param.BattChgPARAM.HOLD_AC_CHARGE_START_BATTERY_VOLTAGE_TEMP = new com.lux.luxcloud.global.bean.param.BattChgPARAM$6("HOLD_AC_CHARGE_START_BATTERY_VOLTAGE_TEMP", 5, 0);
        com.lux.luxcloud.global.bean.param.BattChgPARAM.OFF_GRID_HOLD_MAX_GEN_CHG_BAT_CURR = new com.lux.luxcloud.global.bean.param.BattChgPARAM$7("OFF_GRID_HOLD_MAX_GEN_CHG_BAT_CURR", 6, 0);
        com.lux.luxcloud.global.bean.param.BattChgPARAM.MIDBOX_HOLD_SL_START_SOC_1 = new com.lux.luxcloud.global.bean.param.BattChgPARAM$8("MIDBOX_HOLD_SL_START_SOC_1", 7, 0);
        com.lux.luxcloud.global.bean.param.BattChgPARAM.MIDBOX_HOLD_SL_START_VOLT_1 = new com.lux.luxcloud.global.bean.param.BattChgPARAM$9("MIDBOX_HOLD_SL_START_VOLT_1", 8, 0);
        com.lux.luxcloud.global.bean.param.BattChgPARAM.MIDBOX_HOLD_AC_START_SOC_1 = new com.lux.luxcloud.global.bean.param.BattChgPARAM$10("MIDBOX_HOLD_AC_START_SOC_1", 9, 0);
        com.lux.luxcloud.global.bean.param.BattChgPARAM.MIDBOX_HOLD_AC_START_VOLT_1 = new com.lux.luxcloud.global.bean.param.BattChgPARAM$11("MIDBOX_HOLD_AC_START_VOLT_1", 10, 0);
        com.lux.luxcloud.global.bean.param.BattChgPARAM.MIDBOX_HOLD_SL_START_SOC_2 = new com.lux.luxcloud.global.bean.param.BattChgPARAM$12("MIDBOX_HOLD_SL_START_SOC_2", 11, 0);
        com.lux.luxcloud.global.bean.param.BattChgPARAM.MIDBOX_HOLD_SL_START_VOLT_2 = new com.lux.luxcloud.global.bean.param.BattChgPARAM$13("MIDBOX_HOLD_SL_START_VOLT_2", 12, 0);
        com.lux.luxcloud.global.bean.param.BattChgPARAM.MIDBOX_HOLD_AC_START_SOC_2 = new com.lux.luxcloud.global.bean.param.BattChgPARAM$14("MIDBOX_HOLD_AC_START_SOC_2", 13, 0);
        com.lux.luxcloud.global.bean.param.BattChgPARAM.MIDBOX_HOLD_AC_START_VOLT_2 = new com.lux.luxcloud.global.bean.param.BattChgPARAM$15("MIDBOX_HOLD_AC_START_VOLT_2", 14, 0);
        com.lux.luxcloud.global.bean.param.BattChgPARAM.MIDBOX_HOLD_SL_START_SOC_3 = new com.lux.luxcloud.global.bean.param.BattChgPARAM$16("MIDBOX_HOLD_SL_START_SOC_3", 15, 0);
        com.lux.luxcloud.global.bean.param.BattChgPARAM.MIDBOX_HOLD_SL_START_VOLT_3 = new com.lux.luxcloud.global.bean.param.BattChgPARAM$17("MIDBOX_HOLD_SL_START_VOLT_3", 16, 0);
        com.lux.luxcloud.global.bean.param.BattChgPARAM.MIDBOX_HOLD_AC_START_SOC_3 = new com.lux.luxcloud.global.bean.param.BattChgPARAM$18("MIDBOX_HOLD_AC_START_SOC_3", 17, 0);
        com.lux.luxcloud.global.bean.param.BattChgPARAM.MIDBOX_HOLD_AC_START_VOLT_3 = new com.lux.luxcloud.global.bean.param.BattChgPARAM$19("MIDBOX_HOLD_AC_START_VOLT_3", 18, 0);
        com.lux.luxcloud.global.bean.param.BattChgPARAM.MIDBOX_HOLD_SL_START_SOC_4 = new com.lux.luxcloud.global.bean.param.BattChgPARAM$20("MIDBOX_HOLD_SL_START_SOC_4", 19, 0);
        com.lux.luxcloud.global.bean.param.BattChgPARAM.MIDBOX_HOLD_SL_START_VOLT_4 = new com.lux.luxcloud.global.bean.param.BattChgPARAM$21("MIDBOX_HOLD_SL_START_VOLT_4", 20, 0);
        com.lux.luxcloud.global.bean.param.BattChgPARAM.MIDBOX_HOLD_AC_START_SOC_4 = new com.lux.luxcloud.global.bean.param.BattChgPARAM$22("MIDBOX_HOLD_AC_START_SOC_4", 21, 0);
        com.lux.luxcloud.global.bean.param.BattChgPARAM.MIDBOX_HOLD_AC_START_VOLT_4 = new com.lux.luxcloud.global.bean.param.BattChgPARAM$23("MIDBOX_HOLD_AC_START_VOLT_4", 22, 0);
        com.lux.luxcloud.global.bean.param.BattChgPARAM.HOLD_AC_CHARGE_END_BATTERY_VOLTAGE = new com.lux.luxcloud.global.bean.param.BattChgPARAM$24("HOLD_AC_CHARGE_END_BATTERY_VOLTAGE", 23, 0);
        com.lux.luxcloud.global.bean.param.BattChgPARAM._12K_HOLD_CHARGE_FIRST_VOLT = new com.lux.luxcloud.global.bean.param.BattChgPARAM$25("_12K_HOLD_CHARGE_FIRST_VOLT", 24, 0);
        com.lux.luxcloud.global.bean.param.BattChgPARAM.OFF_GRID_HOLD_GEN_CHG_START_VOLT = new com.lux.luxcloud.global.bean.param.BattChgPARAM$26("OFF_GRID_HOLD_GEN_CHG_START_VOLT", 25, 0);
        com.lux.luxcloud.global.bean.param.BattChgPARAM.OFF_GRID_HOLD_GEN_CHG_END_VOLT = new com.lux.luxcloud.global.bean.param.BattChgPARAM$27("OFF_GRID_HOLD_GEN_CHG_END_VOLT", 26, 0);
        com.lux.luxcloud.global.bean.param.BattChgPARAM.HOLD_AC_CHARGE_START_BATTERY_SOC = new com.lux.luxcloud.global.bean.param.BattChgPARAM$28("HOLD_AC_CHARGE_START_BATTERY_SOC", 27, 0);
        com.lux.luxcloud.global.bean.param.BattChgPARAM.HOLD_AC_CHARGE_SOC_LIMIT = new com.lux.luxcloud.global.bean.param.BattChgPARAM$29("HOLD_AC_CHARGE_SOC_LIMIT", 28, 0);
        com.lux.luxcloud.global.bean.param.BattChgPARAM.HOLD_FORCED_CHG_SOC_LIMIT = new com.lux.luxcloud.global.bean.param.BattChgPARAM$30("HOLD_FORCED_CHG_SOC_LIMIT", 29, 0);
        com.lux.luxcloud.global.bean.param.BattChgPARAM.OFF_GRID_HOLD_GEN_CHG_START_SOC = new com.lux.luxcloud.global.bean.param.BattChgPARAM$31("OFF_GRID_HOLD_GEN_CHG_START_SOC", 30, 0);
        com.lux.luxcloud.global.bean.param.BattChgPARAM.OFF_GRID_HOLD_GEN_CHG_END_SOC = new com.lux.luxcloud.global.bean.param.BattChgPARAM$32("OFF_GRID_HOLD_GEN_CHG_END_SOC", 31, 0);
        com.lux.luxcloud.global.bean.param.BattChgPARAM.HOLD_SOC_LOW_LIMIT_EPS_DISCHG = new com.lux.luxcloud.global.bean.param.BattChgPARAM$33("HOLD_SOC_LOW_LIMIT_EPS_DISCHG", 32, 0);
        com.lux.luxcloud.global.bean.param.BattChgPARAM.HOLD_LEAD_ACID_DISCHARGE_CUT_OFF_VOLT = new com.lux.luxcloud.global.bean.param.BattChgPARAM$34("HOLD_LEAD_ACID_DISCHARGE_CUT_OFF_VOLT", 33, 0);
        com.lux.luxcloud.global.bean.param.BattChgPARAM._12K_HOLD_GRID_PEAK_SHAVING_VOLT = new com.lux.luxcloud.global.bean.param.BattChgPARAM$35("_12K_HOLD_GRID_PEAK_SHAVING_VOLT", 34, 0);
        com.lux.luxcloud.global.bean.param.BattChgPARAM._12K_HOLD_GRID_PEAK_SHAVING_VOLT_2 = new com.lux.luxcloud.global.bean.param.BattChgPARAM$36("_12K_HOLD_GRID_PEAK_SHAVING_VOLT_2", 35, 0);
        com.lux.luxcloud.global.bean.param.BattChgPARAM._12K_HOLD_GRID_PEAK_SHAVING_SOC = new com.lux.luxcloud.global.bean.param.BattChgPARAM$37("_12K_HOLD_GRID_PEAK_SHAVING_SOC", 36, 0);
        com.lux.luxcloud.global.bean.param.BattChgPARAM._12K_HOLD_GRID_PEAK_SHAVING_SOC_2 = new com.lux.luxcloud.global.bean.param.BattChgPARAM$38("_12K_HOLD_GRID_PEAK_SHAVING_SOC_2", 37, 0);
        com.lux.luxcloud.global.bean.param.BattChgPARAM.HOLD_FORCED_DISCHG_SOC_LIMIT = new com.lux.luxcloud.global.bean.param.BattChgPARAM$39("HOLD_FORCED_DISCHG_SOC_LIMIT", 38, 0);
        com.lux.luxcloud.global.bean.param.BattChgPARAM._12K_HOLD_STOP_DISCHG_VOLT = new com.lux.luxcloud.global.bean.param.BattChgPARAM$40("_12K_HOLD_STOP_DISCHG_VOLT", 39, 0);
        com.lux.luxcloud.global.bean.param.BattChgPARAM.HOLD_BATTERY_WARNING_SOC = new com.lux.luxcloud.global.bean.param.BattChgPARAM$41("HOLD_BATTERY_WARNING_SOC", 40, 0);
        com.lux.luxcloud.global.bean.param.BattChgPARAM.HOLD_BATTERY_WARNING_VOLTAGE = new com.lux.luxcloud.global.bean.param.BattChgPARAM$42("HOLD_BATTERY_WARNING_VOLTAGE", 41, 0);
        com.lux.luxcloud.global.bean.param.BattChgPARAM.$VALUES = com.lux.luxcloud.global.bean.param.BattChgPARAM.$values();
        return;
    }

    private BattChgPARAM(String p1, int p2)
    {
        super(p1, p2);
        return;
    }

    synthetic BattChgPARAM(String p1, int p2, com.lux.luxcloud.global.bean.param.BattChgPARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public static com.lux.luxcloud.global.bean.param.BattChgPARAM valueOf(String p1)
    {
        return ((com.lux.luxcloud.global.bean.param.BattChgPARAM) Enum.valueOf(com.lux.luxcloud.global.bean.param.BattChgPARAM, p1));
    }

    public static com.lux.luxcloud.global.bean.param.BattChgPARAM[] values()
    {
        return ((com.lux.luxcloud.global.bean.param.BattChgPARAM[]) com.lux.luxcloud.global.bean.param.BattChgPARAM.$VALUES.clone());
    }

    public boolean checkEnabled(String p1)
    {
        return 0;
    }

    public boolean checkInvisible(com.lux.luxcloud.global.UserData p3)
    {
        if ((p3.getRole() != null) && (p3.getCurrentInverter() != null)) {
            return (this.checkVisible(p3) ^ 1);
        } else {
            return 1;
        }
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p1)
    {
        return 0;
    }

    protected org.json.JSONObject createDropdown(String[] p7, String[] p8)
    {
        org.json.JSONObject v0_1 = new org.json.JSONObject();
        v0_1.put("type", "select");
        org.json.JSONArray v1_2 = new org.json.JSONArray();
        int v2_0 = 0;
        while (v2_0 < p7.length) {
            org.json.JSONObject v3_1 = new org.json.JSONObject();
            v3_1.put("text", p7[v2_0]);
            v3_1.put("value", p8[v2_0]);
            v1_2.put(v3_1);
            v2_0++;
        }
        v0_1.put("column", v1_2);
        return v0_1;
    }

    protected org.json.JSONObject createInputBox(String p4, String p5)
    {
        org.json.JSONObject v0_1 = new org.json.JSONObject();
        v0_1.put("type", "input");
        v0_1.put("placeholder", "");
        v0_1.put("min", p5);
        v0_1.put("max", p4);
        return v0_1;
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return -1;
    }

    public Object getPlatformSpecificData(com.lux.luxcloud.global.UserData p1)
    {
        return 0;
    }

    public abstract int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p0);

    public boolean isAdmin(com.lux.luxcloud.global.UserData p2)
    {
        return com.lux.luxcloud.global.bean.user.ROLE.ADMIN.equals(p2.getRole());
    }

    public boolean isEg4(com.lux.luxcloud.global.UserData p3)
    {
        if ((!com.lux.luxcloud.global.bean.user.PLATFORM.EG4.equals(com.lux.luxcloud.version.Custom.APP_PLATFORM)) && (!com.lux.luxcloud.global.bean.user.PLATFORM.EG4.equals(p3.getPlatform()))) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isFortress(com.lux.luxcloud.global.UserData p3)
    {
        if ((!com.lux.luxcloud.global.bean.user.PLATFORM.FORTRESS.equals(com.lux.luxcloud.version.Custom.APP_PLATFORM)) && (!com.lux.luxcloud.global.bean.user.PLATFORM.FORTRESS.equals(p3.getPlatform()))) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isLocal(com.lux.luxcloud.global.UserData p2)
    {
        return com.lux.luxcloud.global.bean.user.ROLE.LOCAL.equals(p2.getRole());
    }

    public boolean isMAINTAIN(com.lux.luxcloud.global.UserData p2)
    {
        return com.lux.luxcloud.global.bean.user.ROLE.MAINTAIN.equals(p2.getRole());
    }

    public boolean isViewer(com.lux.luxcloud.global.UserData p2)
    {
        return com.lux.luxcloud.global.bean.user.ROLE.VIEWER.equals(p2.getRole());
    }
}
