package com.lux.luxcloud.global.bean.param;
final enum class PARAM$417 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$417(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$417(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p2)
    {
        return com.lux.luxcloud.global.bean.param.PARAM$417.AFCI_SETTING.checkVisible(p2);
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887231;
    }
}
