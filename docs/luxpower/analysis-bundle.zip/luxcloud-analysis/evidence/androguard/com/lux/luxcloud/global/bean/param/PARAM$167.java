package com.lux.luxcloud.global.bean.param;
final enum class PARAM$167 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$167(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$167(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    private void addOption(java.util.Map p3, String p4, int p5, android.content.Context p6)
    {
        p3.put(p4, new StringBuilder().append(p4).append(": ").append(p6.getString(p5)).toString());
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p5)
    {
        boolean v0_0 = p5.getCurrentInverter();
        if (!v0_0.isGen3Series()) {
            if (((!v0_0.isType6Series()) && (!v0_0.isMega24K())) || (v0_0.isAllInOne())) {
                if (!v0_0.isMidBox()) {
                    return 0;
                } else {
                    if ((this.isViewer(p5)) && (!this.isEg4(p5))) {
                        return 0;
                    } else {
                        return 1;
                    }
                }
            } else {
                if ((this.isViewer(p5)) && (!this.isEg4(p5))) {
                    return 0;
                } else {
                    return 1;
                }
            }
        } else {
            return 0;
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return 2131886772;
    }

    public Object getPlatformSpecificData(com.lux.luxcloud.global.UserData p18, android.content.Context p19)
    {
        String[] v1_30 = p18.getCurrentInverter();
        if (v1_30 != null) {
            String v5_15;
            com.lux.luxcloud.global.bean.param.PARAM$167 v2_6 = new java.util.LinkedHashMap();
            String[] v3_3 = v1_30.getDeviceTypeValue();
            String v4_0 = v1_30.getPhaseValue().intValue();
            if (v1_30.getUsVersion() != null) {
                v5_15 = v1_30.getUsVersion().intValue();
            } else {
                v5_15 = -1;
            }
            String v11_0;
            int v6 = v1_30.getSlaveVersionValue();
            int v7 = v1_30.getFwVersionValue();
            int v8_0 = v1_30.getDtcValue();
            String v9_0 = v1_30.isMega24K();
            int v10_0 = this.isFortress(p18);
            String[] v1_31 = v1_30.isLxpUS8_12k();
            if (v10_0 == 0) {
                v11_0 = "0: UL1741&IEEE1547";
            } else {
                v11_0 = "0: UL1741&IEEE1547-2018";
            }
            boolean v18_1 = v1_31;
            p19 = v9_0;
            boolean v16 = v10_0;
            if (!p19) {
                String v4_1;
                String v0_8 = 1;
                if ((v3_3 != 6) || ((v4_0 != 1) || ((v5_15 != 1) && (v8_0 != 1)))) {
                    v4_1 = 0;
                } else {
                    v4_1 = 1;
                }
                if ((v4_1 == null) && ((v3_3 != 9) && ((!p19) || (v5_15 != 1)))) {
                    v0_8 = 0;
                }
                if (v3_3 != 10) {
                    v2_6.put("0", v11_0);
                    v2_6.put("1", "1: HECO");
                    v2_6.put("2", "2: USA(rule21)");
                }
                if (v0_8 == null) {
                    v2_6.put("3", "3: South Africa");
                    v2_6.put("4", "4: General");
                }
                if (v3_3 != 10) {
                    v2_6.put("5", "5: PR-LUMA");
                    v2_6.put("6", "6: KIUC");
                    if ((v4_1 != null) && ((v6 >= 39) && (v7 >= 39))) {
                        v2_6.put("7", "7: NewEngland");
                    }
                }
                if (v3_3 == 10) {
                    v2_6.put("7", "7: VDE0123");
                    v2_6.put("8", "8: AS4777");
                    v2_6.put("9", "9: Newzealand");
                    v2_6.put("10", "10: CGC");
                    v2_6.put("13", "13: N4105");
                    v2_6.put("14", "14: CEI021");
                    v2_6.put("15", "15: EN50438");
                    v2_6.put("16", "16: EN50438Finland");
                    v2_6.put("17", "17: Japan");
                    v2_6.put("18", "18: PEA");
                    v2_6.put("19", "19: MEA");
                    v2_6.put("20", "20: EN50438Ireland");
                    v2_6.put("21", "21: Czech");
                    v2_6.put("22", "22: Barbados");
                    v2_6.put("23", "23: CEI021ARETI");
                    v2_6.put("24", "24: EN50549");
                    v2_6.put("25", "25: Denmark");
                    v2_6.put("26", "26: PTPiREE(Poland)");
                }
                if ((v3_3 == 6) || (v3_3 == 9)) {
                    v2_6.put("10", "10: Brazil");
                }
                if (v0_8 == null) {
                    v2_6.put("11", "11: G99");
                    v2_6.put("12", "12: G98");
                }
                if ((v18_1) && (v16)) {
                    v2_6.put("13", "13: IEEE 1547 2014");
                }
                String[] v3_0 = new String[0];
                String[] v1_17 = new String[0];
                return this.createDropdown(((String[]) v2_6.values().toArray(v1_17)), ((String[]) v2_6.keySet().toArray(v3_0)));
            } else {
                v2_6.put("0", v11_0);
                v2_6.put("1", "1: Rsvd");
                v2_6.put("2", "2: Rsvd");
                v2_6.put("5", "5: Rsvd");
                v2_6.put("6", "6: Rsvd");
                v2_6.put("10", "10: Rsvd");
                String[] v3_1 = new String[0];
                String[] v3_2 = new String[0];
                return this.createDropdown(((String[]) v2_6.values().toArray(v3_2)), ((String[]) v2_6.keySet().toArray(v3_1)));
            }
        } else {
            return 0;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887475;
    }

    public int getStartRegister()
    {
        return 203;
    }
}
