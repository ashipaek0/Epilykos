package com.lux.luxcloud.global.bean.param;
final enum class PARAM$198 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$198(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$198(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p5)
    {
        int v0_0 = p5.getCurrentInverter();
        if (!this.isLocal(p5)) {
            if ((!v0_0.isEQB()) && (!v0_0.isMidMini())) {
                if ((!v0_0.isSna3_6K_eu()) && (!v0_0.isSnaSeries())) {
                    if ((!v0_0.is7_10KDevice()) || (!this.isViewer(p5))) {
                        if (!v0_0.isGen3Series()) {
                            if ((!v0_0.isAcCharger()) && (!v0_0.isHybird())) {
                                if ((!v0_0.isMidBox()) || ((this.isViewer(p5)) && (!this.isEg4(p5)))) {
                                    if (v0_0.isAllInOne()) {
                                        return 0;
                                    } else {
                                        return (this.isViewer(p5) ^ 1);
                                    }
                                } else {
                                    if (v0_0.getSlaveVersionValue() < 24) {
                                        return 0;
                                    } else {
                                        return 1;
                                    }
                                }
                            } else {
                                if ((!this.isEg4(p5)) && (this.isViewer(p5))) {
                                    return 0;
                                } else {
                                    return 1;
                                }
                            }
                        } else {
                            return 1;
                        }
                    } else {
                        return 0;
                    }
                } else {
                    if ((!this.isEg4Admin(p5)) && ((!this.isAdmin(p5)) && (!this.isMAINTAIN(p5)))) {
                        return 0;
                    } else {
                        return 1;
                    }
                }
            } else {
                return 0;
            }
        } else {
            return 0;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        if (!p1.isMidBox()) {
            return 2131886213;
        } else {
            return 2131886214;
        }
    }
}
