package com.lux.luxcloud.global.bean.param;
final enum class PARAM$217 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$217(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$217(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p5)
    {
        com.lux.luxcloud.global.bean.param.PARAM v0_0 = p5.getCurrentInverter();
        if (!v0_0.isEQB()) {
            if (((!v0_0.isType6Series()) && (!v0_0.isGen3Series())) || ((v0_0.getMachineType() != 1) || ((v0_0.isMega24K()) || ((v0_0.isFlexBoss100()) || (v0_0.isSnaSeriesOrGeta()))))) {
                if (!v0_0.isMidBox()) {
                    if ((!com.lux.luxcloud.global.bean.param.PARAM$217.GENERATOR_FUNCTION.checkVisible(p5)) && ((!com.lux.luxcloud.global.bean.param.PARAM$217.AC_COUPLING_FUNCTION.checkVisible(p5)) && ((!com.lux.luxcloud.global.bean.param.PARAM$217.SMART_LOAD_FUNCTION.checkVisible(p5)) && (!com.lux.luxcloud.global.bean.param.PARAM$217.AC_COUPLE_DARK_START_FUNCTION.checkVisible(p5))))) {
                        return 0;
                    } else {
                        return 1;
                    }
                } else {
                    return 0;
                }
            } else {
                return 0;
            }
        } else {
            return 0;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131886293;
    }
}
