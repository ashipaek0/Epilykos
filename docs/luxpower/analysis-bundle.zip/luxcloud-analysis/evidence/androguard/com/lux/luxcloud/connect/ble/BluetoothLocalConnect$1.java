package com.lux.luxcloud.connect.ble;
 class BluetoothLocalConnect$1 implements com.lux.luxcloud.connect.listener.ConnectListener {
    final synthetic com.lux.luxcloud.connect.ble.BluetoothLocalConnect this$0;
    final synthetic com.lux.luxcloud.connect.ble.InitCallback val$callback;

    BluetoothLocalConnect$1(com.lux.luxcloud.connect.ble.BluetoothLocalConnect p1, com.lux.luxcloud.connect.ble.InitCallback p2)
    {
        this.this$0 = p1;
        this.val$callback = p2;
        return;
    }

    public void onConnected()
    {
        com.lux.luxcloud.connect.ble.InitCallback v0 = this.val$callback;
        if (v0 != null) {
            v0.onSuccess();
        }
        return;
    }

    public void onConnecting()
    {
        com.lux.luxcloud.connect.ble.InitCallback v0 = this.val$callback;
        if (v0 != null) {
            v0.onConnecting();
        }
        return;
    }

    public void onDisconnected()
    {
        com.lux.luxcloud.connect.ble.InitCallback v0 = this.val$callback;
        if (v0 != null) {
            v0.onFail("disconnected");
        }
        return;
    }

    public void onFail(String p2)
    {
        com.lux.luxcloud.connect.ble.InitCallback v0 = this.val$callback;
        if (v0 != null) {
            v0.onFail(p2);
        }
        return;
    }
}
