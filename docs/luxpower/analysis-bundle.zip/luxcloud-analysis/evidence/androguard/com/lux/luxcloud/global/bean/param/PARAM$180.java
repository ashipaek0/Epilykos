package com.lux.luxcloud.global.bean.param;
final enum class PARAM$180 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$180(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$180(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p6)
    {
        boolean v0_0 = p6.getCurrentInverter();
        p6.getRole();
        boolean v1_7 = com.lux.luxcloud.global.GlobalInfo.getInstance().getCurrentClusterGroup();
        if ((!p6.isEnergy100User()) || ((!this.isViewer(p6)) || ((v0_0.getDtcValue() != 0) || (!"firstCluster".equals(v1_7))))) {
            if (((!v0_0.isType6Series()) && (!v0_0.isGen3Series())) || (v0_0.isAllInOne())) {
                if (!v0_0.isMidBox()) {
                    if ((!v0_0.isSnaSeries()) || (!v0_0.isOffGridHardV11())) {
                        return 0;
                    } else {
                        if ((this.isViewer(p6)) && ((!this.isEg4(p6)) && ((!p6.isEnergy100User()) || (!this.isViewer(p6))))) {
                            return 0;
                        } else {
                            return 1;
                        }
                    }
                } else {
                    return 1;
                }
            } else {
                return 1;
            }
        } else {
            if ((!v0_0.isSnaSeriesOrGeta()) && (!v0_0.isHybird())) {
                return 0;
            } else {
                return 1;
            }
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return 2131886799;
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887315;
    }

    public int getStartRegister()
    {
        return 220;
    }
}
