package com.lux.luxcloud.global.bean.param;
final enum class PARAM$271 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$271(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$271(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p8)
    {
        com.lux.luxcloud.global.bean.inverter.Inverter v0 = p8.getCurrentInverter();
        if (!v0.isGen3Series()) {
            if ((!v0.isType6Series()) || ((v0.isAllInOne()) || ((!com.lux.luxcloud.global.bean.user.ROLE.ADMIN.equals(p8.getRole())) && ((com.lux.luxcloud.global.bean.user.ROLE.VIEWER.equals(p8.getRole())) || ((p8.getClusterId() != 4) && (p8.getClusterId() != 100)))))) {
                v0.isMidBox();
                return 0;
            } else {
                return 1;
            }
        } else {
            return 0;
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return 2131886746;
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131886867;
    }
}
