package com.lux.luxcloud.global.bean.param;
final enum class PARAM$409 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$409(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$409(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p9)
    {
        p9.getRole();
        boolean v0_0 = p9.getCurrentInverter();
        if ((!v0_0.isAcCharger()) && (!v0_0.isHybird())) {
            if (!v0_0.isMega24K()) {
                if ((!v0_0.isType6Series()) || (v0_0.isAllInOne())) {
                    if ((!v0_0.isSnaSeries()) || ((!this.isAdmin(p9)) && ((!this.isMAINTAIN(p9)) || ((p9.getClusterId() != 1) && (p9.getClusterId() != 4))))) {
                        return 0;
                    } else {
                        if ((!v0_0.is6000XP()) && (!v0_0.is12000XP())) {
                            return 0;
                        } else {
                            return 1;
                        }
                    }
                } else {
                    if ((this.isViewer(p9)) && (!this.isEg4(p9))) {
                        return 0;
                    } else {
                        return 1;
                    }
                }
            } else {
                return (this.isViewer(p9) ^ 1);
            }
        } else {
            return 1;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887193;
    }
}
