package com.lux.luxcloud.global.bean.param;
final enum class PARAM$290 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$290(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$290(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p4)
    {
        com.lux.luxcloud.global.bean.inverter.Inverter v0 = p4.getCurrentInverter();
        if (!v0.isAcCharger()) {
            if (!v0.isHybird()) {
                if (com.lux.luxcloud.global.bean.param.PARAM$290.BIT_AC_CHARGE_TYPE.checkVisible(p4)) {
                    if ((!v0.isType6Series()) && (!v0.isGen3Series())) {
                        if (!v0.isMidBox()) {
                            return 0;
                        } else {
                            return 1;
                        }
                    } else {
                        return 1;
                    }
                } else {
                    return 0;
                }
            } else {
                return this.checkHybridFirmware20240811(v0);
            }
        } else {
            return 1;
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        p1.getCurrentInverter();
        return 2131886793;
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p2)
    {
        if ((!p2.isHybird()) && ((!p2.isAcCharger()) && (!p2.isMidBox()))) {
            return 2131887294;
        } else {
            return 2131887295;
        }
    }

    public int getStartRegister()
    {
        return 67;
    }
}
