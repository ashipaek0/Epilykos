package com.lux.luxcloud.global.bean.param;
final enum class PARAM$266 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$266(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$266(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p5)
    {
        boolean v0_0 = p5.getCurrentInverter();
        if (!v0_0.isGen3Series()) {
            if (!v0_0.isSnaSeriesOrGeta()) {
                if (!v0_0.is12KUsVersion()) {
                    if (((!v0_0.isType6Series()) || (v0_0.isAllInOne())) && ((!v0_0.isGen2_7_14K()) && ((!v0_0.is7_10KDevice()) && ((!v0_0.isGen3_6K()) && (!v0_0.isTrip12K()))))) {
                        if (!v0_0.isMidBox()) {
                            return 0;
                        } else {
                            if ((p5.isGigabiz1User()) && ((this.isViewer(p5)) && (!this.isEg4(p5)))) {
                                return 0;
                            } else {
                                return 1;
                            }
                        }
                    } else {
                        if ((p5.isGigabiz1User()) && ((this.isViewer(p5)) && (!this.isEg4(p5)))) {
                            return 0;
                        } else {
                            return 1;
                        }
                    }
                } else {
                    return 1;
                }
            } else {
                if ((this.isViewer(p5)) && (!this.isEg4(p5))) {
                    return 0;
                } else {
                    return 1;
                }
            }
        } else {
            return 0;
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return 2131886752;
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p2)
    {
        if ((!p2.isMidBox()) && ((!p2.is7_10KDevice()) && ((!p2.isType6Series()) && ((!p2.isTrip12K()) && (!p2.isSnaSeriesOrGeta()))))) {
            return 2131887130;
        } else {
            return 2131887118;
        }
    }
}
