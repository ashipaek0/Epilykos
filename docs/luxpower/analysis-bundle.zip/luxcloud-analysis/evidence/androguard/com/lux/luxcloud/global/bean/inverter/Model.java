package com.lux.luxcloud.global.bean.inverter;
public class Model {
    private int batteryType;
    private int leadAcidType;
    private int lithiumType;
    private int measurement;
    private int meterBrand;
    private int meterType;
    private int powerRating;
    private int powerRatingBit3;
    private int rule;
    private int ruleMask;
    private int usVersion;
    private int wirelessMeter;

    public Model()
    {
        return;
    }

    public Model(long p9)
    {
        this.rule = ((int) (p9 & 31));
        this.powerRating = ((int) ((p9 >> 5) & 7));
        long v2_3 = ((int) ((p9 >> 8) & 3));
        this.batteryType = v2_3;
        long v6 = (p9 >> 10);
        if (v2_3 != 1) {
            if (v2_3 == 2) {
                this.lithiumType = ((int) (31 & v6));
            }
        } else {
            this.leadAcidType = ((int) (31 & v6));
        }
        this.ruleMask = ((int) ((p9 >> 15) & 1));
        this.measurement = ((int) ((p9 >> 16) & 1));
        this.meterBrand = ((int) ((p9 >> 17) & 3));
        this.usVersion = ((int) ((p9 >> 19) & 1));
        this.meterType = ((int) ((p9 >> 20) & 1));
        this.powerRatingBit3 = ((int) ((p9 >> 24) & 1));
        this.wirelessMeter = ((int) ((p9 >> 25) & 1));
        return;
    }

    public int getBatteryType()
    {
        return this.batteryType;
    }

    public String getBatteryTypeText()
    {
        String v0_0 = this.batteryType;
        if (v0_0 == null) {
            return "No battery";
        } else {
            if (v0_0 == 1) {
                return "Lead-acid";
            } else {
                if (v0_0 == 2) {
                    return "Lithium";
                } else {
                    return "";
                }
            }
        }
    }

    public int getLeadAcidType()
    {
        return this.leadAcidType;
    }

    public String getLeadAcidTypeText()
    {
        switch (this.leadAcidType) {
            case 0:
                return "50Ah";
            case 1:
                return "100Ah";
            case 2:
                return "150Ah";
            case 3:
                return "200Ah";
            case 4:
                return "250Ah";
            case 5:
                return "300Ah";
            case 6:
                return "350Ah";
            case 7:
                return "400Ah";
            case 8:
                return "450Ah";
            case 9:
                return "500Ah";
            case 10:
                return "550Ah";
            case 11:
                return "600Ah";
            case 12:
                return "650Ah";
            default:
                return "";
        }
    }

    public int getLithiumType()
    {
        return this.lithiumType;
    }

    public int getMeasurement()
    {
        return this.measurement;
    }

    public String getMeasurementText()
    {
        String v0_0 = this.measurement;
        if (v0_0 == null) {
            return "Meter";
        } else {
            if (v0_0 == 1) {
                return "CT";
            } else {
                return "";
            }
        }
    }

    public int getMeterBrand()
    {
        return this.meterBrand;
    }

    public String getMeterBrandText()
    {
        String v0_0 = this.meterBrand;
        if (v0_0 == null) {
            return "Eastron";
        } else {
            if (v0_0 == 1) {
                return "WattNode/Rsvd";
            } else {
                if (v0_0 == 2) {
                    return "Rsvd";
                } else {
                    if (v0_0 == 3) {
                        return "Chint";
                    } else {
                        return "";
                    }
                }
            }
        }
    }

    public int getMeterType()
    {
        return this.meterType;
    }

    public String getMeterTypeText()
    {
        String v0_0 = this.meterType;
        if (v0_0 == null) {
            return "1 Phase Meter";
        } else {
            if (v0_0 == 1) {
                return "3 Phase Meter";
            } else {
                return "";
            }
        }
    }

    public long getModel(long p8)
    {
        long v2_0;
        long v2_30 = this.batteryType;
        long v0_2 = ((((long) this.rule) + (((long) this.powerRating) << 5)) + (((long) v2_30) << 8));
        if (v2_30 != 1) {
            if (v2_30 == 2) {
                v2_0 = this.lithiumType;
                v0_2 += (((long) v2_0) << 10);
            }
        } else {
            v2_0 = this.leadAcidType;
        }
        return (((((((((v0_2 + (((long) this.ruleMask) << 15)) + (((long) this.measurement) << 16)) + (((long) this.meterBrand) << 17)) + (((long) this.usVersion) << 19)) + (((long) this.meterType) << 20)) + (((p8 >> 21) & 7) << 21)) + (((long) this.powerRatingBit3) << 24)) + (((long) this.wirelessMeter) << 25)) + (p8 & -67108864));
    }

    public int getRule()
    {
        return this.rule;
    }

    public int getRuleMask()
    {
        return this.ruleMask;
    }

    public String getRuleMaskText()
    {
        String v0_0 = this.ruleMask;
        if (v0_0 == null) {
            return "Strict";
        } else {
            if (v0_0 == 1) {
                return "Easy";
            } else {
                return "";
            }
        }
    }

    public int getUsVersion()
    {
        return this.usVersion;
    }

    public String getUsVersionText()
    {
        String v0_0 = this.usVersion;
        if (v0_0 == null) {
            return "Standard Version";
        } else {
            if (v0_0 == 1) {
                return "US Version";
            } else {
                return "";
            }
        }
    }

    public int getWholePowerRating()
    {
        return ((this.powerRatingBit3 << 3) + this.powerRating);
    }

    public int getWirelessMeter()
    {
        return this.wirelessMeter;
    }

    public String getWirelessMeterText()
    {
        String v0_0 = this.wirelessMeter;
        if (v0_0 == null) {
            return "Disable";
        } else {
            if (v0_0 == 1) {
                return "Enable";
            } else {
                return "";
            }
        }
    }

    public void setBatteryType(int p1)
    {
        this.batteryType = p1;
        return;
    }

    public void setLeadAcidType(int p1)
    {
        this.leadAcidType = p1;
        return;
    }

    public void setLithiumType(int p1)
    {
        this.lithiumType = p1;
        return;
    }

    public void setMeasurement(int p1)
    {
        this.measurement = p1;
        return;
    }

    public void setMeterBrand(int p1)
    {
        this.meterBrand = p1;
        return;
    }

    public void setMeterType(int p1)
    {
        this.meterType = p1;
        return;
    }

    public void setRule(int p1)
    {
        this.rule = p1;
        return;
    }

    public void setRuleMask(int p1)
    {
        this.ruleMask = p1;
        return;
    }

    public void setUsVersion(int p1)
    {
        this.usVersion = p1;
        return;
    }

    public void setWholePowerRating(int p2)
    {
        this.powerRating = (p2 & 7);
        this.powerRatingBit3 = ((p2 >> 3) & 1);
        return;
    }

    public void setWirelessMeter(int p1)
    {
        this.wirelessMeter = p1;
        return;
    }

    public String toString()
    {
        return new StringBuilder("Model{wirelessMeter=").append(this.wirelessMeter).append(", powerRatingBit3=").append(this.powerRatingBit3).append(", meterType=").append(this.meterType).append(", usVersion=").append(this.usVersion).append(", meterBrand=").append(this.meterBrand).append(", measurement=").append(this.measurement).append(", ruleMask=").append(this.ruleMask).append(", batteryType=").append(this.batteryType).append(", leadAcidType=").append(this.leadAcidType).append(", lithiumType=").append(this.lithiumType).append(", powerRating=").append(this.powerRating).append(", rule=").append(this.rule).append(125).toString();
    }
}
