package com.lux.luxcloud.global.bean.param;
final enum class PARAM$361 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$361(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$361(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p5)
    {
        boolean v0_0 = p5.getCurrentInverter();
        if (!v0_0.isGen3()) {
            if (((!v0_0.isType6Series()) || ((v0_0.getSlaveVersionValue() < 29) || (v0_0.getFwVersionValue() < 29))) && (!v0_0.isFlexBoss100())) {
                return 0;
            } else {
                if ((!this.isAdmin(p5)) && ((!this.isMAINTAIN(p5)) && (!this.isEg4(p5)))) {
                    return 0;
                } else {
                    return 1;
                }
            }
        } else {
            return 0;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887111;
    }
}
