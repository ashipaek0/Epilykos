package com.lux.luxcloud.global.bean.param;
final enum class PARAM$117 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$117(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$117(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p5)
    {
        com.lux.luxcloud.global.bean.user.ROLE v0 = p5.getRole();
        boolean v1_0 = p5.getCurrentInverter();
        if ((!v1_0.isAcCharger()) && (!v1_0.isHybird())) {
            return 0;
        } else {
            if ((!this.isAdmin(p5)) && (!v0.getOwnerLevelCheck())) {
                return 0;
            } else {
                return 1;
            }
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131886149;
    }

    public int getStartRegister()
    {
        return 137;
    }
}
