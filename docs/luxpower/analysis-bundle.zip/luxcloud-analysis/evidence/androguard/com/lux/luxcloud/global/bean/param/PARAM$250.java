package com.lux.luxcloud.global.bean.param;
final enum class PARAM$250 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$250(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$250(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p7)
    {
        boolean v7_2;
        com.lux.luxcloud.global.bean.user.ROLE v0_0 = p7.getCurrentInverter();
        if (((!v0_0.isAcCharger()) && (!v0_0.isHybird())) || (v0_0.isTrip12K())) {
            if ((((!v0_0.isType6Series()) && (!v0_0.isGen3Series())) || (v0_0.isAllInOne())) && (!v0_0.isMidBox())) {
                if ((!v0_0.isSnaSeries()) || ((p7.getClusterId() != 4) && (p7.getClusterId() != 100))) {
                    return 0;
                } else {
                    v7_2 = com.lux.luxcloud.global.bean.user.ROLE.VIEWER.equals(p7.getRole());
                }
            } else {
                if ((v0_0.isTrip12K()) || (v0_0.isGen3_6K())) {
                    return 0;
                } else {
                    if ((!this.isEg4(p7)) && (this.isViewer(p7))) {
                        return 0;
                    } else {
                        return 1;
                    }
                }
            }
        } else {
            v7_2 = this.isViewer(p7);
        }
        return (v7_2 ^ 1);
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return 2131886745;
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887682;
    }
}
