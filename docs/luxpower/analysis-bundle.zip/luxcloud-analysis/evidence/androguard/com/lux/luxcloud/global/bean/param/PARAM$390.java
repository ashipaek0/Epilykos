package com.lux.luxcloud.global.bean.param;
final enum class PARAM$390 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$390(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$390(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p5)
    {
        boolean v0_0 = p5.getCurrentInverter();
        new com.lux.luxcloud.global.bean.inverter.Model(v0_0.getModel().longValue()).getMeasurement();
        if (!v0_0.isType6Series()) {
            if ((!v0_0.isSna3_6K_eu()) && ((!v0_0.isGen3()) && (!v0_0.isGen3Pro()))) {
                return 0;
            } else {
                if ((!this.isAdmin(p5)) && (!this.isMAINTAIN(p5))) {
                    return 0;
                } else {
                    return 1;
                }
            }
        } else {
            if ((this.isViewer(p5)) && (!this.isEg4(p5))) {
                return 0;
            } else {
                return 1;
            }
        }
    }

    public Object getPlatformSpecificData(com.lux.luxcloud.global.UserData p3, android.content.Context p4)
    {
        org.json.JSONObject v3_1 = new java.util.LinkedHashMap();
        v3_1.put("0", p4.getString(2131887263));
        v3_1.put("1", p4.getString(2131887264));
        return this.createDropdownFromMap(v3_1);
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887268;
    }
}
