package com.lux.luxcloud.global.bean.param;
final enum class PARAM$255 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$255(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$255(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p5)
    {
        int v0_0 = p5.getCurrentInverter();
        new com.lux.luxcloud.global.bean.inverter.Model(v0_0.getModel().longValue()).getMeasurement();
        if ((!p5.isGigabiz1User()) || (!com.lux.luxcloud.global.bean.user.ROLE.VIEWER.equals(p5.getRole()))) {
            if (((!v0_0.isType6Series()) && (!v0_0.isGen3Series())) || (v0_0.isAllInOne())) {
                if ((!v0_0.isSna3_6K_eu()) && ((!v0_0.isGen3()) && (!v0_0.isGen3Pro()))) {
                    if ((!v0_0.isAcCharger()) && (!v0_0.isHybird())) {
                        if (((!v0_0.isMidBox()) || ((this.isViewer(p5)) && (!this.isEg4(p5)))) || (v0_0.getSlaveVersionValue() < 24)) {
                            return 0;
                        } else {
                            return 1;
                        }
                    } else {
                        return (this.isViewer(p5) ^ 1);
                    }
                } else {
                    if ((!this.isAdmin(p5)) && (!this.isMAINTAIN(p5))) {
                        return 0;
                    } else {
                        return 1;
                    }
                }
            } else {
                if ((this.isViewer(p5)) && (!this.isEg4(p5))) {
                    return 0;
                } else {
                    return 1;
                }
            }
        } else {
            return 0;
        }
    }

    public Object getPlatformSpecificData(com.lux.luxcloud.global.UserData p11, android.content.Context p12)
    {
        boolean v11_1 = p11.getCurrentInverter();
        if (v11_1) {
            java.util.LinkedHashMap v0_1 = new java.util.LinkedHashMap();
            if ((!v11_1.isType6Series()) && (!v11_1.isMidBox())) {
                if (!v11_1.isGen3_6K()) {
                    if (!v11_1.isHybird()) {
                        if (!v11_1.isMega24K()) {
                            this.addPlainOption(v0_1, "0", 2131887266, p12);
                            this.addPlainOption(v0_1, "1", 2131887632, p12);
                            this.addPlainOption(v0_1, "2", 2131887632, p12);
                            this.addPlainOption(v0_1, "3", 2131887265, p12);
                        } else {
                            this.addPlainOption(v0_1, "0", 2131887266, p12);
                            this.addPlainOption(v0_1, "1", 2131887267, p12);
                        }
                    } else {
                        this.addPlainOption(v0_1, "0", 2131887266, p12);
                    }
                } else {
                    this.addPlainOption(v0_1, "0", 2131887266, p12);
                    this.addPlainOption(v0_1, "1", 2131887632, p12);
                    this.addPlainOption(v0_1, "3", 2131887265, p12);
                }
            } else {
                this.addPlainOption(v0_1, "0", 2131887266, p12);
                this.addPlainOption(v0_1, "1", 2131887267, p12);
                this.addPlainOption(v0_1, "2", 2131887632, p12);
                this.addPlainOption(v0_1, "3", 2131887265, p12);
            }
            return this.createDropdownFromMap(v0_1);
        } else {
            return 0;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131886471;
    }
}
