package com.lux.luxcloud.connect.ble;
 class BleManager$3 implements com.lux.luxcloud.connect.ble.InitCallback {
    final synthetic com.lux.luxcloud.connect.ble.BleManager this$0;
    final synthetic com.lux.luxcloud.connect.ble.InitCallback val$callback;

    BleManager$3(com.lux.luxcloud.connect.ble.BleManager p1, com.lux.luxcloud.connect.ble.InitCallback p2)
    {
        this.this$0 = p1;
        this.val$callback = p2;
        return;
    }

    public void onFail(String p2)
    {
        this.val$callback.onFail(p2);
        return;
    }

    public void onSuccess()
    {
        com.lux.luxcloud.connect.ble.BleManager.access$002(this.this$0, 1);
        this.val$callback.onSuccess();
        return;
    }
}
