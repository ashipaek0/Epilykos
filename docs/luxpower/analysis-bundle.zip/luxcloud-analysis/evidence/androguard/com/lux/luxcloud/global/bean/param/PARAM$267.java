package com.lux.luxcloud.global.bean.param;
final enum class PARAM$267 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$267(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$267(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p7)
    {
        boolean v0_0 = p7.getCurrentInverter();
        if ((!v0_0.isSnaSeries()) || ((!v0_0.isGeta()) && ((((v0_0.getDeviceTypeValue() != 3) || (v0_0.getHardwareVersion() < 11)) && ((v0_0.getSubDeviceTypeValue() != 131) && (v0_0.getDeviceTypeValue() != 11))) || (v0_0.is_ENELEAGE_ZERO())))) {
            if ((!v0_0.isAcCharger()) && ((!v0_0.isHybird()) && ((!v0_0.isType6Series()) && (!v0_0.isGen3Series())))) {
                return 0;
            } else {
                return (this.isViewer(p7) ^ 1);
            }
        } else {
            if ((this.isViewer(p7)) && (!this.isEg4(p7))) {
                return 0;
            } else {
                return 1;
            }
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return 2131886739;
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887122;
    }
}
