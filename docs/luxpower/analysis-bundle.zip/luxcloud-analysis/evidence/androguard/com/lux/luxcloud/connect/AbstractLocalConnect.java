package com.lux.luxcloud.connect;
public abstract class AbstractLocalConnect implements com.lux.luxcloud.connect.LocalConnect {
    protected String connectType;
    protected boolean connected;
    protected String datalogSn;
    protected com.lux.luxcloud.global.bean.inverter.Inverter inverter;
    protected com.lux.luxcloud.protocol.tcp.dataframe.tcp.TCP_PROTOCOL tcpProtocol;

    public AbstractLocalConnect(String p2)
    {
        this.tcpProtocol = com.lux.luxcloud.protocol.tcp.dataframe.tcp.TCP_PROTOCOL._02;
        this.connectType = p2;
        return;
    }

    public boolean functionControl(int p4, int p5, boolean p6)
    {
        if (!this.initialize(1)) {
            return 0;
        } else {
            Integer v1_1 = this.readSingle03(p4);
            if (v1_1 != null) {
                int v5_5;
                if (p6 == 0) {
                    v5_5 = Integer.valueOf((((~ (1 << p5)) & 65535) & v1_1.intValue()));
                } else {
                    v5_5 = Integer.valueOf(((1 << p5) | v1_1.intValue()));
                }
                return this.writeSingle(p4, Integer.valueOf((v5_5.intValue() & 65535)).intValue());
            } else {
                return 0;
            }
        }
    }

    public String getConnectType()
    {
        return this.connectType;
    }

    public String getDatalogSn()
    {
        return this.datalogSn;
    }

    public com.lux.luxcloud.global.bean.inverter.Inverter getInverter()
    {
        return this.inverter;
    }

    public com.lux.luxcloud.protocol.tcp.dataframe.tcp.TCP_PROTOCOL getTcpProtocol()
    {
        return this.tcpProtocol;
    }

    public void initDongleSn()
    {
        this.datalogSn = com.lux.luxcloud.global.Constants.DEFAULT_DATALOG_SN;
        return;
    }

    public boolean read03AndInitDevice()
    {
        Integer v0_1 = this.sendCommand("read_03_1", com.lux.luxcloud.protocol.tcp.DataFrameFactory.createReadMultiHoldDataFrame(this.getTcpProtocol(), this.getDatalogSn(), 0, 40));
        if ((com.lux.luxcloud.tool.Tool.isEmpty(v0_1)) || (v0_1.length() <= 60)) {
            return 0;
        } else {
            com.lux.luxcloud.global.bean.inverter.Inverter v1_3 = new com.lux.luxcloud.global.bean.inverter.Inverter();
            v1_3.setDatalogSn(com.lux.luxcloud.tool.FrameTool.getDatalogSn(v0_1));
            v1_3.setSerialNum(com.lux.luxcloud.tool.FrameTool.getInverterSn(v0_1));
            int v2_14 = com.lux.luxcloud.tool.FrameTool.getRegister4(v0_1, 0);
            v1_3.setModel(Long.valueOf(v2_14));
            int v4_3 = new com.lux.luxcloud.global.bean.inverter.Model(v2_14);
            v1_3.setBatteryTypeFromModel(com.lux.luxcloud.global.bean.inverter.BATTERY_TYPE.getBatteryTypeByCode(((int) ((v2_14 >> 8) & 3))));
            if (com.lux.luxcloud.global.bean.inverter.BATTERY_TYPE.LEAD_ACID.equals(v1_3.getBatteryTypeFromModel())) {
                v1_3.setLeadAcidType(Integer.valueOf(((int) ((v2_14 >> 10) & 31))));
            }
            int v3_3;
            int v2_21 = com.lux.luxcloud.tool.FrameTool.getRegister2(v0_1, 19);
            int v5_11 = ((v2_21 >> 1) & 15);
            String v7_4 = ((v2_21 >> 5) & 7);
            int v9_1 = ((v2_21 >> 8) & 1);
            int v11_1 = ((v2_21 >> 9) & 12);
            int v2_23 = ((v2_21 >> 13) & 15);
            if ((v2_21 & 1) != 0) {
                v3_3 = 3;
            } else {
                v3_3 = 1;
            }
            v1_3.setPhase(Integer.valueOf(v3_3));
            v1_3.setDeviceType(Integer.valueOf(v5_11));
            v1_3.setDtc(Integer.valueOf(v7_4));
            v1_3.setVoltClass(Integer.valueOf(v9_1));
            v1_3.setOdm(Integer.valueOf(v11_1));
            v1_3.setMachineType(v2_23);
            v1_3.setUsVersion(Integer.valueOf(v4_3.getUsVersion()));
            v1_3.setPowerRating(Integer.valueOf(v4_3.getWholePowerRating()));
            int v3_0 = com.lux.luxcloud.tool.FrameTool.getRegHighInt(v0_1, 9);
            int v2_2 = com.lux.luxcloud.tool.FrameTool.getRegLowInt(v0_1, 9);
            int v4_0 = com.lux.luxcloud.tool.FrameTool.getRegLowInt(v0_1, 10);
            v1_3.setSlaveVersion(Integer.valueOf(v3_0));
            v1_3.setFwVersion(Integer.valueOf(v4_0));
            v1_3.setStandard(com.lux.luxcloud.tool.FrameTool.getRegisterText(v0_1, 7, 2));
            if ((!v1_3.isSnaSeries()) && (!v1_3.isLsp())) {
                v1_3.setFwCode(new StringBuilder().append(com.lux.luxcloud.tool.FrameTool.getRegisterText(v0_1, 7, 2)).append("-").append(com.lux.luxcloud.tool.ProTool.showHex(v3_0)).append(com.lux.luxcloud.tool.ProTool.showHex(v4_0)).toString());
            } else {
                v1_3.setFwCode(new StringBuilder().append(com.lux.luxcloud.tool.FrameTool.getRegisterText(v0_1, 7, 2)).append("-").append(com.lux.luxcloud.tool.ProTool.showHex(v2_2)).append(com.lux.luxcloud.tool.ProTool.showHex(v3_0)).append(com.lux.luxcloud.tool.ProTool.showHex(v4_0)).toString());
            }
            if (!v1_3.isSnaSeries()) {
                if (!v1_3.isSna12K()) {
                    if ((v1_3.isType6()) && (v1_3.getPowerRating() != null)) {
                        if (!v1_3.is12KUsVersion()) {
                            if ((v1_3.getPowerRating().intValue() != 3) && (v1_3.getPowerRating().intValue() != 6)) {
                                v1_3.setSubDeviceType(Integer.valueOf(161));
                            } else {
                                v1_3.setSubDeviceType(Integer.valueOf(162));
                            }
                        } else {
                            if ((v1_3.getPowerRating().intValue() != 3) && (v1_3.getPowerRating().intValue() != 6)) {
                                v1_3.setSubDeviceType(Integer.valueOf(163));
                            } else {
                                v1_3.setSubDeviceType(Integer.valueOf(164));
                            }
                        }
                    }
                } else {
                    Integer v0_37;
                    if (!v1_3.isDtcAmerica()) {
                        v0_37 = 1110;
                    } else {
                        v0_37 = 1111;
                    }
                    v1_3.setSubDeviceType(Integer.valueOf(v0_37));
                }
            } else {
                Integer v0_40;
                if (!v1_3.isDtcAmerica()) {
                    v0_40 = 0;
                } else {
                    v0_40 = Integer.valueOf(131);
                }
                v1_3.setSubDeviceType(v0_40);
            }
            this.setInverter(v1_3);
            return 1;
        }
    }

    public String readDatalogParam(int p4)
    {
        if ((this.initialize(1)) && (!com.lux.luxcloud.tool.Tool.isEmpty(this.datalogSn))) {
            String v4_3 = this.sendCommand(new StringBuilder("read_datalog_").append(p4).toString(), com.lux.luxcloud.protocol.tcp.DataFrameFactory.createReadDatalogParamDataFrame(this.tcpProtocol, this.datalogSn, p4), 15);
            if ((!com.lux.luxcloud.tool.Tool.isEmpty(v4_3)) && (v4_3.length() > 22)) {
                return v4_3.substring(22);
            }
        }
        return 0;
    }

    public org.json.JSONObject readMultiHold(int p7, int p8)
    {
        org.json.JSONObject v1_1 = new org.json.JSONObject();
        try {
            if (this.initialize(1)) {
                int v8_1 = (p8 * 2);
                String v7_5 = this.sendCommand(new StringBuilder("read_multi_03_").append(p7).append("_").append(v8_1).toString(), com.lux.luxcloud.protocol.tcp.DataFrameFactory.createReadMultiHoldDataFrame(this.tcpProtocol, this.datalogSn, p7, p8));
                if ((!com.lux.luxcloud.tool.Tool.isEmpty(v7_5)) && (v7_5.length() > 36)) {
                    v1_1.put("success", 1);
                    v1_1.put("valueFrame", v7_5.substring(35, (v8_1 + 35)));
                    return v1_1;
                }
            }
        } catch (String v7_8) {
            v7_8.printStackTrace();
            return v1_1;
        }
        v1_1.put("success", 0);
        return v1_1;
    }

    public String readMultiInput(int p4, int p5)
    {
        try {
            if ((this.initialize(1)) && (!com.lux.luxcloud.tool.Tool.isEmpty(this.datalogSn))) {
                return this.sendCommand(new StringBuilder("read_multi_04_").append(p4).append("_").append((p5 * 2)).toString(), com.lux.luxcloud.protocol.tcp.DataFrameFactory.createReadMultiInputDataFrame(this.tcpProtocol, this.datalogSn, p4, p5));
            }
        } catch (String v4_7) {
            v4_7.printStackTrace();
        }
        return 0;
    }

    public Integer readSingle03(int p4)
    {
        if ((this.initialize(1)) && (!com.lux.luxcloud.tool.Tool.isEmpty(this.datalogSn))) {
            Integer v4_3 = this.sendCommand(new StringBuilder("read_single_03_").append(p4).toString(), com.lux.luxcloud.protocol.tcp.DataFrameFactory.createReadSingleHoldDataFrame(this.tcpProtocol, this.datalogSn, p4));
            if ((!com.lux.luxcloud.tool.Tool.isEmpty(v4_3)) && (v4_3.length() > 36)) {
                return Integer.valueOf(com.lux.luxcloud.tool.ProTool.count(v4_3.charAt(36), v4_3.charAt(35)));
            }
        }
        return 0;
    }

    public void setDatalogSn(String p1)
    {
        this.datalogSn = p1;
        return;
    }

    public void setInverter(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        this.inverter = p1;
        return;
    }

    public void setTcpProtocol(com.lux.luxcloud.protocol.tcp.dataframe.tcp.TCP_PROTOCOL p1)
    {
        this.tcpProtocol = p1;
        return;
    }

    public boolean writeDatalogParam(int p2, String p3)
    {
        if (com.lux.luxcloud.tool.Tool.isEmpty(p3)) {
            return 0;
        } else {
            return this.writeDatalogParam(p2, p3.getBytes(java.nio.charset.StandardCharsets.ISO_8859_1));
        }
    }

    public boolean writeDatalogParam(int p5, byte[] p6)
    {
        if ((this.initialize(1)) && (!com.lux.luxcloud.tool.Tool.isEmpty(this.datalogSn))) {
            char v5_3 = this.sendCommand(new StringBuilder("write_datalog_").append(p5).toString(), com.lux.luxcloud.protocol.tcp.DataFrameFactory.createWriteDatalogParamDataFrame(this.tcpProtocol, this.datalogSn, p5, p6));
            if ((!com.lux.luxcloud.tool.Tool.isEmpty(v5_3)) && ((v5_3.length() == 21) && (v5_3.charAt(20) == 0))) {
                return 1;
            }
        }
        return 0;
    }

    public boolean writeMulti(int p6, int p7, byte[] p8)
    {
        if ((this.initialize(1)) && (!com.lux.luxcloud.tool.Tool.isEmpty(this.datalogSn))) {
            int v8_2 = this.sendCommand(new StringBuilder("write_multi_06_").append(p6).append("_").append(p7).toString(), com.lux.luxcloud.protocol.tcp.DataFrameFactory.createWriteMultiDataFrame(this.tcpProtocol, this.datalogSn, p6, p7, p8));
            if ((!com.lux.luxcloud.tool.Tool.isEmpty(v8_2)) && (v8_2.length() > 33)) {
                int v1_10 = com.lux.luxcloud.tool.ProTool.count(v8_2.charAt(33), v8_2.charAt(32));
                int vtmp16 = com.lux.luxcloud.tool.ProTool.count(v8_2.charAt(35), v8_2.charAt(34));
                if ((p6 == v1_10) && (p7 == vtmp16)) {
                    return 1;
                }
            }
        }
        return 0;
    }

    public boolean writeSingle(int p5, int p6)
    {
        if ((this.initialize(1)) && (!com.lux.luxcloud.tool.Tool.isEmpty(this.datalogSn))) {
            int v6_2 = this.sendCommand("write_single_06", com.lux.luxcloud.protocol.tcp.DataFrameFactory.createWriteSingleDataFrame(this.tcpProtocol, this.datalogSn, p5, p6));
            if ((!com.lux.luxcloud.tool.Tool.isEmpty(v6_2)) && ((v6_2.length() > 33) && (p5 == com.lux.luxcloud.tool.ProTool.count(v6_2.charAt(33), v6_2.charAt(32))))) {
                return 1;
            }
        }
        return 0;
    }
}
