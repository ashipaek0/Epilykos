package com.lux.luxcloud.connect.ble;
 class BleManager$1 extends android.bluetooth.le.ScanCallback {
    final synthetic com.lux.luxcloud.connect.ble.BleManager this$0;
    final synthetic com.lux.luxcloud.connect.ble.BleScanCallback val$callback;
    final synthetic java.util.concurrent.atomic.AtomicBoolean val$matchedOnce;
    final synthetic String val$targetName;

    BleManager$1(com.lux.luxcloud.connect.ble.BleManager p1, String p2, java.util.concurrent.atomic.AtomicBoolean p3, com.lux.luxcloud.connect.ble.BleScanCallback p4)
    {
        this.this$0 = p1;
        this.val$targetName = p2;
        this.val$matchedOnce = p3;
        this.val$callback = p4;
        return;
    }

    public void onScanFailed(int p4)
    {
        this.val$callback.onScanError(new StringBuilder("Scan failed, code=").append(p4).toString());
        return;
    }

    public void onScanResult(int p6, android.bluetooth.le.ScanResult p7)
    {
        p6 = p7.getDevice();
        if (p6 != null) {
            String v0_0 = p6.getName();
            String v1_1 = p6.getAddress();
            System.out.println(new StringBuilder("LuxPower - BLE ScanResult => name=").append(v0_0).append(", addr=").append(v1_1).append(", rssi=").append(p7.getRssi()).toString());
            if ((v0_0 != null) && ((v0_0.trim().equalsIgnoreCase(this.val$targetName)) && (this.val$matchedOnce.compareAndSet(0, 1)))) {
                System.out.println(new StringBuilder("LuxPower - BLE: \u5339\u914d\u5230\u76ee\u6807\u8bbe\u5907 => ").append(v0_0).append(" (").append(v1_1).append(")").toString());
                try {
                    com.lux.luxcloud.connect.ble.BleManager.-$$Nest$fgetbleScanner(this.this$0).stopScan(this);
                } catch (Exception) {
                }
                com.lux.luxcloud.connect.ble.BleManager.-$$Nest$mbind(this.this$0, p6);
                this.val$callback.onDeviceFound(p6);
            }
        }
        return;
    }
}
