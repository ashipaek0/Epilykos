package com.lux.luxcloud.global.bean.param;
final enum class PARAM$111 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$111(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$111(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p6)
    {
        if (!this.isLocal(p6)) {
            boolean v0_4 = p6.getCurrentInverter();
            new com.lux.luxcloud.global.bean.inverter.Model(v0_4.getModel().longValue()).getMeasurement();
            if (!v0_4.isTrip12K()) {
                if ((!v0_4.isType6Series()) || (v0_4.isAllInOne())) {
                    if ((!v0_4.isSna3_6K_eu()) && ((!v0_4.isGen3()) && (!v0_4.isGen3Pro()))) {
                        if ((!v0_4.isAcCharger()) && (!v0_4.isHybird())) {
                            return 0;
                        } else {
                            if ((p6.isGigabiz1User()) && (this.isViewer(p6))) {
                                return 0;
                            } else {
                                return 1;
                            }
                        }
                    } else {
                        if ((!this.isAdmin(p6)) && (!this.isMAINTAIN(p6))) {
                            return 0;
                        } else {
                            return 1;
                        }
                    }
                } else {
                    return 1;
                }
            } else {
                if (((!"GAAA".equals(v0_4.getStandard())) && (!"GAaA".equals(v0_4.getStandard()))) || ((v0_4.getSlaveVersionValue() >= 13) || (v0_4.getSlaveVersionValue() >= 13))) {
                    return 1;
                } else {
                    return 0;
                }
            }
        } else {
            return 0;
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        if (!p1.getCurrentInverter().isTrip12K()) {
            return 2131886808;
        } else {
            return 2131886809;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887354;
    }

    public int getStartRegister()
    {
        return 119;
    }
}
