package com.lux.luxcloud.global.bean.param;
final enum class PARAM$221 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$221(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$221(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p8)
    {
        boolean v8_2;
        boolean v0_0 = p8.getCurrentInverter();
        boolean v1_4 = com.lux.luxcloud.global.GlobalInfo.getInstance().getCurrentClusterGroup();
        if ((!p8.isEnergy100User()) || ((!"firstCluster".equals(v1_4)) || ((v0_0.getDtcValue() != 0) && ((!v0_0.isHybird()) && (!v0_0.isSnaSeries()))))) {
            if (!v0_0.isMega24K()) {
                if ((!v0_0.isType6Series()) && ((!v0_0.isGen3Series()) && (!v0_0.isMidBoxWithOutEQB()))) {
                    if (!v0_0.isSnaSeriesOrGeta()) {
                        return 0;
                    } else {
                        if (!v0_0.isAllInOne()) {
                            if (!this.isAdmin(p8)) {
                                if (!"solarcom".equals(p8.getUsername())) {
                                    if (!v0_0.isSna12K()) {
                                        if ((!v0_0.isOffGridHardV11()) && (!v0_0.isGeta())) {
                                            return 0;
                                        } else {
                                            if ((this.isViewer(p8)) && ((!"firstCluster".equals(v1_4)) || ((!p8.isEnergy100User()) || (!this.isViewer(p8))))) {
                                                return 0;
                                            } else {
                                                return 1;
                                            }
                                        }
                                    } else {
                                        if ((this.isViewer(p8)) && ((!this.isEg4(p8)) && ((!"firstCluster".equals(v1_4)) || ((!p8.isEnergy100User()) || (!this.isViewer(p8)))))) {
                                            return 0;
                                        } else {
                                            return 1;
                                        }
                                    }
                                } else {
                                    return 1;
                                }
                            } else {
                                return 1;
                            }
                        } else {
                            return 0;
                        }
                    }
                } else {
                    if (!v0_0.isFlexBoss100()) {
                        if (v0_0.getMachineType() == 1) {
                            return 0;
                        } else {
                            return 1;
                        }
                    } else {
                        return 1;
                    }
                }
            } else {
                v8_2 = this.isViewer(p8);
            }
        } else {
            if ((v0_0.getMachineType() != 1) || ((v0_0.isFlexSeries()) || ((v0_0.isGen2_7_14K()) || (v0_0.isGenUs13_16K())))) {
                v8_2 = this.isViewer(p8);
            } else {
                return 0;
            }
        }
        return (v8_2 ^ 1);
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887731;
    }
}
