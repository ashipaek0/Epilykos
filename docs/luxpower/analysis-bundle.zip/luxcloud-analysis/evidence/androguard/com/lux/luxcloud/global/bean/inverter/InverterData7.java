package com.lux.luxcloud.global.bean.inverter;
public class InverterData7 {
    private int tokenSetResult;

    public InverterData7()
    {
        return;
    }

    public int getTokenSetResult()
    {
        return this.tokenSetResult;
    }

    public void setTokenSetResult(int p1)
    {
        this.tokenSetResult = p1;
        return;
    }
}
