package com.lux.luxcloud.global.bean.param;
final enum class BattChgPARAM$26 extends com.lux.luxcloud.global.bean.param.BattChgPARAM {

    private BattChgPARAM$26(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic BattChgPARAM$26(String p1, int p2, com.lux.luxcloud.global.bean.param.BattChgPARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkEnabled(String p2)
    {
        return "VOLT".equals(p2);
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p8)
    {
        com.lux.luxcloud.global.bean.inverter.Inverter v0 = p8.getCurrentInverter();
        int v1 = v0.getSlaveVersionValue();
        int v2 = v0.getFwVersionValue();
        String v3 = v0.getStandard();
        if (((!v0.isFlexSeries()) && ((!v0.isGen3Series()) && ((!v0.isMega24K()) && (v0.getDeviceTypeValue() != 10)))) && (((!v0.isType6Series()) && ((!v0.isMidBox()) && ((v0.getDeviceTypeValue() != 8) || (this.isViewer(p8))))) || (((!"EAAB".equals(v3)) && ((!"eAAB".equals(v3)) && ((!"FAAB".equals(v3)) && (!"fAAB".equals(v3))))) || ((v1 < 24) || (v2 < 24))))) {
            if ((!v0.isSnaSeriesOrGeta()) || (v0.isEQB())) {
                return 0;
            } else {
                return 1;
            }
        } else {
            return 1;
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return 2131886807;
    }

    public Object getPlatformSpecificData(com.lux.luxcloud.global.UserData p7)
    {
        com.lux.luxcloud.global.bean.inverter.Inverter v0 = p7.getCurrentInverter();
        if (!com.lux.luxcloud.global.bean.user.PLATFORM.LUX_POWER.equals(p7.getPlatform())) {
            if (!com.lux.luxcloud.global.bean.user.PLATFORM.EG4.equals(p7.getPlatform())) {
                return 0;
            } else {
                if (!v0.isTrip12K()) {
                    return this.createInputBox("59.5", "40");
                } else {
                    return this.createInputBox("800", "100");
                }
            }
        } else {
            if (!v0.isTrip12K()) {
                return this.createInputBox("59.5", "40");
            } else {
                return this.createInputBox("800", "100");
            }
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887339;
    }

    public int getStartRegister()
    {
        return 194;
    }
}
