package com.lux.luxcloud.global.bean.param;
public abstract enum class HOLD_PARAM extends java.lang.Enum {
    private static final synthetic com.lux.luxcloud.global.bean.param.HOLD_PARAM[] $VALUES;
    public static final enum com.lux.luxcloud.global.bean.param.HOLD_PARAM HOLD_TOKEN_CONFIG;

    private static synthetic com.lux.luxcloud.global.bean.param.HOLD_PARAM[] $values()
    {
        return new com.lux.luxcloud.global.bean.param.HOLD_PARAM[] {com.lux.luxcloud.global.bean.param.HOLD_PARAM.HOLD_TOKEN_CONFIG});
    }

    static HOLD_PARAM()
    {
        com.lux.luxcloud.global.bean.param.HOLD_PARAM.HOLD_TOKEN_CONFIG = new com.lux.luxcloud.global.bean.param.HOLD_PARAM$1("HOLD_TOKEN_CONFIG", 0, 0);
        com.lux.luxcloud.global.bean.param.HOLD_PARAM.$VALUES = com.lux.luxcloud.global.bean.param.HOLD_PARAM.$values();
        return;
    }

    private HOLD_PARAM(String p1, int p2)
    {
        super(p1, p2);
        return;
    }

    synthetic HOLD_PARAM(String p1, int p2, com.lux.luxcloud.global.bean.param.HOLD_PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public static com.lux.luxcloud.global.bean.param.HOLD_PARAM valueOf(String p1)
    {
        return ((com.lux.luxcloud.global.bean.param.HOLD_PARAM) Enum.valueOf(com.lux.luxcloud.global.bean.param.HOLD_PARAM, p1));
    }

    public static com.lux.luxcloud.global.bean.param.HOLD_PARAM[] values()
    {
        return ((com.lux.luxcloud.global.bean.param.HOLD_PARAM[]) com.lux.luxcloud.global.bean.param.HOLD_PARAM.$VALUES.clone());
    }

    public int getRegisterCount()
    {
        return 1;
    }

    public abstract int getStartRegister();

    public boolean isWritable()
    {
        return 1;
    }
}
