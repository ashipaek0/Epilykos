package com.lux.luxcloud.global.bean.param;
final enum class PARAM$76 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$76(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$76(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p1)
    {
        return 1;
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return 2131886767;
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p2)
    {
        if ((!p2.isMidBox()) && (!p2.isType6Series())) {
            return 2131887410;
        } else {
            return 2131887412;
        }
    }

    public int getStartRegister()
    {
        return 83;
    }
}
