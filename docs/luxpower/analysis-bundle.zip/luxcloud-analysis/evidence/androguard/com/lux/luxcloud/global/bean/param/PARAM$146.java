package com.lux.luxcloud.global.bean.param;
final enum class PARAM$146 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$146(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$146(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p5)
    {
        boolean v0_0 = p5.getCurrentInverter();
        if (!v0_0.isAllInOne()) {
            if (((!v0_0.isGen3Series()) && ((!v0_0.isType6Series()) || (v0_0.isAllInOne()))) && (!v0_0.isFlexSeries())) {
                if (!v0_0.isSnaSeriesOrGeta()) {
                    if (!v0_0.isMidBoxWithOutEQB()) {
                        if ((!v0_0.isHybird()) && (!v0_0.isAcCharger())) {
                            return 0;
                        } else {
                            if ((this.isViewer(p5)) && (!this.isEg4(p5))) {
                                return 0;
                            }
                        }
                    } else {
                        return 1;
                    }
                } else {
                    return 1;
                }
            }
            return 1;
        } else {
            return 0;
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        if (!p1.getCurrentInverter().isSnaSeriesOrGeta()) {
            return 2131886768;
        } else {
            return 2131886849;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        if (!p1.isSnaSeriesOrGeta()) {
            return 2131887417;
        } else {
            return 2131887525;
        }
    }

    public int getStartRegister()
    {
        return 177;
    }
}
