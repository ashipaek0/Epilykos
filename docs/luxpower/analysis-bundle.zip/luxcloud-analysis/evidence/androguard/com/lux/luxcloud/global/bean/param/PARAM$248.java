package com.lux.luxcloud.global.bean.param;
final enum class PARAM$248 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$248(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$248(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p5)
    {
        int v0_0 = p5.getCurrentInverter();
        new com.lux.luxcloud.global.bean.inverter.Model(v0_0.getModel().longValue()).getMeasurement();
        if ((!v0_0.isAcCharger()) && ((!v0_0.isHybird()) && ((!v0_0.isType6Series()) && (!v0_0.isGen3Series())))) {
            if ((!v0_0.isSna3_6K_eu()) && ((!v0_0.isGen3()) && (!v0_0.isGen3Pro()))) {
                if ((!v0_0.isSnaSeriesOrGeta()) || (this.isViewer(p5))) {
                    return 0;
                } else {
                    if ((v0_0.getSubDeviceTypeValue() != 131) && (v0_0.getHardwareVersion() < 11)) {
                        return 0;
                    } else {
                        return 1;
                    }
                }
            } else {
                if ((!this.isAdmin(p5)) && (!this.isMAINTAIN(p5))) {
                    return 0;
                } else {
                    return 1;
                }
            }
        } else {
            return (this.isViewer(p5) ^ 1);
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        p1.getCurrentInverter();
        return 2131886759;
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887100;
    }
}
