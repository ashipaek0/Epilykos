package com.lux.luxcloud.global.bean.param;
final enum class PARAM$105 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$105(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$105(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p5)
    {
        boolean v0_0 = p5.getCurrentInverter();
        if ((!v0_0.isType6Series()) || (v0_0.isAllInOne())) {
            if ((!v0_0.isSnaSeriesOrGeta()) && (!v0_0.isGen3Series())) {
                if ((!v0_0.isHybird()) && (!v0_0.isAcCharger())) {
                    return 0;
                } else {
                    return (this.isViewer(p5) ^ 1);
                }
            } else {
                if ((this.isViewer(p5)) && (!this.isEg4(p5))) {
                    return 0;
                } else {
                    return 1;
                }
            }
        } else {
            return 1;
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return 2131886635;
    }

    public Object getPlatformSpecificData(com.lux.luxcloud.global.UserData p14, android.content.Context p15)
    {
        int v0_0 = p14.getCurrentInverter();
        if (v0_0 != 0) {
            int v2_1;
            java.util.LinkedHashMap v1_1 = new java.util.LinkedHashMap();
            int v2_2 = p14.getClusterId();
            if ((v2_2 != 4) && (v2_2 != 100)) {
                v2_1 = 0;
            } else {
                v2_1 = 1;
            }
            v1_1.put("-1", p15.getString(2131887062));
            if ((!v0_0.isGeta()) && (!v0_0.isSnaSeries())) {
                if ((!v0_0.isType6Series()) && (!v0_0.isFlexSeries())) {
                    if ((v0_0.isHybird()) || (v0_0.isAcCharger())) {
                        this.addPlainOption(v1_1, "0", 2131887342, p15);
                        if (v2_1 == 0) {
                            this.addPlainOption(v1_1, "1", 2131887343, p15);
                            this.addPlainOption(v1_1, "2", 2131887344, p15);
                            this.addPlainOption(v1_1, "3", 2131887345, p15);
                        } else {
                            this.addPlainOption(v1_1, "1", 2131887350, p15);
                            this.addPlainOption(v1_1, "2", 2131887351, p15);
                            this.addPlainOption(v1_1, "3", 2131887352, p15);
                        }
                    }
                } else {
                    if (!this.isEg4(p14)) {
                        this.addPlainOption(v1_1, "1", 2131887343, p15);
                        this.addPlainOption(v1_1, "2", 2131887344, p15);
                        this.addPlainOption(v1_1, "3", 2131887345, p15);
                    } else {
                        this.addPlainOption(v1_1, "1", 2131887346, p15);
                        this.addPlainOption(v1_1, "2", 2131887347, p15);
                        this.addPlainOption(v1_1, "3", 2131887348, p15);
                    }
                }
            } else {
                if (v2_1 == 0) {
                    this.addPlainOption(v1_1, "1", 2131887343, p15);
                    this.addPlainOption(v1_1, "2", 2131887344, p15);
                    this.addPlainOption(v1_1, "3", 2131887345, p15);
                } else {
                    this.addPlainOption(v1_1, "1", 2131887350, p15);
                    this.addPlainOption(v1_1, "2", 2131887351, p15);
                    this.addPlainOption(v1_1, "3", 2131887352, p15);
                }
            }
            return this.createDropdownFromMap(v1_1);
        } else {
            return 0;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887714;
    }

    public int getStartRegister()
    {
        return 113;
    }
}
