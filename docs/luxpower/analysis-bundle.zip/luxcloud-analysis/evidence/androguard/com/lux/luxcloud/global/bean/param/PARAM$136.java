package com.lux.luxcloud.global.bean.param;
final enum class PARAM$136 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$136(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$136(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p3)
    {
        int v3_1 = p3.getCurrentInverter();
        if ((!v3_1.isType6Series()) || (v3_1.isAllInOne())) {
            if (!v3_1.isSnaSeries()) {
                return 0;
            } else {
                return 1;
            }
        } else {
            return 1;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887286;
    }

    public int getStartRegister()
    {
        return 161;
    }
}
