package com.lux.luxcloud.global.bean.param;
final enum class PARAM$319 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$319(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$319(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p2)
    {
        boolean v2_1 = p2.getCurrentInverter();
        if (!v2_1.isEQB()) {
            return v2_1.isMidBox();
        } else {
            return 0;
        }
    }

    public Object getPlatformSpecificData(com.lux.luxcloud.global.UserData p3, android.content.Context p4)
    {
        if (p3.getCurrentInverter() != null) {
            org.json.JSONObject v3_5 = new java.util.LinkedHashMap();
            v3_5.put("-1", p4.getString(2131887062));
            v3_5.put("0", p4.getString(2131887639));
            v3_5.put("1", p4.getString(2131887584));
            v3_5.put("2", p4.getString(2131887312));
            return this.createDropdownFromMap(v3_5);
        } else {
            return 0;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887736;
    }
}
