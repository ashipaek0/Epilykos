package com.lux.luxcloud.global.bean.param;
final enum class BattChgPARAM$11 extends com.lux.luxcloud.global.bean.param.BattChgPARAM {

    private BattChgPARAM$11(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic BattChgPARAM$11(String p1, int p2, com.lux.luxcloud.global.bean.param.BattChgPARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkEnabled(String p2)
    {
        return "VOLT".equals(p2);
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p1)
    {
        return p1.getCurrentInverter().isMidBox();
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131886111;
    }

    public int getStartRegister()
    {
        return 198;
    }
}
