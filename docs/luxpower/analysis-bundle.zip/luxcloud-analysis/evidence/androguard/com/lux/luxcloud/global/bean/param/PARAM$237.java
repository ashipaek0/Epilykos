package com.lux.luxcloud.global.bean.param;
final enum class PARAM$237 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$237(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$237(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p12)
    {
        boolean v0_0 = p12.getCurrentInverter();
        if (!v0_0.isAcCharger()) {
            if ((!v0_0.isSnaSeriesOrGeta()) || (!this.isEg4(p12))) {
                if (!v0_0.isSnaSeriesOrGeta()) {
                    if ((!v0_0.isType6Series()) || (v0_0.isAllInOne())) {
                        if (!v0_0.is12KUsVersion()) {
                            if (!v0_0.isMidBox()) {
                                return 0;
                            } else {
                                if (!this.isLocal(p12)) {
                                    return 1;
                                } else {
                                    return 0;
                                }
                            }
                        } else {
                            return v0_0.isAllowExport2Grid();
                        }
                    } else {
                        return 1;
                    }
                } else {
                    int v8_10;
                    int v12_6 = v0_0.getDeviceTypeValue();
                    int v1_6 = v0_0.getSubDeviceTypeValue();
                    int v4 = v0_0.getFwVersionValue();
                    int v5 = v0_0.getSlaveVersionValue();
                    int v6 = v0_0.getDtcValue();
                    int v7_1 = v0_0.getPhaseValue().intValue();
                    boolean v0_3 = v0_0.getStandard();
                    if (((v12_6 != 3) || (v1_6 != 131)) || (((!"ccaa".equals(v0_3)) || ((v5 < 15) || (v4 < 16))) && ((!"cCaa".equals(v0_3)) || ((v5 < 106) || (v4 < 112))))) {
                        v8_10 = 0;
                    } else {
                        v8_10 = 1;
                    }
                    if ((v12_6 != 11) || ((v1_6 != 1111) || ((!"ceaa".equals(v0_3)) || ((v5 < 4) || (v4 < 5))))) {
                        int v1_12 = 0;
                    } else {
                        v1_12 = 1;
                    }
                    if ((v12_6 != 11) || ((v6 != 0) || ((v7_1 != 1) || ((!"cfaa".equals(v0_3)) || ((v5 < 2) || (v4 < 2)))))) {
                        int v12_1 = 0;
                    } else {
                        v12_1 = 1;
                    }
                    if ((v8_10 == 0) && ((v1_12 == 0) && (v12_1 == 0))) {
                        return 0;
                    } else {
                        return 1;
                    }
                }
            } else {
                return v0_0.isAllowExport2Grid();
            }
        } else {
            if ((!v0_0.isAllowExport2Grid()) || (!p12.isGigabiz1User())) {
                return 0;
            } else {
                return 1;
            }
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        if (!p1.getCurrentInverter().isSnaSeriesOrGeta()) {
            return 2131886776;
        } else {
            return 2131886813;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        if (!p1.isSnaSeriesOrGeta()) {
            return 2131887105;
        } else {
            return 2131887103;
        }
    }
}
