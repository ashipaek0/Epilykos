package com.lux.luxcloud.global.bean.param;
final enum class PARAM$242 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$242(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$242(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p5)
    {
        boolean v0_0 = p5.getCurrentInverter();
        if (!this.isEg4(p5)) {
            if (!v0_0.isSnaSeries()) {
                if ((!v0_0.isAcCharger()) && (!v0_0.isHybird())) {
                    if (!v0_0.isGen3Series()) {
                        if ((!v0_0.isType6Series()) || (v0_0.isAllInOne())) {
                            if (!v0_0.isSna12K()) {
                                if ((!v0_0.isGen3_6K()) && ((!v0_0.is7_10KDevice()) && (!v0_0.isTrip12K()))) {
                                    if (!v0_0.isMidBox()) {
                                        return 0;
                                    } else {
                                        if ((!this.isAdmin(p5)) && ((!this.isMAINTAIN(p5)) && (!this.isEg4Admin(p5)))) {
                                            return 0;
                                        } else {
                                            return 1;
                                        }
                                    }
                                } else {
                                    return 1;
                                }
                            } else {
                                return 1;
                            }
                        } else {
                            return 1;
                        }
                    } else {
                        return 1;
                    }
                } else {
                    return (this.isViewer(p5) ^ 1);
                }
            } else {
                if ((this.isViewer(p5)) && (!this.isEg4(p5))) {
                    return 0;
                } else {
                    return 1;
                }
            }
        } else {
            if ((!v0_0.isType6Series()) || ((v0_0.getSlaveVersion().intValue() < 29) || (v0_0.getFwVersion().intValue() < 29))) {
                return 0;
            } else {
                return 1;
            }
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        if (!p1.getCurrentInverter().isMidBox()) {
            return 2131886753;
        } else {
            return -1;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887095;
    }
}
