package com.lux.luxcloud.global.bean.param;
final enum class PARAM$159 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$159(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$159(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p3)
    {
        int v3_1 = p3.getCurrentInverter();
        com.lux.luxcloud.global.GlobalInfo.getInstance().getCurrentClusterGroup();
        if ((!v3_1.isGen3Series()) && ((!v3_1.isType6Series()) && ((!v3_1.isGenUs13_16K()) && (!v3_1.isMidBoxWithOutEQB())))) {
            if (!v3_1.isFlexSeries()) {
                if (!v3_1.isSnaSeriesOrGeta()) {
                    if ((!v3_1.isHybird()) && (!v3_1.isAcCharger())) {
                        return 0;
                    }
                } else {
                    return 1;
                }
            } else {
                return 1;
            }
        }
        return 1;
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        if (!p1.getCurrentInverter().isSnaSeriesOrGeta()) {
            return 2131886756;
        } else {
            return 2131886783;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887524;
    }

    public int getStartRegister()
    {
        return 198;
    }
}
