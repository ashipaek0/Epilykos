package com.lux.luxcloud.connect;
public class LocalConnectManager {
    private static com.lux.luxcloud.connect.ble.BluetoothLocalConnect bluetoothLocalConnect;
    private static String dongleSn;

    public LocalConnectManager()
    {
        return;
    }

    public static com.lux.luxcloud.connect.LocalConnect getBluetoothLocalConnect()
    {
        return com.lux.luxcloud.connect.LocalConnectManager.bluetoothLocalConnect;
    }

    public static com.lux.luxcloud.connect.LocalConnect getLocalConnect(String p3)
    {
        if (!"bluetooth".equals(p3)) {
            if (!"tcp".equals(p3)) {
                throw new RuntimeException(new StringBuilder("No such localConnectType: ").append(p3).toString());
            } else {
                String v3_3 = com.lux.luxcloud.tcp.TcpManager.getInstance();
                v3_3.setDatalogSn(com.lux.luxcloud.connect.LocalConnectManager.dongleSn);
                return v3_3;
            }
        } else {
            return com.lux.luxcloud.connect.LocalConnectManager.bluetoothLocalConnect;
        }
    }

    public static void setupDongleSn(String p0)
    {
        com.lux.luxcloud.connect.LocalConnectManager.dongleSn = p0;
        return;
    }

    public static void updateBluetoothLocalConnect(com.lux.luxcloud.connect.ble.BluetoothLocalConnect p1)
    {
        com.lux.luxcloud.connect.ble.BluetoothLocalConnect v0 = com.lux.luxcloud.connect.LocalConnectManager.bluetoothLocalConnect;
        if (v0 != null) {
            v0.close();
        }
        com.lux.luxcloud.connect.LocalConnectManager.bluetoothLocalConnect = p1;
        return;
    }
}
