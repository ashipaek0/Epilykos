package com.lux.luxcloud.global.bean.param;
public final synthetic class HOLD_PARAM-IA {
}
