package com.lux.luxcloud.global.bean.param;
final enum class PARAM$47 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$47(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$47(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p5)
    {
        boolean v0_0 = p5.getCurrentInverter();
        if (!v0_0.isHybird()) {
            if ((!v0_0.isType6Series()) && ((!v0_0.isGen3Series()) && (!v0_0.isMidBox()))) {
                if (!v0_0.isAcCharger()) {
                    return 0;
                } else {
                    return 1;
                }
            } else {
                if ((p5.isGigabiz1User()) && (this.isViewer(p5))) {
                    return 0;
                } else {
                    return 1;
                }
            }
        } else {
            return 1;
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        if (!p1.getCurrentInverter().isHybird()) {
            return 2131887608;
        } else {
            return -1;
        }
    }

    public Object getPlatformSpecificData(com.lux.luxcloud.global.UserData p5, android.content.Context p6)
    {
        p6 = p5.getCurrentInverter();
        if (!com.lux.luxcloud.global.bean.user.PLATFORM.LUX_POWER.equals(p5.getPlatform())) {
            if (!com.lux.luxcloud.global.bean.user.PLATFORM.EG4.equals(p5.getPlatform())) {
                return 0;
            } else {
                if ((!p6.isType6()) && (!p6.isMidBox())) {
                    return this.createInputBox("100", "0");
                } else {
                    return this.createInputBox("25.5", "0");
                }
            }
        } else {
            if ((!p6.isType6()) && (!p6.isMidBox())) {
                return this.createInputBox("100", "0");
            } else {
                return this.createInputBox("25.5", "0");
            }
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p2)
    {
        if ((!p2.isType6Series()) && (!p2.isMidBox())) {
            return 2131887291;
        } else {
            return 2131887292;
        }
    }

    public int getStartRegister()
    {
        return 66;
    }
}
