package com.lux.luxcloud.global.bean.param;
final enum class PARAM$257 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$257(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$257(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p9)
    {
        boolean v0_0 = p9.getCurrentInverter();
        boolean v1_0 = v0_0.getStandard();
        int v2 = v0_0.getSlaveVersionValue();
        int v3 = v0_0.getFwVersionValue();
        com.lux.luxcloud.global.GlobalInfo.getInstance().getCurrentClusterGroup();
        if (!v0_0.isAllInOne()) {
            if (!v0_0.isSnaSeries()) {
                if (((!v0_0.isFlexSeries()) && ((!v0_0.isGen2_7_14K()) && ((!v0_0.isGen3Series()) && ((!v0_0.isMega24K()) && (v0_0.getDeviceTypeValue() != 10))))) && (((!v0_0.isType6Series()) && ((!v0_0.isMidBox()) && ((v0_0.getDeviceTypeValue() != 8) || (this.isViewer(p9))))) || (((!"EAAB".equals(v1_0)) && ((!"eAAB".equals(v1_0)) && ((!"FAAB".equals(v1_0)) && (!"fAAB".equals(v1_0))))) || ((v2 < 24) || (v3 < 24))))) {
                    if ((!v0_0.isHybird()) && (!v0_0.isAcCharger())) {
                        return 0;
                    } else {
                        if ((this.isViewer(p9)) && (!this.isEg4(p9))) {
                            return 0;
                        } else {
                            return 1;
                        }
                    }
                } else {
                    if ((this.isViewer(p9)) && ((!this.isEg4(p9)) && ((!p9.isEnergy100User()) || (!this.isViewer(p9))))) {
                        return 0;
                    } else {
                        return 1;
                    }
                }
            } else {
                if ((this.isViewer(p9)) && (!this.isEg4(p9))) {
                    return 0;
                } else {
                    return 1;
                }
            }
        } else {
            return 0;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131886290;
    }
}
