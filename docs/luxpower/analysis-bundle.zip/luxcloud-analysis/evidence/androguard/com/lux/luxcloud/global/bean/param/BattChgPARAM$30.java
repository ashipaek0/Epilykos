package com.lux.luxcloud.global.bean.param;
final enum class BattChgPARAM$30 extends com.lux.luxcloud.global.bean.param.BattChgPARAM {

    private BattChgPARAM$30(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic BattChgPARAM$30(String p1, int p2, com.lux.luxcloud.global.bean.param.BattChgPARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkEnabled(String p2)
    {
        return "SOC".equals(p2);
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p2)
    {
        int v2_1 = p2.getCurrentInverter();
        if ((!v2_1.isType6Series()) && ((!v2_1.isMidBox()) && ((!v2_1.isAllInOne()) && ((!v2_1.isHybird()) && ((!v2_1.isAcCharger()) && (!v2_1.isSnaSeriesOrGeta())))))) {
            return 0;
        } else {
            return 1;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p2)
    {
        if ((!p2.isMidBox()) && ((!p2.isType6Series()) && (!p2.isSnaSeriesOrGeta()))) {
            return 2131887397;
        } else {
            return 2131887398;
        }
    }

    public int getStartRegister()
    {
        return 75;
    }
}
