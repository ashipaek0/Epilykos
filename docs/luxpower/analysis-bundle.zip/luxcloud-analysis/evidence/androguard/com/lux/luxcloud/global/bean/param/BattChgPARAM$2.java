package com.lux.luxcloud.global.bean.param;
final enum class BattChgPARAM$2 extends com.lux.luxcloud.global.bean.param.BattChgPARAM {

    private BattChgPARAM$2(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic BattChgPARAM$2(String p1, int p2, com.lux.luxcloud.global.bean.param.BattChgPARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkEnabled(String p2)
    {
        return "VOLT".equals(p2);
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p7)
    {
        boolean v0_0 = p7.getCurrentInverter();
        String v1_1 = com.lux.luxcloud.global.GlobalInfo.getInstance().getCurrentClusterGroup();
        if (((!p7.isEnergy100User()) || ((v0_0.getDtcValue() != 0) || ((!v0_0.isSnaSeriesOrGeta()) && (!v0_0.isHybird())))) || (!"firstCluster".equals(v1_1))) {
            p7.getRole();
            if (!v0_0.isGen3Series()) {
                if ((!v0_0.isType6Series()) || (v0_0.isAllInOne())) {
                    if (!v0_0.isSnaSeriesOrGeta()) {
                        return 0;
                    } else {
                        if (!v0_0.isAllInOne()) {
                            if ((!v0_0.isSna12K()) || ((!v0_0.isOffGridHardV11()) && (!v0_0.isGeta()))) {
                                if ((!v0_0.isOffGridHardV11()) && (!v0_0.isGeta())) {
                                    return 0;
                                } else {
                                    if ((this.isViewer(p7)) && ((!this.isEg4(p7)) && ((!"firstCluster".equals(v1_1)) || ((!p7.isEnergy100User()) || (!this.isViewer(p7)))))) {
                                        return 0;
                                    } else {
                                        return 1;
                                    }
                                }
                            } else {
                                if ((this.isViewer(p7)) && ((!this.isEg4(p7)) && ((!"firstCluster".equals(v1_1)) || ((!p7.isEnergy100User()) || (!this.isViewer(p7)))))) {
                                    return 0;
                                } else {
                                    return 1;
                                }
                            }
                        } else {
                            return 0;
                        }
                    }
                } else {
                    return 1;
                }
            } else {
                return 1;
            }
        } else {
            if ((v0_0.getMachineType() == 1) || ((v0_0.isMega24K()) || (v0_0.isFlexBoss100()))) {
                return 1;
            } else {
                return 0;
            }
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return 2131886800;
    }

    public Object getPlatformSpecificData(com.lux.luxcloud.global.UserData p7)
    {
        com.lux.luxcloud.global.bean.inverter.Inverter v0 = p7.getCurrentInverter();
        if (!com.lux.luxcloud.global.bean.user.PLATFORM.LUX_POWER.equals(p7.getPlatform())) {
            if (!com.lux.luxcloud.global.bean.user.PLATFORM.EG4.equals(p7.getPlatform())) {
                return 0;
            } else {
                if (!v0.isTrip12K()) {
                    return this.createInputBox("59.5", "40");
                } else {
                    return this.createInputBox("800", "100");
                }
            }
        } else {
            if (!v0.isTrip12K()) {
                return this.createInputBox("59.5", "40");
            } else {
                return this.createInputBox("800", "100");
            }
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887316;
    }

    public int getStartRegister()
    {
        return 222;
    }
}
