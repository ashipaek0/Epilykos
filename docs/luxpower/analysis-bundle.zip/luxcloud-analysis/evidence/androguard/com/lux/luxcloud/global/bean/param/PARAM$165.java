package com.lux.luxcloud.global.bean.param;
final enum class PARAM$165 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$165(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$165(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p2)
    {
        if ((!p2.getCurrentInverter().isTrip12K()) || (com.lux.luxcloud.global.bean.user.ROLE.VIEWER.equals(p2.getRole()))) {
            return 0;
        } else {
            return 1;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887414;
    }
}
