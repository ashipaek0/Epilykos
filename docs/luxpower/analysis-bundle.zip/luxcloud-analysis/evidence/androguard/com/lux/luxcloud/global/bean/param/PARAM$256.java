package com.lux.luxcloud.global.bean.param;
final enum class PARAM$256 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$256(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$256(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p5)
    {
        com.lux.luxcloud.global.bean.user.ROLE v0_0 = p5.getCurrentInverter();
        if (((!this.isEg4(p5)) || ((!v0_0.isType6Series()) && (!v0_0.isGen3Series()))) || (v0_0.getFwVersion().intValue() < 30)) {
            if ((!v0_0.isMidBox()) || (v0_0.getSlaveVersionValue() < 24)) {
                return 0;
            } else {
                return 1;
            }
        } else {
            return (com.lux.luxcloud.global.bean.user.ROLE.VIEWER.equals(p5.getRole()) ^ 1);
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131886472;
    }
}
