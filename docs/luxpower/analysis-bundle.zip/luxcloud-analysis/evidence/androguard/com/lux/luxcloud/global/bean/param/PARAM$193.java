package com.lux.luxcloud.global.bean.param;
final enum class PARAM$193 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$193(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$193(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p8)
    {
        boolean v0_0 = p8.getCurrentInverter();
        int v2 = 0;
        if (!v0_0.isEQB()) {
            if ((!v0_0.isMidBox()) || (!this.isLocal(p8))) {
                if (v0_0.isSnaSeriesOrGeta()) {
                    int v1_4 = new com.lux.luxcloud.global.bean.inverter.Model(v0_0.getModel().longValue()).getRule();
                    if (((((v0_0.getDeviceType().intValue() != 3) || (v0_0.is6000XP())) && (!v0_0.isSna2_12k_EU())) || (((!this.isViewer(p8)) && (p8.getParentUserIdValue() != 68186)) || (v1_4 != 5))) && ((!this.isEg4(p8)) && (!v0_0.is_ENELEAGE_ZERO()))) {
                        if (((v0_0.is12000XP()) || (v0_0.is6000XP())) && ((v1_4 == 1) && ((!this.isAdmin(p8)) && (!this.isMAINTAIN(p8))))) {
                            v2 = 1;
                        }
                        return (v2 ^ 1);
                    }
                }
                return 0;
            } else {
                return 0;
            }
        } else {
            return 0;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131886306;
    }
}
