package com.lux.luxcloud.global.bean.param;
final enum class PARAM$392 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$392(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$392(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p5)
    {
        boolean v5_1;
        boolean v0_0 = p5.getCurrentInverter();
        if (((!v0_0.isType6Series()) || (v0_0.getUsVersionValue() != 1)) && (!v0_0.isGenUs13_16K())) {
            if ((!v0_0.isType6Series()) && (!v0_0.isGen3Series())) {
                if (!v0_0.isSnaSeriesOrGeta()) {
                    return 0;
                } else {
                    v5_1 = this.isViewer(p5);
                }
            } else {
                if ((!this.isAdmin(p5)) && (!this.isMAINTAIN(p5))) {
                    return 0;
                } else {
                    return 1;
                }
            }
        } else {
            v5_1 = this.isViewer(p5);
        }
        return (v5_1 ^ 1);
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return 2131887614;
    }

    public Object getPlatformSpecificData(com.lux.luxcloud.global.UserData p4, android.content.Context p5)
    {
        int v4_2;
        int v4_1 = p4.getCurrentInverter();
        if (!v4_1.isGeta()) {
            v4_2 = 1065353216;
        } else {
            int v4_5 = v4_1.getVoltClassValue();
            if (v4_5 != 2) {
                if (v4_5 != 3) {
                } else {
                    v4_2 = 1082130432;
                }
            } else {
                v4_2 = 1073741824;
            }
        }
        java.text.DecimalFormat v5_1 = new java.text.DecimalFormat("0.#");
        v5_1.setRoundingMode(java.math.RoundingMode.HALF_UP);
        return this.createInputBox(v5_1.format(((double) (((float) 20) / v4_2))), v5_1.format(((double) (((float) 10) / v4_2))));
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887613;
    }
}
