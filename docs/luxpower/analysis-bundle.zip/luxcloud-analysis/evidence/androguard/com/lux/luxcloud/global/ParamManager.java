package com.lux.luxcloud.global;
public class ParamManager {
    private static java.util.List phase1EnergyChartParams;
    private static java.util.List phase1LineChartParams;
    private static java.util.List phase3EnergyChartParams;
    private static java.util.List phase3LineChartParams;

    static ParamManager()
    {
        com.lux.luxcloud.global.ParamManager.phase1LineChartParams = new java.util.ArrayList();
        com.lux.luxcloud.global.ParamManager.phase3LineChartParams = new java.util.ArrayList();
        com.lux.luxcloud.global.ParamManager.phase1EnergyChartParams = new java.util.ArrayList();
        com.lux.luxcloud.global.ParamManager.phase3EnergyChartParams = new java.util.ArrayList();
        com.lux.luxcloud.global.ParamManager.phase1LineChartParams.add(new com.lux.luxcloud.global.bean.property.Property("vpv1", "Vpv1(V)"));
        com.lux.luxcloud.global.ParamManager.phase1LineChartParams.add(new com.lux.luxcloud.global.bean.property.Property("vpv2", "Vpv2(V)"));
        com.lux.luxcloud.global.ParamManager.phase1LineChartParams.add(new com.lux.luxcloud.global.bean.property.Property("ppv1", "Ppv1(W)"));
        com.lux.luxcloud.global.ParamManager.phase1LineChartParams.add(new com.lux.luxcloud.global.bean.property.Property("ppv2", "Ppv2(W)"));
        com.lux.luxcloud.global.ParamManager.phase1LineChartParams.add(new com.lux.luxcloud.global.bean.property.Property("soc", "SOC(%)"));
        com.lux.luxcloud.global.ParamManager.phase1LineChartParams.add(new com.lux.luxcloud.global.bean.property.Property("vacr", "Vacr(V)"));
        com.lux.luxcloud.global.ParamManager.phase1LineChartParams.add(new com.lux.luxcloud.global.bean.property.Property("qac", "Qac(Var)"));
        com.lux.luxcloud.global.ParamManager.phase1LineChartParams.add(new com.lux.luxcloud.global.bean.property.Property("vepsr", "Vepsr(V)"));
        com.lux.luxcloud.global.ParamManager.phase1LineChartParams.add(new com.lux.luxcloud.global.bean.property.Property("feps", "Feps(Hz)"));
        com.lux.luxcloud.global.ParamManager.phase1LineChartParams.add(new com.lux.luxcloud.global.bean.property.Property("peps", "Peps(W)"));
        com.lux.luxcloud.global.ParamManager.phase1LineChartParams.add(new com.lux.luxcloud.global.bean.property.Property("seps", "Seps(VA)"));
        com.lux.luxcloud.global.ParamManager.phase1LineChartParams.add(new com.lux.luxcloud.global.bean.property.Property("pToGrid", "pToGrid(W)"));
        com.lux.luxcloud.global.ParamManager.phase3LineChartParams.add(new com.lux.luxcloud.global.bean.property.Property("vpv1", "Vpv1(V)"));
        com.lux.luxcloud.global.ParamManager.phase3LineChartParams.add(new com.lux.luxcloud.global.bean.property.Property("vpv2", "Vpv2(V)"));
        com.lux.luxcloud.global.ParamManager.phase3LineChartParams.add(new com.lux.luxcloud.global.bean.property.Property("vpv3", "Vpv3(V)"));
        com.lux.luxcloud.global.ParamManager.phase3LineChartParams.add(new com.lux.luxcloud.global.bean.property.Property("ppv1", "Ppv1(W)"));
        com.lux.luxcloud.global.ParamManager.phase3LineChartParams.add(new com.lux.luxcloud.global.bean.property.Property("ppv2", "Ppv2(W)"));
        com.lux.luxcloud.global.ParamManager.phase3LineChartParams.add(new com.lux.luxcloud.global.bean.property.Property("ppv3", "Ppv3(W)"));
        com.lux.luxcloud.global.ParamManager.phase3LineChartParams.add(new com.lux.luxcloud.global.bean.property.Property("soc", "SOC(%)"));
        com.lux.luxcloud.global.ParamManager.phase3LineChartParams.add(new com.lux.luxcloud.global.bean.property.Property("vacr", "Vacr(V)"));
        com.lux.luxcloud.global.ParamManager.phase3LineChartParams.add(new com.lux.luxcloud.global.bean.property.Property("vacs", "Vacs(V)"));
        com.lux.luxcloud.global.ParamManager.phase3LineChartParams.add(new com.lux.luxcloud.global.bean.property.Property("vact", "Vact(V)"));
        com.lux.luxcloud.global.ParamManager.phase3LineChartParams.add(new com.lux.luxcloud.global.bean.property.Property("qac", "Qac(Var)"));
        com.lux.luxcloud.global.ParamManager.phase3LineChartParams.add(new com.lux.luxcloud.global.bean.property.Property("vepsr", "Vepsr(V)"));
        com.lux.luxcloud.global.ParamManager.phase3LineChartParams.add(new com.lux.luxcloud.global.bean.property.Property("vepss", "Vepss(V)"));
        com.lux.luxcloud.global.ParamManager.phase3LineChartParams.add(new com.lux.luxcloud.global.bean.property.Property("vepst", "Vepst(V)"));
        com.lux.luxcloud.global.ParamManager.phase3LineChartParams.add(new com.lux.luxcloud.global.bean.property.Property("feps", "Feps(Hz)"));
        com.lux.luxcloud.global.ParamManager.phase3LineChartParams.add(new com.lux.luxcloud.global.bean.property.Property("peps", "Peps(W)"));
        com.lux.luxcloud.global.ParamManager.phase3LineChartParams.add(new com.lux.luxcloud.global.bean.property.Property("seps", "Seps(VA)"));
        com.lux.luxcloud.global.ParamManager.phase3LineChartParams.add(new com.lux.luxcloud.global.bean.property.Property("pToGrid", "pToGrid(W)"));
        com.lux.luxcloud.global.ParamManager.phase1EnergyChartParams.add(new com.lux.luxcloud.global.bean.property.Property("ePv1Day", "E_pv1(kWh)"));
        com.lux.luxcloud.global.ParamManager.phase1EnergyChartParams.add(new com.lux.luxcloud.global.bean.property.Property("ePv2Day", "E_pv2(kWh)"));
        com.lux.luxcloud.global.ParamManager.phase1EnergyChartParams.add(new com.lux.luxcloud.global.bean.property.Property("eInvDay", "E_inv(kWh)"));
        com.lux.luxcloud.global.ParamManager.phase1EnergyChartParams.add(new com.lux.luxcloud.global.bean.property.Property("eRecDay", "E_rec(kWh)"));
        com.lux.luxcloud.global.ParamManager.phase1EnergyChartParams.add(new com.lux.luxcloud.global.bean.property.Property("eChgDay", "E_charge(kWh)"));
        com.lux.luxcloud.global.ParamManager.phase1EnergyChartParams.add(new com.lux.luxcloud.global.bean.property.Property("eDisChgDay", "E_discharge(kWh)"));
        com.lux.luxcloud.global.ParamManager.phase1EnergyChartParams.add(new com.lux.luxcloud.global.bean.property.Property("eEpsDay", "E_eps(kWh)"));
        com.lux.luxcloud.global.ParamManager.phase1EnergyChartParams.add(new com.lux.luxcloud.global.bean.property.Property("eToGridDay", "EnergyToGrid(kWh)"));
        com.lux.luxcloud.global.ParamManager.phase1EnergyChartParams.add(new com.lux.luxcloud.global.bean.property.Property("eToUserDay", "EnergyToUser(kWh)"));
        com.lux.luxcloud.global.ParamManager.phase3EnergyChartParams.add(new com.lux.luxcloud.global.bean.property.Property("ePv1Day", "E_pv1(kWh)"));
        com.lux.luxcloud.global.ParamManager.phase3EnergyChartParams.add(new com.lux.luxcloud.global.bean.property.Property("ePv2Day", "E_pv2(kWh)"));
        com.lux.luxcloud.global.ParamManager.phase3EnergyChartParams.add(new com.lux.luxcloud.global.bean.property.Property("ePv3Day", "E_pv3(kWh)"));
        com.lux.luxcloud.global.ParamManager.phase3EnergyChartParams.add(new com.lux.luxcloud.global.bean.property.Property("eInvDay", "E_inv(kWh)"));
        com.lux.luxcloud.global.ParamManager.phase3EnergyChartParams.add(new com.lux.luxcloud.global.bean.property.Property("eRecDay", "E_rec(kWh)"));
        com.lux.luxcloud.global.ParamManager.phase3EnergyChartParams.add(new com.lux.luxcloud.global.bean.property.Property("eChgDay", "E_charge(kWh)"));
        com.lux.luxcloud.global.ParamManager.phase3EnergyChartParams.add(new com.lux.luxcloud.global.bean.property.Property("eDisChgDay", "E_discharge(kWh)"));
        com.lux.luxcloud.global.ParamManager.phase3EnergyChartParams.add(new com.lux.luxcloud.global.bean.property.Property("eEpsDay", "E_eps(kWh)"));
        com.lux.luxcloud.global.ParamManager.phase3EnergyChartParams.add(new com.lux.luxcloud.global.bean.property.Property("eToGridDay", "EnergyToGrid(kWh)"));
        com.lux.luxcloud.global.ParamManager.phase3EnergyChartParams.add(new com.lux.luxcloud.global.bean.property.Property("eToUserDay", "EnergyToUser(kWh)"));
        return;
    }

    public ParamManager()
    {
        return;
    }

    public static java.util.List getEnergyChartParams(int p1)
    {
        if (p1 != 1) {
            return com.lux.luxcloud.global.ParamManager.phase3EnergyChartParams;
        } else {
            return com.lux.luxcloud.global.ParamManager.phase1EnergyChartParams;
        }
    }

    public static java.util.List getLineChartParams(int p1)
    {
        if (p1 != 1) {
            return com.lux.luxcloud.global.ParamManager.phase3LineChartParams;
        } else {
            return com.lux.luxcloud.global.ParamManager.phase1LineChartParams;
        }
    }
}
