package com.lux.luxcloud.connect.ble;
public interface BleManager$ScanFinishCallback {

    public abstract void onFinish();
}
