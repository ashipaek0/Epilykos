package com.lux.luxcloud.global.bean.param;
final enum class PARAM$252 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$252(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$252(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p5)
    {
        if (!this.isLocal(p5)) {
            boolean v5_5;
            int v0_1 = p5.getCurrentInverter();
            if ((!v0_1.isHybird()) && (!v0_1.isAcCharger())) {
                if ((!v0_1.isSna3_6K_eu()) && (!v0_1.isSnaSeries())) {
                    if (!v0_1.isMidBox()) {
                        if ((!v0_1.isGen3_6K()) && (!v0_1.is7_10KDevice())) {
                            if ((!v0_1.isAcCharger()) && ((!v0_1.isType6Series()) && ((!v0_1.isHybird()) && (!v0_1.isGen3Series())))) {
                                return 0;
                            } else {
                                return 1;
                            }
                        } else {
                            v5_5 = this.isViewer(p5);
                        }
                    } else {
                        if (((this.isViewer(p5)) && (!this.isEg4(p5))) || (v0_1.getSlaveVersionValue() < 24)) {
                            return 0;
                        } else {
                            return 1;
                        }
                    }
                } else {
                    if ((!this.isEg4Admin(p5)) && ((!this.isAdmin(p5)) && (!this.isMAINTAIN(p5)))) {
                        return 0;
                    } else {
                        return 1;
                    }
                }
            } else {
                v5_5 = this.isViewer(p5);
            }
            return (v5_5 ^ 1);
        } else {
            return 0;
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return 2131886784;
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131886469;
    }
}
