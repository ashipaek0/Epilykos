package com.lux.luxcloud.global.bean.param;
final enum class PARAM$249 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$249(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$249(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p3)
    {
        boolean v0_0 = p3.getCurrentInverter();
        if ((!v0_0.isAcCharger()) && (!v0_0.isHybird())) {
            return 0;
        } else {
            return (this.isViewer(p3) ^ 1);
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return 2131886715;
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887136;
    }
}
