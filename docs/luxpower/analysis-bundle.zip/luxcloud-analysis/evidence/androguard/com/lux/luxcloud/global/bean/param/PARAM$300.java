package com.lux.luxcloud.global.bean.param;
final enum class PARAM$300 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$300(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$300(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p4)
    {
        int v0_0 = p4.getCurrentInverter();
        if (!v0_0.isSnaSeriesOrGeta()) {
            return 0;
        } else {
            if ((!this.isAdmin(p4)) && ((!this.isMAINTAIN(p4)) && ((!p4.getRole().getOwnerLevelCheck()) && (v0_0.getDeviceTypeValue() != 11)))) {
                return 0;
            } else {
                return 1;
            }
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131886272;
    }
}
