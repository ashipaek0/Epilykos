package com.lux.luxcloud.global.bean.param;
final enum class PARAM$399 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$399(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$399(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p8)
    {
        int v0_0 = p8.getRole();
        com.lux.luxcloud.global.bean.user.ROLE v1_3 = p8.getCurrentInverter();
        String v2 = v1_3.getStandard();
        int v3 = v1_3.getSlaveVersionValue();
        boolean v4_0 = com.lux.luxcloud.global.GlobalInfo.getInstance().getCurrentClusterGroup();
        if (((!p8.isEnergy100User()) || ((v1_3.getDtcValue() != 0) || ((!v1_3.isSnaSeriesOrGeta()) && (!v1_3.isHybird())))) || (!"firstCluster".equals(v4_0))) {
            if ((!v1_3.isType6Series()) && (!v1_3.isGen3Series())) {
                if ((!v1_3.isSnaSeriesOrGeta()) || ((((!v1_3.isSunKing()) || ((!"cbba".equals(v2)) || (v3 < 10))) && ((!v1_3.isGeta()) && ((v1_3.getDeviceTypeValue() != 3) || (((!"cbaa".equals(v2)) || (v3 < 36)) && (((!"cBaa".equals(v2)) || (v3 < 141)) && (((!"cBAA".equals(v2)) || (v3 < 141)) && ((v1_3.getDtcValue() != 1) || ((!"ccaa".equals(v2)) || (v3 < 18))))))))) && ((v1_3.getDeviceTypeValue() != 11) || (((v1_3.getDtcValue() != 1) || ((!"ceaa".equals(v2)) || (v3 < 6))) && ((!"cfaa".equals(v2)) || (v3 < 6)))))) {
                    return 0;
                } else {
                    return 1;
                }
            } else {
                if ((!this.isEg4Admin(p8)) && ((!this.isAdmin(p8)) && ((!com.lux.luxcloud.global.bean.user.ROLE.OWNER.equals(v0_0)) && ((!this.isMAINTAIN(p8)) && ((!p8.isEnergy100User()) || (!this.isViewer(p8))))))) {
                    return 0;
                } else {
                    return 1;
                }
            }
        } else {
            return 1;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887356;
    }
}
