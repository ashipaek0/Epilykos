package com.lux.luxcloud.connect.listener;
public interface LoadListener {

    public abstract void onError(String p0);

    public abstract void onSuccess(java.util.List p0);
}
