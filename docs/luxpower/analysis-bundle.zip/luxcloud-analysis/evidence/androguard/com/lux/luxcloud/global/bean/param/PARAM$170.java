package com.lux.luxcloud.global.bean.param;
final enum class PARAM$170 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$170(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$170(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p3)
    {
        int v3_1 = p3.getCurrentInverter();
        if (((!v3_1.isType6Series()) && (!v3_1.isGen3Series())) || (v3_1.isAllInOne())) {
            if (!v3_1.isMidBox()) {
                return 0;
            } else {
                return 1;
            }
        } else {
            return 1;
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return 2131886771;
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887470;
    }

    public int getStartRegister()
    {
        return 206;
    }
}
