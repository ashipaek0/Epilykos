package com.lux.luxcloud.global.bean.param;
final enum class PARAM$219 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$219(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$219(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p14)
    {
        boolean v14_4;
        p14.getRole();
        boolean v0_3 = p14.getCurrentInverter();
        int v1_21 = com.lux.luxcloud.global.GlobalInfo.getInstance().getCurrentClusterGroup();
        if ((!p14.isEnergy100User()) || ((!"firstCluster".equals(v1_21)) || ((v0_3.getDtcValue() != 0) && ((!v0_3.isHybird()) && ((!v0_3.isSnaSeriesOrGeta()) && ((!v0_3.isSna2_12k_EU()) && (!v0_3.isSna2_12k_EU_lt()))))))) {
            if (!v0_3.isMega24K()) {
                if (!v0_3.isGen3Series()) {
                    if ((!v0_3.isType6Series()) && (!v0_3.isMidBoxWithOutEQB())) {
                        if (!v0_3.isSnaSeriesOrGeta()) {
                            return 0;
                        } else {
                            int v10_10;
                            int v1_20 = v0_3.getDeviceTypeValue();
                            int v2_1 = v0_3.getSubDeviceTypeValue();
                            int v5 = v0_3.getFwVersionValue();
                            int v6 = v0_3.getSlaveVersionValue();
                            int v7 = v0_3.getDtcValue();
                            int v8_1 = v0_3.getPhaseValue().intValue();
                            String v9 = v0_3.getStandard();
                            if (((v1_20 != 3) || (v2_1 != 131)) || (((!"ccaa".equals(v9)) || ((v6 < 15) || (v5 < 16))) && ((!"cCaa".equals(v9)) || ((v6 < 106) || (v5 < 112))))) {
                                v10_10 = 0;
                            } else {
                                v10_10 = 1;
                            }
                            if ((v1_20 != 11) || ((v2_1 != 1111) || ((!"ceaa".equals(v9)) || ((v6 < 4) || (v5 < 5))))) {
                                int v2_7 = 0;
                            } else {
                                v2_7 = 1;
                            }
                            if ((v1_20 != 11) || ((v7 != 0) || ((v8_1 != 1) || ((!"cfaa".equals(v9)) || ((v6 < 2) || (v5 < 2)))))) {
                                int v1_3 = 0;
                            } else {
                                v1_3 = 1;
                            }
                            if ((v10_10 == 0) && ((v2_7 == 0) && (v1_3 == 0))) {
                                if ((!v0_3.isGeta()) && (!v0_3.isOffGridHardV11())) {
                                    return 0;
                                } else {
                                    if ((this.isViewer(p14)) && (!this.isEg4(p14))) {
                                        return 0;
                                    }
                                }
                            }
                            return 1;
                        }
                    } else {
                        if ((v0_3.isFlexBoss100()) || (v0_3.getMachineType() != 1)) {
                            return 1;
                        } else {
                            return 0;
                        }
                    }
                } else {
                    return 1;
                }
            } else {
                v14_4 = this.isViewer(p14);
            }
        } else {
            if ((v0_3.getMachineType() != 1) || ((v0_3.isFlexSeries()) || ((v0_3.isGen2_7_14K()) || (v0_3.isGenUs13_16K())))) {
                v14_4 = this.isViewer(p14);
            } else {
                return 0;
            }
        }
        return (v14_4 ^ 1);
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131886121;
    }
}
