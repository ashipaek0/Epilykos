package com.lux.luxcloud.global.bean.param;
synthetic class PARAM$432 {
    static final synthetic int[] $SwitchMap$com$lux$luxcloud$global$bean$param$PARAM;

    static PARAM$432()
    {
        int[] v0_6 = new int[com.lux.luxcloud.global.bean.param.PARAM.values().length];
        com.lux.luxcloud.global.bean.param.PARAM$432.$SwitchMap$com$lux$luxcloud$global$bean$param$PARAM = v0_6;
        com.lux.luxcloud.global.bean.param.PARAM.MODEL_BIT_BATTERY_TYPE.ordinal()[int v1_11] = 1;
        com.lux.luxcloud.global.bean.param.PARAM._12K_HOLD_LEAD_CAPACITY.ordinal()[int v1_1] = 2;
        com.lux.luxcloud.global.bean.param.PARAM.HOLD_Detected_COMPOSED_PHASE.ordinal()[int v1_3] = 3;
        com.lux.luxcloud.global.bean.param.PARAM.HOLD_AFCI_SOFTWARE_VERSION.ordinal()[int v1_5] = 4;
        com.lux.luxcloud.global.bean.param.PARAM.HOLD_AFCI_ALGORITHM_VERSION.ordinal()[int v1_7] = 5;
        try {
            com.lux.luxcloud.global.bean.param.PARAM.HOLD_CT_POWER_OFFSET.ordinal()[int v1_9] = 6;
        } catch (NoSuchFieldError) {
        }
        return;
    }
}
