package com.lux.luxcloud.global.bean.param;
final enum class PARAM$181 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$181(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$181(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p7)
    {
        boolean v0_0 = p7.getCurrentInverter();
        int v1_0 = p7.getRole();
        int v2_10 = com.lux.luxcloud.global.GlobalInfo.getInstance().getCurrentClusterGroup();
        if ((!p7.isEnergy100User()) || ((!this.isViewer(p7)) || ((v0_0.getDtcValue() != 0) || (!"firstCluster".equals(v2_10))))) {
            if (((!v0_0.isType6Series()) && (!v0_0.isGen3Series())) || (v0_0.isAllInOne())) {
                if (((!v0_0.isSnaSeries()) || ((!com.lux.luxcloud.global.bean.user.ROLE.ADMIN.equals(v1_0)) && (!v1_0.getOwnerLevelCheck()))) || ((v0_0.getSubDeviceTypeValue() != 131) && (v0_0.getHardwareVersion() <= 11))) {
                    if (!v0_0.isMidBox()) {
                        return 0;
                    } else {
                        if ((this.isViewer(p7)) && (!this.isEg4(p7))) {
                            return 0;
                        } else {
                            return 1;
                        }
                    }
                } else {
                    return 1;
                }
            } else {
                return 1;
            }
        } else {
            if ((!v0_0.isSnaSeriesOrGeta()) && (!v0_0.isHybird())) {
                return 0;
            } else {
                return 1;
            }
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return 2131886797;
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887313;
    }

    public int getStartRegister()
    {
        return 221;
    }
}
