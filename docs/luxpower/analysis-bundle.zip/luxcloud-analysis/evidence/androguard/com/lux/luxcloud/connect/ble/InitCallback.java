package com.lux.luxcloud.connect.ble;
public interface InitCallback {

    public void onConnecting()
    {
        return;
    }

    public abstract void onFail(String p0);

    public abstract void onSuccess();
}
