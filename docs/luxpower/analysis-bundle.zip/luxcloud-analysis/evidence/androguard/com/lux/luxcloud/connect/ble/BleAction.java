package com.lux.luxcloud.connect.ble;
public interface BleAction {

    public abstract void bleConnectClosed();

    public abstract void bleConnected();
}
