package com.lux.luxcloud.global.bean.param;
final enum class PARAM$145 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$145(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$145(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p7)
    {
        boolean v0_0 = p7.getCurrentInverter();
        boolean v1_0 = v0_0.getSlaveVersionValue();
        boolean v2_0 = v0_0.getStandard();
        if ((!v0_0.isAcCharger()) && (!v0_0.isHybird())) {
            if ((!v0_0.isSnaSeriesOrGeta()) || ((((!v0_0.isSunKing()) || ((!"cbba".equals(v2_0)) || (v1_0 < 10))) && ((!v0_0.isGeta()) && ((v0_0.getDeviceTypeValue() != 3) || (((!"cbaa".equals(v2_0)) || (v1_0 < 36)) && (((!"cBaa".equals(v2_0)) || (v1_0 < 141)) && (((!"cBAA".equals(v2_0)) || (v1_0 < 141)) && ((v0_0.getDtcValue() != 1) || ((!"ccaa".equals(v2_0)) || (v1_0 < 18))))))))) && (((v0_0.getDeviceTypeValue() != 11) || (((v0_0.getDtcValue() != 1) || ((!"ceaa".equals(v2_0)) || (v1_0 < 6))) && ((!"cfaa".equals(v2_0)) || (v1_0 < 6)))) && (!v0_0.isSna2_12k_EU())))) {
                if (!v0_0.isSna3_6K_eu()) {
                    if (((!v0_0.isType6Series()) && (!v0_0.isGen3Series())) || (v0_0.isAllInOne())) {
                        if (!v0_0.isMidBox()) {
                            return 0;
                        } else {
                            if ((this.isViewer(p7)) && (!this.isEg4(p7))) {
                                return 0;
                            } else {
                                return 1;
                            }
                        }
                    } else {
                        if ((this.isViewer(p7)) && (!this.isEg4(p7))) {
                            return 0;
                        } else {
                            return 1;
                        }
                    }
                } else {
                    return 1;
                }
            } else {
                return 1;
            }
        } else {
            return (this.isViewer(p7) ^ 1);
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return 2131886781;
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887523;
    }

    public int getStartRegister()
    {
        return 176;
    }
}
