package com.lux.luxcloud.global.bean.param;
final enum class PARAM$188 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$188(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$188(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p4)
    {
        if (!this.isLocal(p4)) {
            boolean v4_1;
            boolean v0_2 = p4.getCurrentInverter();
            if ((!v0_2.isAcCharger()) && (!v0_2.isHybird())) {
                if ((!v0_2.isType6Series()) || (v0_2.isAllInOne())) {
                    return 0;
                } else {
                    v4_1 = this.isViewer(p4);
                }
            } else {
                v4_1 = this.isViewer(p4);
            }
            return (v4_1 ^ 1);
        } else {
            return 0;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131886605;
    }
}
