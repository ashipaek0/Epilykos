package com.lux.luxcloud.global.bean.param;
final enum class PARAM$241 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$241(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$241(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p5)
    {
        boolean v0_0 = p5.getCurrentInverter();
        boolean v1_9 = com.lux.luxcloud.global.GlobalInfo.getInstance().getCurrentClusterGroup();
        if (((!p5.isEnergy100User()) || ((v0_0.getDtcValue() != 0) || ((!v0_0.isSnaSeriesOrGeta()) && (!v0_0.isHybird())))) || (!"firstCluster".equals(v1_9))) {
            if (!v0_0.isGen3Series()) {
                if (((!v0_0.isType6Series()) || (v0_0.isAllInOne())) && ((!v0_0.isFlexSeries()) && (!v0_0.isMidBox()))) {
                    if ((!v0_0.isHybird()) && ((!v0_0.isAcCharger()) && (!v0_0.isTrip12K()))) {
                        return 0;
                    } else {
                        return (this.isViewer(p5) ^ 1);
                    }
                } else {
                    if ((this.isViewer(p5)) && (!this.isEg4(p5))) {
                        return 0;
                    } else {
                        return 1;
                    }
                }
            } else {
                return 0;
            }
        } else {
            return 1;
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return 2131886738;
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887121;
    }
}
