package com.lux.luxcloud.global.bean.param;
final enum class PARAM$118 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$118(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$118(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p4)
    {
        com.lux.luxcloud.global.bean.user.ROLE v0_0 = p4.getCurrentInverter();
        if ((!this.isEg4(p4)) || (!v0_0.isParallelGroup())) {
            if (!v0_0.isSnaSeriesOrGeta()) {
                if ((!v0_0.isAcCharger()) && ((!v0_0.isHybird()) && ((!v0_0.isGen3_6K()) && ((!v0_0.is7_10KDevice()) && (!v0_0.isType6SeriesWithoutTrip12K()))))) {
                    if (((!v0_0.isType6Series()) && (!v0_0.isGen3Series())) || (v0_0.isAllInOne())) {
                        return 0;
                    } else {
                        return 1;
                    }
                } else {
                    return 1;
                }
            } else {
                return (com.lux.luxcloud.global.bean.user.ROLE.VIEWER.equals(p4.getRole()) ^ 1);
            }
        } else {
            return 1;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887387;
    }

    public int getStartRegister()
    {
        return 144;
    }
}
