package com.lux.luxcloud.global.bean.param;
final enum class PARAM$362 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$362(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$362(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p4)
    {
        com.lux.luxcloud.global.bean.inverter.Inverter v0 = p4.getCurrentInverter();
        if ((!v0.isMidBox()) || (!this.isLocal(p4))) {
            if ((this.isViewer(p4)) || ((!v0.isType6Series()) && ((!v0.isGen3Series()) && ((!v0.isMega24K()) && ((!v0.isMidBox()) && (!v0.isFlexSeries())))))) {
                return 0;
            } else {
                return 1;
            }
        } else {
            return 0;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131886638;
    }
}
