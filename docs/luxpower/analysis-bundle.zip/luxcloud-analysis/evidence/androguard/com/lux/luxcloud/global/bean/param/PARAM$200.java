package com.lux.luxcloud.global.bean.param;
final enum class PARAM$200 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$200(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$200(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p7)
    {
        if (((278 != p7.getParentUserId().longValue()) && (400 != p7.getClusterId())) || (!this.isViewer(p7))) {
            boolean v0_3 = p7.getCurrentInverter();
            if ((!v0_3.isType6Series()) && (!v0_3.isGen3Series())) {
                if ((!v0_3.isAcCharger()) && ((!v0_3.isHybird()) && (!v0_3.isSnaSeries()))) {
                    if (!v0_3.isMidBox()) {
                        return 0;
                    } else {
                        if (!this.isLocal(p7)) {
                            if ((this.isViewer(p7)) && (!this.isEg4(p7))) {
                                return 0;
                            } else {
                                return 1;
                            }
                        } else {
                            return 0;
                        }
                    }
                } else {
                    if ((p7.isGigabiz1User()) && (this.isViewer(p7))) {
                        return 0;
                    }
                }
            }
            return 1;
        } else {
            return 0;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131886597;
    }
}
