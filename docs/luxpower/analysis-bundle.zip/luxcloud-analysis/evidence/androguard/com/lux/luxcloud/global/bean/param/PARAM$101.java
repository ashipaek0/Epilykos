package com.lux.luxcloud.global.bean.param;
final enum class PARAM$101 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$101(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$101(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p3)
    {
        boolean v0_0 = p3.getCurrentInverter();
        if ((!v0_0.isAcCharger()) && (!v0_0.isHybird())) {
            if (((!v0_0.isType6Series()) && (!v0_0.isGen3Series())) || (v0_0.isAllInOne())) {
                return 0;
            } else {
                return this.isAdmin(p3);
            }
        } else {
            return this.isAdmin(p3);
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131886177;
    }

    public int getStartRegister()
    {
        return 108;
    }
}
