package com.lux.luxcloud.global.bean.param;
final enum class PARAM$260 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$260(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$260(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p7)
    {
        p7.getRole();
        boolean v0_0 = p7.getCurrentInverter();
        if (!v0_0.isGen3Series()) {
            String v1_0 = com.lux.luxcloud.global.GlobalInfo.getInstance().getCurrentClusterGroup();
            if (((!p7.isEnergy100User()) || ((v0_0.getDtcValue() != 0) || ((!v0_0.isSnaSeriesOrGeta()) && (!v0_0.isHybird())))) || (!"firstCluster".equals(v1_0))) {
                if ((!v0_0.isType6Series()) && (!v0_0.isMega24K())) {
                    if (!v0_0.isSnaSeriesOrGeta()) {
                        return 0;
                    } else {
                        if (!v0_0.isAllInOne()) {
                            if (!v0_0.isSna12K()) {
                                if ((!v0_0.isOffGridHardV11()) && (!v0_0.isGeta())) {
                                    return 0;
                                } else {
                                    if ((this.isViewer(p7)) && ((!this.isEg4(p7)) && ((!"firstCluster".equals(v1_0)) || ((!p7.isEnergy100User()) || (!this.isViewer(p7)))))) {
                                        return 0;
                                    } else {
                                        return 1;
                                    }
                                }
                            } else {
                                if ((this.isViewer(p7)) && ((!this.isEg4(p7)) && ((!"firstCluster".equals(v1_0)) || ((!p7.isEnergy100User()) || (!this.isViewer(p7)))))) {
                                    return 0;
                                } else {
                                    return 1;
                                }
                            }
                        } else {
                            return 0;
                        }
                    }
                } else {
                    if ((v0_0.getMachineType() == 1) || ((v0_0.isMega24K()) || (v0_0.isFlexBoss100()))) {
                        return 1;
                    } else {
                        return 0;
                    }
                }
            } else {
                if ((v0_0.getMachineType() == 1) || ((v0_0.isMega24K()) || (v0_0.isFlexBoss100()))) {
                    return 1;
                } else {
                    return 0;
                }
            }
        } else {
            return 1;
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return 2131886726;
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887312;
    }
}
