package com.lux.luxcloud.connect.ble;
public interface BleScanCallback {

    public abstract void onDeviceFound(android.bluetooth.BluetoothDevice p0);

    public abstract void onScanError(String p0);

    public abstract void onScanTimeout();
}
