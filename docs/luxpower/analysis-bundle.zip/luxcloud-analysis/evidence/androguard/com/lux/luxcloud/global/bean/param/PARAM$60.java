package com.lux.luxcloud.global.bean.param;
final enum class PARAM$60 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$60(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$60(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p2)
    {
        int v2_1 = p2.getCurrentInverter();
        if ((!v2_1.isType6Series()) && ((!v2_1.isMidBox()) && ((!v2_1.isGen3Series()) && ((!v2_1.isAllInOne()) && ((!v2_1.isHybird()) && ((!v2_1.isAcCharger()) && (!v2_1.isSnaSeriesOrGeta()))))))) {
            return 0;
        } else {
            return 1;
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return 2131886629;
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p2)
    {
        if ((!p2.isMidBox()) && (!p2.isType6Series())) {
            return 2131887397;
        } else {
            return 2131887398;
        }
    }

    public int getStartRegister()
    {
        return 75;
    }
}
