package com.lux.luxcloud.global.bean.param;
final enum class PARAM$225 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$225(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$225(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p8)
    {
        long v0_0 = p8.getRole();
        boolean v1_1 = p8.getCurrentInverter();
        if (((!v1_1.isAcCharger()) && ((!v1_1.isHybird()) && (!v1_1.isMidBox()))) || ((this.isViewer(p8)) || (v0_0.getInstallerLevelCheck()))) {
            if (((!v1_1.isType6Series()) && (!v1_1.isGen3Series())) || ((v1_1.isAllInOne()) || ((com.lux.luxcloud.global.bean.user.ROLE.VIEWER.equals(v0_0)) || ((v0_0.getInstallerLevelCheck()) || (p8.getClusterId() >= 4))))) {
                return 0;
            } else {
                return 1;
            }
        } else {
            if (p8.getClusterId() >= 4) {
                return 0;
            } else {
                return 1;
            }
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887101;
    }
}
