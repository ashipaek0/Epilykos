package com.lux.luxcloud.global.bean.param;
final enum class PARAM$104 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$104(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$104(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p2)
    {
        int v2_1 = p2.getCurrentInverter();
        if ((!v2_1.isMidBox()) || (v2_1.getSlaveVersionValue() < 24)) {
            return 0;
        } else {
            return 1;
        }
    }

    public int getBit()
    {
        return 8;
    }

    public int getBitSize()
    {
        return 1;
    }

    public Object getPlatformSpecificData(com.lux.luxcloud.global.UserData p3, android.content.Context p4)
    {
        if (p3.getCurrentInverter() != null) {
            org.json.JSONObject v3_8 = new java.util.LinkedHashMap();
            v3_8.put("-1", p4.getString(2131887062));
            v3_8.put("0", "0: Master");
            v3_8.put("1", "1: Detect");
            v3_8.put("2", "2: Slave");
            String[] v1 = new String[0];
            String[] v0_4 = new String[0];
            return this.createDropdown(((String[]) v3_8.values().toArray(v0_4)), ((String[]) v3_8.keySet().toArray(v1)));
        } else {
            return 0;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887545;
    }

    public int getStartRegister()
    {
        return 2101;
    }
}
