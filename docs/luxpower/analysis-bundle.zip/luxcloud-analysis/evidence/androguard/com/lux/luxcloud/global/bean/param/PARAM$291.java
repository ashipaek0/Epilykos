package com.lux.luxcloud.global.bean.param;
final enum class PARAM$291 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$291(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$291(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p9)
    {
        com.lux.luxcloud.global.bean.inverter.Inverter v0 = p9.getCurrentInverter();
        int v1 = v0.getSlaveVersionValue();
        int v2_3 = v0.getFwVersionValue();
        String v3 = v0.getStandard();
        int v4_0 = com.lux.luxcloud.global.GlobalInfo.getInstance().getCurrentClusterGroup();
        if (((!p9.isEnergy100User()) || ((v0.getDtcValue() != 0) || ((!v0.isSnaSeriesOrGeta()) && (!v0.isHybird())))) || (!"firstCluster".equals(v4_0))) {
            if (((!v0.isFlexSeries()) && ((!v0.isGen3Series()) && ((!v0.isMega24K()) && (v0.getDeviceTypeValue() != 10)))) && (((!v0.isType6Series()) && ((!v0.isMidBox()) && ((v0.getDeviceTypeValue() != 8) || (this.isViewer(p9))))) || (((!"EAAB".equals(v3)) && ((!"eAAB".equals(v3)) && ((!"FAAB".equals(v3)) && (!"fAAB".equals(v3))))) || ((v1 < 24) || (v2_3 < 24))))) {
                if ((!v0.isSnaSeriesOrGeta()) || ((((!v0.isSunKing()) || ((!"cbba".equals(v3)) || (v1 < 10))) && ((!v0.isGeta()) && ((v0.getDeviceTypeValue() != 3) || (((!"cbaa".equals(v3)) || (v1 < 36)) && (((!"cBaa".equals(v3)) || (v1 < 141)) && (((!"cBAA".equals(v3)) || (v1 < 141)) && ((v0.getDtcValue() != 1) || ((!"ccaa".equals(v3)) || (v1 < 18))))))))) && (((v0.getDeviceTypeValue() != 11) || (((v0.getDtcValue() != 1) || ((!"ceaa".equals(v3)) || (v1 < 6))) && ((!"cfaa".equals(v3)) || (v1 < 6)))) && (!v0.isSna2_12k_EU())))) {
                    return 0;
                } else {
                    return 1;
                }
            } else {
                return 1;
            }
        } else {
            return 1;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887415;
    }
}
