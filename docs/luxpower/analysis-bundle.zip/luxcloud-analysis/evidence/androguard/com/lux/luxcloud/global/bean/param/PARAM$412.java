package com.lux.luxcloud.global.bean.param;
final enum class PARAM$412 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$412(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$412(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p6)
    {
        String v0_0 = p6.getCurrentInverter();
        int v1_4 = p6.getRole();
        int v2 = v0_0.getSlaveVersionValue();
        int v3 = v0_0.getFwVersionValue();
        if (((!v1_4.isHigherThan(com.lux.luxcloud.global.bean.user.ROLE.P_ASSISTANT_L3)) || ((this.isViewer(p6)) && (!this.isEg4(p6)))) || (((!v0_0.isFlexBoss100()) || ((!"FCCA".equals(v0_0.getStandard())) || ((v0_0.getSlaveVersionValue() < 6) || (v0_0.getFwVersionValue() < 8)))) && ((!v0_0.isType6Series()) || ((!v0_0.getStandard().endsWith("AAB")) || ((v2 < 39) || (v3 < 39)))))) {
            return 0;
        } else {
            return 1;
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return 2131887274;
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887273;
    }
}
