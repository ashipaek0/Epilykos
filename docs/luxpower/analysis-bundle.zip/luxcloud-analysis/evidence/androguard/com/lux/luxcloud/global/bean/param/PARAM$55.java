package com.lux.luxcloud.global.bean.param;
final enum class PARAM$55 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$55(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$55(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p1)
    {
        return 1;
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887289;
    }

    public int getStartRegister()
    {
        return 71;
    }
}
