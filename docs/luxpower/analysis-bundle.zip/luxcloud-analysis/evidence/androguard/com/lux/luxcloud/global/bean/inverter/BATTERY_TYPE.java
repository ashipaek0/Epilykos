package com.lux.luxcloud.global.bean.inverter;
public abstract enum class BATTERY_TYPE extends java.lang.Enum {
    private static final synthetic com.lux.luxcloud.global.bean.inverter.BATTERY_TYPE[] $VALUES;
    public static final enum com.lux.luxcloud.global.bean.inverter.BATTERY_TYPE LEAD_ACID;
    public static final enum com.lux.luxcloud.global.bean.inverter.BATTERY_TYPE LITHIUM;
    public static final enum com.lux.luxcloud.global.bean.inverter.BATTERY_TYPE NO_BATTERY;

    private static synthetic com.lux.luxcloud.global.bean.inverter.BATTERY_TYPE[] $values()
    {
        return new com.lux.luxcloud.global.bean.inverter.BATTERY_TYPE[] {com.lux.luxcloud.global.bean.inverter.BATTERY_TYPE.NO_BATTERY, com.lux.luxcloud.global.bean.inverter.BATTERY_TYPE.LEAD_ACID, com.lux.luxcloud.global.bean.inverter.BATTERY_TYPE.LITHIUM});
    }

    static BATTERY_TYPE()
    {
        com.lux.luxcloud.global.bean.inverter.BATTERY_TYPE.NO_BATTERY = new com.lux.luxcloud.global.bean.inverter.BATTERY_TYPE$1("NO_BATTERY", 0, 0);
        com.lux.luxcloud.global.bean.inverter.BATTERY_TYPE.LEAD_ACID = new com.lux.luxcloud.global.bean.inverter.BATTERY_TYPE$2("LEAD_ACID", 1, 0);
        com.lux.luxcloud.global.bean.inverter.BATTERY_TYPE.LITHIUM = new com.lux.luxcloud.global.bean.inverter.BATTERY_TYPE$3("LITHIUM", 2, 0);
        com.lux.luxcloud.global.bean.inverter.BATTERY_TYPE.$VALUES = com.lux.luxcloud.global.bean.inverter.BATTERY_TYPE.$values();
        return;
    }

    private BATTERY_TYPE(String p1, int p2)
    {
        super(p1, p2);
        return;
    }

    synthetic BATTERY_TYPE(String p1, int p2, com.lux.luxcloud.global.bean.inverter.BATTERY_TYPE-IA p3)
    {
        this(p1, p2);
        return;
    }

    public static com.lux.luxcloud.global.bean.inverter.BATTERY_TYPE getBatteryTypeByCode(int p5)
    {
        com.lux.luxcloud.global.bean.inverter.BATTERY_TYPE[] v0 = com.lux.luxcloud.global.bean.inverter.BATTERY_TYPE.values();
        int v2 = 0;
        while (v2 < v0.length) {
            com.lux.luxcloud.global.bean.inverter.BATTERY_TYPE v3 = v0[v2];
            if (v3.getCode() != p5) {
                v2++;
            } else {
                return v3;
            }
        }
        return 0;
    }

    public static com.lux.luxcloud.global.bean.inverter.BATTERY_TYPE valueOf(String p1)
    {
        return ((com.lux.luxcloud.global.bean.inverter.BATTERY_TYPE) Enum.valueOf(com.lux.luxcloud.global.bean.inverter.BATTERY_TYPE, p1));
    }

    public static com.lux.luxcloud.global.bean.inverter.BATTERY_TYPE[] values()
    {
        return ((com.lux.luxcloud.global.bean.inverter.BATTERY_TYPE[]) com.lux.luxcloud.global.bean.inverter.BATTERY_TYPE.$VALUES.clone());
    }

    public abstract int getCode();

    public abstract String getResourceId();
}
