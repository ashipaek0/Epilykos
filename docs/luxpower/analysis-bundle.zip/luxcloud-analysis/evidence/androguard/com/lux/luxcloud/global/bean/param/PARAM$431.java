package com.lux.luxcloud.global.bean.param;
final enum class PARAM$431 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$431(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$431(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p1)
    {
        if (!p1.getCurrentInverter().isSnaSeries()) {
            return 0;
        } else {
            return 1;
        }
    }

    public Object getPlatformSpecificData(com.lux.luxcloud.global.UserData p3, android.content.Context p4)
    {
        org.json.JSONObject v3_1 = new java.util.LinkedHashMap();
        v3_1.put("-1", p4.getString(2131887062));
        v3_1.put("0", p4.getString(2131887304));
        v3_1.put("1", p4.getString(2131887305));
        return this.createDropdownFromMap(v3_1);
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887013;
    }
}
