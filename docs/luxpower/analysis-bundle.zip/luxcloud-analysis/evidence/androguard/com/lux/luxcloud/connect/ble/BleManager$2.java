package com.lux.luxcloud.connect.ble;
 class BleManager$2 extends android.bluetooth.le.ScanCallback {
    final synthetic com.lux.luxcloud.connect.ble.BleManager this$0;
    final synthetic com.lux.luxcloud.connect.ble.BleManager$ScanFinishCallback val$finishCallback;
    final synthetic com.lux.luxcloud.connect.ble.BleManager$DeviceFoundCallback val$foundCallback;

    BleManager$2(com.lux.luxcloud.connect.ble.BleManager p1, com.lux.luxcloud.connect.ble.BleManager$DeviceFoundCallback p2, com.lux.luxcloud.connect.ble.BleManager$ScanFinishCallback p3)
    {
        this.this$0 = p1;
        this.val$foundCallback = p2;
        this.val$finishCallback = p3;
        return;
    }

    public void onScanFailed(int p1)
    {
        p1 = this.val$finishCallback;
        if (p1 != null) {
            p1.onFinish();
        }
        return;
    }

    public void onScanResult(int p1, android.bluetooth.le.ScanResult p2)
    {
        p1 = this.val$foundCallback;
        if (p1 != null) {
            p1.onDeviceFound(p2);
        }
        return;
    }
}
