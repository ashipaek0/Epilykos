package com.lux.luxcloud.global.bean.param;
final enum class PARAM$282 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$282(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$282(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p8)
    {
        int v8_1 = p8.getCurrentInverter();
        if ((!v8_1.isAcCharger()) && (!v8_1.isHybird())) {
            if (((!v8_1.isType6Series()) && (!v8_1.isGen3Series())) || (v8_1.isAllInOne())) {
                if (!v8_1.isMidBox()) {
                    if (!v8_1.isSnaSeriesOrGeta()) {
                        return 0;
                    } else {
                        int v4_7;
                        String v0_5 = v8_1.getStandard();
                        int v3 = v8_1.getSlaveVersionValue();
                        if (((!v8_1.isSnaSeries()) || (v8_1.getDeviceTypeValue() != 3)) || (((!"cbaa".equals(v0_5)) || (v3 < 38)) && ((!"cBaa".equals(v0_5)) || (v3 < 143)))) {
                            v4_7 = 0;
                        } else {
                            v4_7 = 1;
                        }
                        if ((!v8_1.isSunKing()) || ((!"cbaa".equals(v0_5)) || (v3 < 11))) {
                            int v8_5 = 0;
                        } else {
                            v8_5 = 1;
                        }
                        if ((v4_7 == 0) && (v8_5 == 0)) {
                            return 0;
                        } else {
                            return 1;
                        }
                    }
                } else {
                    return 1;
                }
            } else {
                return 1;
            }
        } else {
            return 1;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131886282;
    }
}
