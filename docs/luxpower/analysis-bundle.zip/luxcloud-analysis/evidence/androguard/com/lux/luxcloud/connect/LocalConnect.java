package com.lux.luxcloud.connect;
public interface LocalConnect {

    public abstract void close();

    public abstract boolean functionControl(int p0, int p1, boolean p2);

    public abstract String getCommandWaitResult(String p0);

    public abstract String getConnectType();

    public abstract String getDatalogSn();

    public abstract com.lux.luxcloud.global.bean.inverter.Inverter getInverter();

    public abstract com.lux.luxcloud.protocol.tcp.dataframe.tcp.TCP_PROTOCOL getTcpProtocol();

    public abstract void initDongleSn();

    public abstract boolean initialize(boolean p0);

    public abstract boolean read03AndInitDevice();

    public abstract String readDatalogParam(int p0);

    public abstract org.json.JSONObject readMultiHold(int p0, int p1);

    public abstract Integer readSingle03(int p0);

    public abstract String sendCommand(String p0, com.lux.luxcloud.protocol.tcp.dataframe.DataFrame p1);

    public abstract String sendCommand(String p0, com.lux.luxcloud.protocol.tcp.dataframe.DataFrame p1, int p2);

    public abstract boolean sendPureCommand(com.lux.luxcloud.protocol.tcp.dataframe.DataFrame p0);

    public abstract void setDatalogSn(String p0);

    public abstract void setInverter(com.lux.luxcloud.global.bean.inverter.Inverter p0);

    public abstract void setTcpProtocol(com.lux.luxcloud.protocol.tcp.dataframe.tcp.TCP_PROTOCOL p0);

    public abstract boolean writeDatalogParam(int p0, String p1);

    public abstract boolean writeDatalogParam(int p0, byte[] p1);

    public abstract boolean writeMulti(int p0, int p1, byte[] p2);

    public abstract boolean writeSingle(int p0, int p1);
}
