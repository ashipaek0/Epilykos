package com.lux.luxcloud.connect.listener;
public interface ConnectListener {

    public abstract void onConnected();

    public void onConnecting()
    {
        return;
    }

    public abstract void onDisconnected();

    public abstract void onFail(String p0);
}
