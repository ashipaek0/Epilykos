package com.lux.luxcloud.global.bean.param;
final enum class BattChgPARAM$28 extends com.lux.luxcloud.global.bean.param.BattChgPARAM {

    private BattChgPARAM$28(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic BattChgPARAM$28(String p1, int p2, com.lux.luxcloud.global.bean.param.BattChgPARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkEnabled(String p2)
    {
        return "SOC".equals(p2);
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p7)
    {
        com.lux.luxcloud.global.bean.inverter.Inverter v0 = p7.getCurrentInverter();
        if (v0.isHybird()) {
            int v1_6 = v0.getStandard();
            int v3 = v0.getSlaveVersionValue();
            int v4 = v0.getFwVersionValue();
            if (((("AAAA".equals(v1_6)) || ("aAAA".equals(v1_6))) && ((v3 >= 36) && (v4 >= 32))) || ((("AAAB".equals(v1_6)) || ("aAAB".equals(v1_6))) && ((v3 >= 29) && (v4 >= 26)))) {
                return 1;
            }
        }
        if (com.lux.luxcloud.global.bean.param.PARAM.BIT_AC_CHARGE_TYPE.checkVisible(p7)) {
            if ((!v0.isType6Series()) || (v0.isAllInOne())) {
                if ((!v0.isMidBox()) && ((!v0.isSnaSeries()) && (!v0.isMega24K()))) {
                    return 0;
                } else {
                    return 1;
                }
            } else {
                return 1;
            }
        } else {
            return 0;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p3)
    {
        if ((p3.isType6()) || ((p3.isMidBox()) || (!p3.isSnaSeries()))) {
            return 2131887597;
        } else {
            return 2131887296;
        }
    }

    public int getStartRegister()
    {
        return 160;
    }
}
