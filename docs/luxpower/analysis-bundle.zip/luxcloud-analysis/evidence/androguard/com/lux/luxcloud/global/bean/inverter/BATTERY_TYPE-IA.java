package com.lux.luxcloud.global.bean.inverter;
public final synthetic class BATTERY_TYPE-IA {
}
