package com.lux.luxcloud.connect.ble;
 class BluetoothLocalConnect$GattCallback extends android.bluetooth.BluetoothGattCallback {
    final synthetic com.lux.luxcloud.connect.ble.BluetoothLocalConnect this$0;

    public static synthetic void $r8$lambda$DEpH0PdCdBFedYjCV8Ov_SKfkm0(com.lux.luxcloud.connect.ble.BluetoothLocalConnect$GattCallback p0, android.bluetooth.BluetoothGatt p1)
    {
        p0.lambda$onConnectionStateChange$0(p1);
        return;
    }

    private BluetoothLocalConnect$GattCallback(com.lux.luxcloud.connect.ble.BluetoothLocalConnect p1)
    {
        this.this$0 = p1;
        return;
    }

    synthetic BluetoothLocalConnect$GattCallback(com.lux.luxcloud.connect.ble.BluetoothLocalConnect p1, com.lux.luxcloud.connect.ble.BluetoothLocalConnect-IA p2)
    {
        this(p1);
        return;
    }

    private synthetic void lambda$onConnectionStateChange$0(android.bluetooth.BluetoothGatt p5)
    {
        if ((com.lux.luxcloud.connect.ble.BluetoothLocalConnect.-$$Nest$fgetbluetoothGatt(this.this$0) == p5) && (!com.lux.luxcloud.connect.ble.BluetoothLocalConnect.-$$Nest$fgetconnected(this.this$0))) {
            com.lux.luxcloud.connect.ble.BluetoothLocalConnect v0_5 = p5.discoverServices();
            System.out.println(new StringBuilder("LuxPower - BLE discoverServices result=").append(v0_5).toString());
            if (v0_5 == null) {
                com.lux.luxcloud.connect.ble.BluetoothLocalConnect.-$$Nest$mfinishConnectFailed(this.this$0, p5, "discoverServices returned false");
            }
        }
        return;
    }

    public void onCharacteristicChanged(android.bluetooth.BluetoothGatt p4, android.bluetooth.BluetoothGattCharacteristic p5)
    {
        p4 = p5.getValue();
        if (p4 != null) {
            int v5_1 = p4.length;
            int v0 = 0;
            while (v0 < v5_1) {
                com.lux.luxcloud.connect.ble.BluetoothLocalConnect.-$$Nest$fgettcpAnalyzer(this.this$0).putChar(com.lux.luxcloud.tool.ProTool.getInt(p4[v0]));
                v0++;
            }
        }
        return;
    }

    public void onCharacteristicWrite(android.bluetooth.BluetoothGatt p2, android.bluetooth.BluetoothGattCharacteristic p3, int p4)
    {
        if (p4 != 0) {
            System.err.println(new StringBuilder("LuxPower - ble - write failed, status=").append(p4).toString());
        }
        try {
            this.this$0.notifyAll();
            return;
        } catch (Throwable v3_1) {
            throw v3_1;
        }
    }

    public void onConnectionStateChange(android.bluetooth.BluetoothGatt p5, int p6, int p7)
    {
        System.out.println(new StringBuilder("LuxPower - BLE state change, status=").append(p6).append(", newState=").append(p7).append(", retry=").append(com.lux.luxcloud.connect.ble.BluetoothLocalConnect.-$$Nest$fgetgattRetryCount(this.this$0)).toString());
        if (p6 != null) {
            System.out.println(new StringBuilder("LuxPower - BLE connect failed, status=").append(p6).append(", retry=").append(com.lux.luxcloud.connect.ble.BluetoothLocalConnect.-$$Nest$fgetgattRetryCount(this.this$0)).toString());
            com.lux.luxcloud.connect.ble.BluetoothLocalConnect.-$$Nest$fputlastConnectError(this.this$0, new StringBuilder("gatt error: ").append(p6).toString());
            com.lux.luxcloud.connect.ble.BluetoothLocalConnect.-$$Nest$mcloseGattSafely(this.this$0, p5);
            if ((!com.lux.luxcloud.connect.ble.BluetoothLocalConnect.-$$Nest$mshouldRetryGattError(this.this$0, p6)) || (com.lux.luxcloud.connect.ble.BluetoothLocalConnect.-$$Nest$fgetgattRetryCount(this.this$0) >= 3)) {
                com.lux.luxcloud.connect.ble.BluetoothLocalConnect.-$$Nest$mfinishConnectFailed(this.this$0, 0, new StringBuilder("gatt error: ").append(p6).toString());
                return;
            } else {
                com.lux.luxcloud.connect.ble.BluetoothLocalConnect.-$$Nest$mscheduleGattRetry(this.this$0, p6);
                return;
            }
        } else {
            if (p7 != 2) {
                if (p7 == null) {
                    com.lux.luxcloud.connect.ble.BluetoothLocalConnect v6_9 = com.lux.luxcloud.connect.ble.BluetoothLocalConnect.-$$Nest$fgetconnected(this.this$0);
                    com.lux.luxcloud.connect.ble.BluetoothLocalConnect.-$$Nest$mcloseGattSafely(this.this$0, p5);
                    com.lux.luxcloud.connect.ble.BluetoothLocalConnect.-$$Nest$fputconnectFinished(this.this$0, 1);
                    if ((v6_9 != null) && (com.lux.luxcloud.connect.ble.BluetoothLocalConnect.-$$Nest$fgetconnectListener(this.this$0) != null)) {
                        com.lux.luxcloud.connect.ble.BluetoothLocalConnect.-$$Nest$fgetconnectListener(this.this$0).onDisconnected();
                    }
                }
            } else {
                com.lux.luxcloud.connect.ble.BluetoothLocalConnect.-$$Nest$fputbluetoothGatt(this.this$0, p5);
                System.out.println("LuxPower - BLE connected, discover services later");
                if (com.lux.luxcloud.connect.ble.BluetoothLocalConnect.-$$Nest$fgetbleHandler(this.this$0) == null) {
                    if (!p5.discoverServices()) {
                        com.lux.luxcloud.connect.ble.BluetoothLocalConnect.-$$Nest$mfinishConnectFailed(this.this$0, p5, "discoverServices returned false");
                        return;
                    }
                } else {
                    com.lux.luxcloud.connect.ble.BluetoothLocalConnect.-$$Nest$fgetbleHandler(this.this$0).postDelayed(new com.lux.luxcloud.connect.ble.BluetoothLocalConnect$GattCallback$$ExternalSyntheticLambda0(this, p5), 1000);
                    return;
                }
            }
            return;
        }
    }

    public void onDescriptorWrite(android.bluetooth.BluetoothGatt p3, android.bluetooth.BluetoothGattDescriptor p4, int p5)
    {
        if (p5 != null) {
            com.lux.luxcloud.connect.ble.BluetoothLocalConnect.-$$Nest$mfinishConnectFailed(this.this$0, p3, new StringBuilder("descriptor failed: ").append(p5).toString());
            return;
        } else {
            System.out.println("LuxPower - ble - descriptor OK, request MTU 256");
            if (!p3.requestMtu(256)) {
                System.out.println("LuxPower - ble - requestMtu failed, use default chunk");
                com.lux.luxcloud.connect.ble.BluetoothLocalConnect.-$$Nest$monBleReady(this.this$0);
            }
            return;
        }
    }

    public void onMtuChanged(android.bluetooth.BluetoothGatt p3, int p4, int p5)
    {
        System.out.println(new StringBuilder("LuxPower - ble - onMtuChanged, mtu=").append(p4).append(", status=").append(p5).toString());
        if ((p5 != null) || (p4 <= 23)) {
            com.lux.luxcloud.connect.ble.BluetoothLocalConnect.-$$Nest$fputcurrentMtu(this.this$0, 23);
            com.lux.luxcloud.connect.ble.BluetoothLocalConnect.-$$Nest$fputcurrentChunkSize(this.this$0, 20);
        } else {
            com.lux.luxcloud.connect.ble.BluetoothLocalConnect.-$$Nest$fputcurrentMtu(this.this$0, p4);
            com.lux.luxcloud.connect.ble.BluetoothLocalConnect.-$$Nest$fputcurrentChunkSize(this.this$0, Math.max(20, (p4 - 3)));
        }
        com.lux.luxcloud.connect.ble.BluetoothLocalConnect.-$$Nest$monBleReady(this.this$0);
        return;
    }

    public void onServicesDiscovered(android.bluetooth.BluetoothGatt p4, int p5)
    {
        System.out.println(new StringBuilder("LuxPower - ble - onServicesDiscovered, status=").append(p5).toString());
        if (p5 == null) {
            com.lux.luxcloud.connect.ble.BluetoothLocalConnect v5_3 = p4.getService(java.util.UUID.fromString("000000ff-0000-1000-8000-00805f9b34fb"));
            if (v5_3 != null) {
                com.lux.luxcloud.connect.ble.BluetoothLocalConnect v5_4 = v5_3.getCharacteristic(java.util.UUID.fromString("0000ff01-0000-1000-8000-00805f9b34fb"));
                String v0_3 = this.this$0;
                if (v5_4 != null) {
                    com.lux.luxcloud.connect.ble.BluetoothLocalConnect.-$$Nest$fputnotifyCharacteristic(v0_3, v5_4);
                    com.lux.luxcloud.connect.ble.BluetoothLocalConnect.-$$Nest$fputwriteCharacteristic(this.this$0, v5_4);
                    if (p4.setCharacteristicNotification(v5_4, 1)) {
                        com.lux.luxcloud.connect.ble.BluetoothLocalConnect v5_5 = v5_4.getDescriptor(java.util.UUID.fromString("00002902-0000-1000-8000-00805f9b34fb"));
                        if (v5_5 != null) {
                            v5_5.setValue(android.bluetooth.BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                            if (!p4.writeDescriptor(v5_5)) {
                                com.lux.luxcloud.connect.ble.BluetoothLocalConnect.-$$Nest$mfinishConnectFailed(this.this$0, p4, "write descriptor failed");
                            }
                            return;
                        } else {
                            com.lux.luxcloud.connect.ble.BluetoothLocalConnect.-$$Nest$mfinishConnectFailed(this.this$0, p4, "descriptor not found");
                            return;
                        }
                    } else {
                        com.lux.luxcloud.connect.ble.BluetoothLocalConnect.-$$Nest$mfinishConnectFailed(this.this$0, p4, "set notification failed");
                        return;
                    }
                } else {
                    com.lux.luxcloud.connect.ble.BluetoothLocalConnect.-$$Nest$mfinishConnectFailed(v0_3, p4, "char not found");
                    return;
                }
            } else {
                com.lux.luxcloud.connect.ble.BluetoothLocalConnect.-$$Nest$mfinishConnectFailed(this.this$0, p4, "service not found");
                return;
            }
        } else {
            com.lux.luxcloud.connect.ble.BluetoothLocalConnect.-$$Nest$mfinishConnectFailed(this.this$0, p4, new StringBuilder("discover failed: ").append(p5).toString());
            return;
        }
    }
}
