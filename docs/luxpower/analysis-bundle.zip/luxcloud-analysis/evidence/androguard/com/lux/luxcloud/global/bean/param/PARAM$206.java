package com.lux.luxcloud.global.bean.param;
final enum class PARAM$206 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$206(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$206(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p2)
    {
        return com.lux.luxcloud.global.bean.param.PARAM$206.FUNC_GO_TO_OFFGRID_MODE.checkVisible(p2);
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p2)
    {
        if (!com.lux.luxcloud.global.bean.user.PLATFORM.EG4.equals(com.lux.luxcloud.version.Custom.APP_USER_PLATFORM)) {
            return 2131887424;
        } else {
            return 2131887425;
        }
    }
}
