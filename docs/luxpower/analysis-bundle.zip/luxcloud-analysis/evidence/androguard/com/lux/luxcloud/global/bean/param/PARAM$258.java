package com.lux.luxcloud.global.bean.param;
final enum class PARAM$258 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$258(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$258(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p7)
    {
        boolean v0_0 = p7.getCurrentInverter();
        if (v0_0.isHybird()) {
            int v4_5;
            int v1_8 = v0_0.getStandard();
            if (((!"AAAA".equals(v1_8)) && (!"aAAA".equals(v1_8))) || ((v0_0.getSlaveVersionValue() < 36) || (v0_0.getFwVersionValue() < 32))) {
                v4_5 = 0;
            } else {
                v4_5 = 1;
            }
            if (((!"AAAB".equals(v1_8)) && (!"aAAB".equals(v1_8))) || ((v0_0.getSlaveVersionValue() < 29) || (v0_0.getFwVersionValue() < 26))) {
                int v1_4 = 0;
            } else {
                v1_4 = 1;
            }
            if ((v4_5 != 0) || (v1_4 != 0)) {
                return 1;
            }
        }
        if ((!v0_0.isType6Series()) && (!v0_0.isGen3Series())) {
            if (!v0_0.isAcCharger()) {
                if (!v0_0.isMidBox()) {
                    return 0;
                } else {
                    if ((this.isViewer(p7)) && (!this.isEg4(p7))) {
                        return 0;
                    } else {
                        return 1;
                    }
                }
            } else {
                return 0;
            }
        } else {
            return 1;
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        if (!p1.getCurrentInverter().isMidBox()) {
            return 2131886727;
        } else {
            return -1;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887092;
    }
}
