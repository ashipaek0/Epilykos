package com.lux.luxcloud.global.bean.param;
final enum class PARAM$254 extends com.lux.luxcloud.global.bean.param.PARAM {

    private PARAM$254(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic PARAM$254(String p1, int p2, com.lux.luxcloud.global.bean.param.PARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p6)
    {
        boolean v0_0 = p6.getCurrentInverter();
        if (v0_0) {
            boolean v6_9;
            new com.lux.luxcloud.global.bean.inverter.Model(v0_0.getModel().longValue()).getMeasurement();
            if ((!v0_0.isAcCharger()) && (!v0_0.isHybird())) {
                if (((!v0_0.isType6Series()) && (!v0_0.isGen3Series())) || (v0_0.isAllInOne())) {
                    if ((!v0_0.isSna3_6K_eu()) && ((!v0_0.isGen3()) && (!v0_0.isGen3Pro()))) {
                        if ((!v0_0.isSnaSeriesOrGeta()) || ((this.isViewer(p6)) || (!this.isEg4(p6)))) {
                            return 0;
                        } else {
                            if (((!v0_0.isGeta()) && ((!v0_0.isOffGrid()) || (v0_0.getHardwareVersion() < 11))) && (((v0_0.getSubDeviceTypeValue() != 131) && (v0_0.getHardwareVersion() != 11)) || (v0_0.is_ENELEAGE_ZERO()))) {
                                return 0;
                            } else {
                                return 1;
                            }
                        }
                    } else {
                        if ((!this.isAdmin(p6)) && (!this.isMAINTAIN(p6))) {
                            return 0;
                        } else {
                            return 1;
                        }
                    }
                } else {
                    v6_9 = this.isViewer(p6);
                }
            } else {
                v6_9 = this.isViewer(p6);
            }
            return (v6_9 ^ 1);
        } else {
            return 0;
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        p1.getCurrentInverter();
        return 2131886760;
    }

    public Object getPlatformSpecificData(com.lux.luxcloud.global.UserData p4, android.content.Context p5)
    {
        org.json.JSONObject v4_1 = p4.getCurrentInverter();
        if (v4_1 != null) {
            java.util.LinkedHashMap v1_1 = new java.util.LinkedHashMap();
            v1_1.put("-1", p5.getString(2131887062));
            v1_1.put("0", "1/1000");
            v1_1.put("1", "1/3000");
            v1_1.put("2", "1/2000");
            if (((v4_1.isType6Series()) && ((com.lux.luxcloud.global.bean.param.PARAM.-$$Nest$smisStandard(v4_1, "FAAB")) && ((v4_1.getSlaveVersion().intValue() >= 31) && (v4_1.getFwVersion().intValue() >= 31)))) || (((v4_1.is7_10KDevice()) && ((com.lux.luxcloud.global.bean.param.PARAM.-$$Nest$smisStandard(v4_1, "HAAA")) && ((v4_1.getSlaveVersion().intValue() >= 8) && (v4_1.getFwVersion().intValue() >= 7)))) || (v4_1.isGen2_7_14K()))) {
                v1_1.put("3", "1/4000");
                v1_1.put("4", "1/6000");
            }
            if (v1_1.isEmpty()) {
                return 0;
            } else {
                java.util.Set v0_1 = new String[0];
                String[] v5_21 = new String[0];
                return this.createDropdown(((String[]) v1_1.values().toArray(v0_1)), ((String[]) v1_1.keySet().toArray(v5_21)));
            }
        } else {
            return 0;
        }
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887009;
    }
}
