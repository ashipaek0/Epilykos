package com.lux.luxcloud.global.bean.param;
final enum class BattChgPARAM$31 extends com.lux.luxcloud.global.bean.param.BattChgPARAM {

    private BattChgPARAM$31(String p2, int p3)
    {
        super(p2, p3, 0);
        return;
    }

    synthetic BattChgPARAM$31(String p1, int p2, com.lux.luxcloud.global.bean.param.BattChgPARAM-IA p3)
    {
        this(p1, p2);
        return;
    }

    public boolean checkEnabled(String p2)
    {
        return "SOC".equals(p2);
    }

    public boolean checkVisible(com.lux.luxcloud.global.UserData p1)
    {
        if (!p1.getCurrentInverter().isEQB()) {
            return 1;
        } else {
            return 0;
        }
    }

    public int getDescription(com.lux.luxcloud.global.UserData p1)
    {
        return 2131887637;
    }

    public int getResourceId(com.lux.luxcloud.global.bean.inverter.Inverter p1)
    {
        return 2131887338;
    }

    public int getStartRegister()
    {
        return 196;
    }
}
